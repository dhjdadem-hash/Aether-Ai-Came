package com.aether.camera.ultra.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** اختبار حقيقي لكاميرا: يفتحها، يلتقط إطارًا، ويحلل الألوان والحدة. يُستدعى خارج الخيط الرئيسي. */
object CameraProbe {

    class Result(
        val ok: Boolean,
        val error: String,
        val thumb: Bitmap?,
        val avgSat: Float,
        val avgLuma: Float,
        val sharp: Float,
        val width: Int,
        val height: Int
    ) {
        val grayish: Boolean get() = ok && avgSat < 0.06f
    }

    private fun fail(msg: String) = Result(false, msg, null, 0f, 0f, 0f, 0, 0)

    fun probe(ctx: Context, cameraId: String, physicalId: String?): Result {
        val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ht = HandlerThread("AetherProbe")
        ht.start()
        val h = Handler(ht.looper)
        var dev: CameraDevice? = null
        var sess: CameraCaptureSession? = null
        var reader: ImageReader? = null
        try {
            val c = manager.getCameraCharacteristics(cameraId)
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: return fail("لا توجد قائمة أحجام")
            val sizes = map.getOutputSizes(ImageFormat.YUV_420_888)
            if (sizes == null || sizes.isEmpty()) return fail("لا يدعم إطارات YUV")
            val pick = sizes.filter { it.width <= 1280 && it.height <= 960 }.maxByOrNull { it.width * it.height }
                ?: sizes.minByOrNull { it.width * it.height }!!
            val rd: ImageReader = ImageReader.newInstance(pick.width, pick.height, ImageFormat.YUV_420_888, 4)
            reader = rd

            val openLatch = CountDownLatch(1)
            var openErr: String? = null
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) { dev = camera; openLatch.countDown() }
                override fun onDisconnected(camera: CameraDevice) { camera.close(); openErr = "انقطع الاتصال"; openLatch.countDown() }
                override fun onError(camera: CameraDevice, error: Int) { camera.close(); openErr = "رفض النظام فتح الكاميرا (رمز $error)"; openLatch.countDown() }
            }, h)
            if (!openLatch.await(5, TimeUnit.SECONDS)) return fail("انتهت مهلة فتح الكاميرا")
            val d = dev ?: return fail(openErr ?: "تعذر الفتح")

            val cfgLatch = CountDownLatch(1)
            val scb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) { sess = s; cfgLatch.countDown() }
                override fun onConfigureFailed(s: CameraCaptureSession) { cfgLatch.countDown() }
            }
            val surf: Surface = rd.surface
            if (Build.VERSION.SDK_INT >= 28 && physicalId != null) {
                val oc = OutputConfiguration(surf)
                oc.setPhysicalCameraId(physicalId)
                d.createCaptureSession(
                    SessionConfiguration(SessionConfiguration.SESSION_REGULAR, listOf(oc), Executor { r -> h.post(r) }, scb)
                )
            } else {
                d.createCaptureSession(listOf(surf), scb, h)
            }
            if (!cfgLatch.await(5, TimeUnit.SECONDS)) return fail("انتهت مهلة إعداد الجلسة")
            val s = sess ?: return fail("رفض النظام إعداد الجلسة لهذه الكاميرا")
            val rb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            rb.addTarget(surf)
            rb.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            s.setRepeatingRequest(rb.build(), null, h)

            // ننتظر تقارب التعريض ثم نأخذ الإطار
            var bmp: Bitmap? = null
            val deadline = System.currentTimeMillis() + 6000L
            var frames = 0
            while (System.currentTimeMillis() < deadline) {
                val img = rd.acquireLatestImage()
                if (img == null) { Thread.sleep(40); continue }
                frames++
                if (frames >= 14) {
                    bmp = yuvToBitmap(img)
                    img.close()
                    break
                }
                img.close()
            }
            if (bmp == null) return fail("لم تصل إطارات من الكاميرا")
            return analyze(bmp, pick.width, pick.height)
        } catch (e: SecurityException) {
            return fail("لا توجد صلاحية الكاميرا")
        } catch (e: Exception) {
            return fail("تعذر الاختبار: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            try { sess?.close() } catch (e: Exception) { /* تجاهل */ }
            try { dev?.close() } catch (e: Exception) { /* تجاهل */ }
            try { reader?.close() } catch (e: Exception) { /* تجاهل */ }
            ht.quitSafely()
        }
    }

    private fun yuvToBitmap(img: android.media.Image): Bitmap {
        val step = max(1, img.width / 320)
        val ow = img.width / step
        val oh = img.height / step
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yb = yP.buffer
        val ub = uP.buffer
        val vb = vP.buffer
        val px = IntArray(ow * oh)
        for (j in 0 until oh) {
            val y = j * step
            for (i in 0 until ow) {
                val x = i * step
                val yy = yb.get(y * yP.rowStride + x * yP.pixelStride).toInt() and 0xFF
                val uu = (ub.get((y / 2) * uP.rowStride + (x / 2) * uP.pixelStride).toInt() and 0xFF) - 128
                val vv = (vb.get((y / 2) * vP.rowStride + (x / 2) * vP.pixelStride).toInt() and 0xFF) - 128
                var r = (yy + 1.402f * vv).toInt()
                var g = (yy - 0.344f * uu - 0.714f * vv).toInt()
                var b = (yy + 1.772f * uu).toInt()
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                px[j * ow + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return Bitmap.createBitmap(px, ow, oh, Bitmap.Config.ARGB_8888)
    }

    private fun analyze(b: Bitmap, w: Int, h: Int): Result {
        val bw = b.width
        val bh = b.height
        val px = IntArray(bw * bh)
        b.getPixels(px, 0, bw, 0, 0, bw, bh)
        val luma = FloatArray(bw * bh)
        var satSum = 0.0
        var satN = 0
        var lumaSum = 0.0
        for (i in px.indices) {
            val r = (px[i] shr 16) and 255
            val g = (px[i] shr 8) and 255
            val bl = px[i] and 255
            val mx = max(r, max(g, bl))
            val mn = minOf(r, minOf(g, bl))
            if (mx > 25) { satSum += (mx - mn).toDouble() / mx; satN++ }
            val y = (r * 0.299f + g * 0.587f + bl * 0.114f)
            luma[i] = y
            lumaSum += y
        }
        var lap = 0.0
        var n = 0
        for (y in 1 until bh - 1) {
            for (x in 1 until bw - 1) {
                val i = y * bw + x
                val v = 4f * luma[i] - luma[i - 1] - luma[i + 1] - luma[i - bw] - luma[i + bw]
                lap += abs(v).toDouble()
                n++
            }
        }
        val sat = if (satN > 0) (satSum / satN).toFloat() else 0f
        val lm = (lumaSum / px.size / 255.0).toFloat()
        val sharp = if (n > 0) (lap / n).toFloat() else 0f
        return Result(true, "", b, sat, lm, sharp, w, h)
    }
}
