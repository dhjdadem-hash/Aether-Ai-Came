package com.aether.camera.ultra.ui

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import com.aether.camera.ultra.MainActivity
import com.aether.camera.ultra.ai.ColorEngine
import com.aether.camera.ultra.ai.PortraitEngine
import com.aether.camera.ultra.media.MediaItem
import com.aether.camera.ultra.media.MediaStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class ViewerScreen(
    private val act: MainActivity,
    items: List<MediaItem>,
    startIndex: Int,
    private val inTrash: Boolean
) : Screen {
    private val prefs = act.prefs
    private val root = FrameLayout(act)
    override val view: View = root
    private val zoomView = ZoomImageView(act)
    private val videoHolder = FrameLayout(act)
    private val videoView = VideoView(act)
    private val topBar = LinearLayout(act)
    private val titleText = label(act, "", 14f, Color.WHITE, true)
    private val bottomBar = LinearLayout(act)
    private val card = LinearLayout(act)
    private val cardText = label(act, "", 14f, Color.WHITE, true)
    private val progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
    private val blurSeek = SeekBar(act)
    private val cardButtons = LinearLayout(act)
    private val heartBtn = GlassIconButton(act, IconView.Kind.HEART, 46)
    private val wandBtn = GlassIconButton(act, IconView.Kind.WAND, 46)
    private val portraitBtn = GlassIconButton(act, IconView.Kind.PORTRAIT, 46)
    private val compareBtn = GlassIconButton(act, IconView.Kind.COMPARE, 46)
    private val undoBtn = GlassIconButton(act, IconView.Kind.UNDO, 46)
    private val shareBtn = GlassIconButton(act, IconView.Kind.SHARE, 46)
    private val delBtn = GlassIconButton(act, IconView.Kind.TRASH, 46)
    private val boxes = ArrayList<View>()

    private val list = ArrayList<MediaItem>(items)
    private var pos = startIndex.coerceIn(0, max(0, items.size - 1))
    private var curBmp: Bitmap? = null
    private var busy = false
    private var chromeVisible = true
    private var loadToken = 0
    private var token = 0
    private val exec = Executors.newSingleThreadExecutor()
    private val previewExec = Executors.newSingleThreadExecutor()
    private var pFull: Bitmap? = null
    private var pPreview: Bitmap? = null
    private var pMask: PortraitEngine.Mask? = null
    private var pSource: MediaItem? = null

    private val cur: MediaItem get() = list[pos]

    init {
        root.setBackgroundColor(Color.BLACK)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.addView(zoomView, FrameLayout.LayoutParams(MATCH, MATCH))
        zoomView.onSwipe = { d -> go(d) }
        zoomView.onTap = { toggleChrome() }

        videoView.setZOrderOnTop(false)
        videoHolder.addView(videoView, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        videoHolder.visibility = View.GONE
        root.addView(videoHolder, FrameLayout.LayoutParams(MATCH, MATCH))

        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(act.dp(12), 0, act.dp(12), act.dp(8))
        topBar.setBackgroundColor(Color.parseColor("#80000000"))
        val back = GlassIconButton(act, IconView.Kind.BACK, 42)
        back.onTap { act.close() }
        topBar.addView(back, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        titleText.setPadding(act.dp(12), 0, act.dp(12), 0)
        titleText.maxLines = 1
        topBar.addView(titleText, LinearLayout.LayoutParams(0, WRAP, 1f))
        val info = GlassIconButton(act, IconView.Kind.INFO, 42)
        info.onTap { showInfo() }
        topBar.addView(info, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        root.addView(topBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.setPadding(act.dp(6), act.dp(8), act.dp(6), act.dp(8))
        bottomBar.setBackgroundColor(Color.parseColor("#80000000"))
        addAction(shareBtn, "مشاركة") { share() }
        addAction(heartBtn, "مفضلة") { toggleFav() }
        addAction(wandBtn, "تحسين AI") { runEnhance() }
        addAction(portraitBtn, "بورتريه") { runPortrait() }
        addAction(compareBtn, "مقارنة") { toggleCompare() }
        addAction(undoBtn, if (inTrash) "استعادة" else "الأصل") { undo() }
        addAction(delBtn, if (inTrash) "حذف نهائي" else "حذف") { deleteCurrent() }
        root.addView(bottomBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        card.orientation = LinearLayout.VERTICAL
        card.background = glass(act, 20f, true)
        card.setPadding(act.dp(16), act.dp(12), act.dp(16), act.dp(12))
        card.visibility = View.GONE
        card.addView(cardText, LinearLayout.LayoutParams(MATCH, WRAP))
        progress.max = 100
        progress.progressTintList = android.content.res.ColorStateList.valueOf(K.CYAN)
        card.addView(progress, LinearLayout.LayoutParams(MATCH, act.dp(10)).also { it.topMargin = act.dp(8) })
        blurSeek.max = 100
        blurSeek.progressTintList = android.content.res.ColorStateList.valueOf(K.CYAN)
        blurSeek.thumbTintList = android.content.res.ColorStateList.valueOf(K.CYAN)
        blurSeek.visibility = View.GONE
        card.addView(blurSeek, LinearLayout.LayoutParams(MATCH, WRAP))
        cardButtons.orientation = LinearLayout.HORIZONTAL
        cardButtons.gravity = Gravity.CENTER
        cardButtons.visibility = View.GONE
        card.addView(cardButtons, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = act.dp(8) })
        root.addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).also {
            it.marginStart = act.dp(12); it.marginEnd = act.dp(12); it.bottomMargin = act.dp(110)
        })

        blurSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) renderPortraitPreview(p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        showCurrent()
    }

    private fun addAction(btn: GlassIconButton, text: String, onClick: () -> Unit) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        btn.onTap(onClick)
        box.addView(btn, LinearLayout.LayoutParams(act.dp(46), act.dp(46)))
        val t = label(act, text, 10f, K.WHITE80)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        box.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        bottomBar.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        boxes.add(box)
        btn.tag = box
    }

    private fun boxOf(b: GlassIconButton): View = b.tag as View

    override fun onInsets(top: Int, bottom: Int) {
        topBar.setPadding(act.dp(12), top + act.dp(6), act.dp(12), act.dp(8))
        bottomBar.setPadding(act.dp(6), act.dp(8), act.dp(6), bottom + act.dp(8))
    }

    override fun onPause() {
        try { videoView.pause() } catch (e: Exception) { /* تجاهل */ }
    }

    override fun onBack(): Boolean {
        if (busy) { act.toast("انتظر انتهاء المعالجة"); return true }
        if (blurSeek.visibility == View.VISIBLE) { cancelPortrait(); return true }
        return false
    }

    private fun ui(r: () -> Unit) { act.runOnUiThread { r() } }

    private fun toggleChrome() {
        chromeVisible = !chromeVisible
        val a = if (chromeVisible) 1f else 0f
        topBar.animate().alpha(a).setDuration(150).start()
        bottomBar.animate().alpha(a).setDuration(150).start()
        topBar.visibility = if (chromeVisible) View.VISIBLE else View.INVISIBLE
        bottomBar.visibility = if (chromeVisible) View.VISIBLE else View.INVISIBLE
    }

    // ---------------- عرض العنصر الحالي ----------------

    private fun counterpart(it: MediaItem): MediaItem? {
        if (it.isVideo) return null
        return if (it.isAi) list.firstOrNull { o -> !o.isAi && !o.isVideo && o.baseName == it.baseName }
        else list.firstOrNull { o -> o.isAi && !o.isVideo && o.baseName == it.baseName }
    }

    private fun showCurrent() {
        if (list.isEmpty()) { act.close(); return }
        val it = cur
        titleText.text = it.name
        zoomView.compare = false
        zoomView.bmp2 = null
        zoomView.scanFrac = -1f
        updateButtons()
        try { videoView.stopPlayback() } catch (e: Exception) { /* تجاهل */ }
        if (it.isVideo) {
            zoomView.visibility = View.GONE
            videoHolder.visibility = View.VISIBLE
            val mc = MediaController(act)
            mc.setAnchorView(videoHolder)
            videoView.setMediaController(mc)
            videoView.setVideoURI(it.uri)
            videoView.setOnPreparedListener { mp -> mp.isLooping = false; videoView.start() }
            videoView.setOnErrorListener { _, _, _ -> act.toast("تعذر تشغيل هذا الفيديو"); true }
        } else {
            videoHolder.visibility = View.GONE
            zoomView.visibility = View.VISIBLE
            val my = ++loadToken
            exec.execute {
                val b = MediaStorage.decode(act, it.uri, 16_000_000)
                ui { if (my == loadToken) { curBmp = b; zoomView.bmp = b } }
            }
        }
    }

    private fun updateButtons() {
        val it = cur
        val fav = prefs.isFav(it.id)
        heartBtn.icon.kind = if (fav) IconView.Kind.HEART_FILL else IconView.Kind.HEART
        val img = !it.isVideo
        boxOf(wandBtn).visibility = if (img && !inTrash) View.VISIBLE else View.GONE
        boxOf(portraitBtn).visibility = if (img && !inTrash) View.VISIBLE else View.GONE
        boxOf(compareBtn).visibility = if (img && counterpart(it) != null) View.VISIBLE else View.GONE
        boxOf(undoBtn).visibility = if (inTrash || it.isAi) View.VISIBLE else View.GONE
        wandBtn.setActive(counterpart(it) != null || it.isAi)
    }

    private fun go(d: Int) {
        if (busy) return
        val n = pos + d
        if (n < 0 || n >= list.size) return
        pos = n
        showCurrent()
    }

    // ---------------- إجراءات بسيطة ----------------

    private fun share() {
        val it = cur
        val i = Intent(Intent.ACTION_SEND)
        i.type = if (it.isVideo) "video/mp4" else "image/jpeg"
        i.putExtra(Intent.EXTRA_STREAM, it.uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.startActivity(Intent.createChooser(i, "مشاركة"))
    }

    private fun toggleFav() {
        val it = cur
        prefs.setFav(it.id, !prefs.isFav(it.id))
        updateButtons()
    }

    private fun showInfo() {
        val it = cur
        val df = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US)
        val sb = StringBuilder()
        sb.append("الاسم: ").append(it.name).append('\n')
        sb.append("التاريخ: ").append(df.format(Date(it.dateMs))).append('\n')
        sb.append("الدقة: ").append(it.width).append('×').append(it.height)
        if (it.width > 0) sb.append(" (").append(f1(it.width.toFloat() * it.height / 1_000_000f)).append("MP)")
        sb.append('\n')
        sb.append("الحجم: ").append(f1(it.size / 1048576f)).append(" MB").append('\n')
        if (it.isVideo) sb.append("المدة: ").append(it.durationMs / 1000L).append(" ث").append('\n')
        sb.append("المسار: ").append(if (it.isVideo) "Movies/AETHER" else "Pictures/AETHER").append('\n')
        if (it.isAi) sb.append("نسخة معالَجة بالذكاء الاصطناعي المحلي (الأصل محفوظ منفصلًا)")
        val other = counterpart(it)
        if (other != null && !it.isAi) sb.append("توجد نسخة محسّنة: ").append(other.name)
        AlertDialog.Builder(act).setTitle("معلومات").setMessage(sb.toString()).setPositiveButton("حسنًا", null).show()
    }

    private fun deleteCurrent() {
        val it = cur
        if (inTrash) {
            AlertDialog.Builder(act).setTitle("حذف نهائي").setMessage("لا يمكن التراجع عن هذا الحذف.")
                .setPositiveButton("حذف") { _, _ ->
                    val ok = MediaStorage.delete(act, it.uri)
                    prefs.untrash(listOf(it.id))
                    if (!ok) act.toast("تعذر الحذف")
                    removeCurrent()
                }.setNegativeButton("إلغاء", null).show()
        } else {
            prefs.trash(listOf(it.id))
            act.toast("نُقل إلى سلة المحذوفات")
            removeCurrent()
        }
    }

    private fun removeCurrent() {
        list.removeAt(pos)
        if (list.isEmpty()) { act.close(); return }
        if (pos >= list.size) pos = list.size - 1
        showCurrent()
    }

    private fun undo() {
        val it = cur
        if (inTrash) {
            prefs.untrash(listOf(it.id))
            act.toast("تمت الاستعادة")
            removeCurrent()
            return
        }
        if (it.isAi) {
            val orig = counterpart(it)
            if (orig == null) { act.toast("الأصل غير موجود"); return }
            AlertDialog.Builder(act)
                .setTitle("استعادة الأصل")
                .setMessage("سأعرض الصورة الأصلية. هل تريد أيضًا نقل النسخة المحسّنة إلى سلة المحذوفات؟")
                .setPositiveButton("نعم، انقلها") { _, _ ->
                    prefs.trash(listOf(it.id))
                    list.remove(it)
                    pos = max(0, list.indexOfFirst { o -> o.id == orig.id })
                    showCurrent()
                }
                .setNegativeButton("لا، اعرض الأصل فقط") { _, _ ->
                    pos = max(0, list.indexOfFirst { o -> o.id == orig.id })
                    showCurrent()
                }
                .show()
        }
    }

    // ---------------- المقارنة ----------------

    private fun toggleCompare() {
        if (busy) return
        val it = cur
        if (zoomView.compare) {
            zoomView.compare = false
            zoomView.bmp2 = null
            zoomView.bmp = curBmp
            return
        }
        val other = counterpart(it)
        if (other == null) { act.toast("لا توجد نسخة للمقارنة"); return }
        val mine = curBmp
        if (mine == null) { act.toast("الصورة قيد التحميل"); return }
        exec.execute {
            val ob = MediaStorage.decode(act, other.uri, 16_000_000)
            ui {
                if (ob == null) { act.toast("تعذر تحميل النسخة الأخرى"); return@ui }
                val orig = if (it.isAi) ob else mine
                val enh = if (it.isAi) mine else ob
                val ra = orig.width.toFloat() / orig.height
                val rb = enh.width.toFloat() / enh.height
                if (abs(ra - rb) > 0.02f) {
                    act.toast("النسختان بنسبتين مختلفتين (قص/تكبير) فلا يمكن المقارنة")
                } else {
                    zoomView.bmp = orig
                    zoomView.bmp2 = enh
                    zoomView.divider = 0.5f
                    zoomView.compare = true
                }
            }
        }
    }

    // ---------------- تحسين AI الحقيقي ----------------

    private fun showCard(text: String, determinate: Boolean) {
        card.visibility = View.VISIBLE
        cardText.text = text
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        blurSeek.visibility = View.GONE
        cardButtons.visibility = View.GONE
    }

    private fun hideCard() {
        card.visibility = View.GONE
        zoomView.scanFrac = -1f
    }

    private fun runEnhance() {
        if (busy) return
        val it = cur
        if (it.isVideo) return
        if (it.isAi) { toggleCompare(); return }
        if (counterpart(it) != null) { toggleCompare(); return }
        busy = true
        showCard("جارٍ تحسين الألوان محليًا…", true)
        val preset = ColorEngine.byStrength(prefs.aiStrength)
        exec.execute {
            val src = MediaStorage.decode(act, it.uri, 10_000_000)
            if (src == null) {
                ui { busy = false; hideCard(); act.toast("تعذر فتح الصورة") }
                return@execute
            }
            try {
                val res = ColorEngine.enhance(src, preset) { p ->
                    ui { progress.progress = p; zoomView.scanFrac = p / 100f; cardText.text = "معالجة الألوان… $p%" }
                }
                val uri = MediaStorage.saveBitmapJpeg(act, res.bitmap, it.baseName + "_AI", prefs.jpegQuality)
                val fresh = loadList()
                ui {
                    busy = false
                    hideCard()
                    if (uri == null) {
                        act.toast("فشل حفظ النسخة المحسّنة")
                    } else {
                        applyFresh(fresh, it.id)
                        zoomView.bmp = src
                        zoomView.bmp2 = res.bitmap
                        zoomView.compare = true
                        revealAnim()
                        act.toast(res.stats.describe())
                    }
                }
            } catch (e: OutOfMemoryError) {
                ui { busy = false; hideCard(); act.toast("الذاكرة لا تكفي لمعالجة هذه الصورة") }
            } catch (e: Exception) {
                ui { busy = false; hideCard(); act.toast("فشلت المعالجة: " + (e.message ?: "")) }
            }
        }
    }

    private fun loadList(): List<MediaItem> {
        val hidden = prefs.trashMap().keys
        return MediaStorage.list(act).filter { o -> if (inTrash) hidden.contains(o.id) else !hidden.contains(o.id) }
    }

    private fun applyFresh(fresh: List<MediaItem>, keepId: Long) {
        list.clear()
        list.addAll(fresh)
        val i = list.indexOfFirst { o -> o.id == keepId }
        pos = if (i >= 0) i else min(pos, max(0, list.size - 1))
        titleText.text = cur.name
        updateButtons()
    }

    private fun revealAnim() {
        val a = ValueAnimator.ofFloat(0.02f, 0.98f, 0.5f)
        a.duration = 1500
        a.addUpdateListener { zoomView.divider = it.animatedValue as Float }
        a.start()
    }

    // ---------------- بورتريه ----------------

    private fun runPortrait() {
        if (busy) return
        val it = cur
        if (it.isVideo) return
        val src: MediaItem = if (it.isAi) (counterpart(it) ?: it) else it
        busy = true
        pSource = src
        showCard("جارٍ اكتشاف الشخص…", false)
        exec.execute {
            val full = MediaStorage.decode(act, src.uri, 8_000_000)
            if (full == null) {
                ui { busy = false; hideCard(); act.toast("تعذر فتح الصورة") }
                return@execute
            }
            val sc = min(1f, 960f / max(full.width, full.height).toFloat())
            val prev = if (sc < 1f) Bitmap.createScaledBitmap(full, max(2, (full.width * sc).toInt()), max(2, (full.height * sc).toInt()), true) else full
            val err = arrayOfNulls<String>(1)
            val mask = try { PortraitEngine.segment(prev, err) } catch (e: Exception) { err[0] = e.message; null }
            if (mask == null) {
                ui { busy = false; hideCard(); act.toast(err[0] ?: "تعذر اكتشاف الشخص") }
                return@execute
            }
            ui {
                pFull = full
                pPreview = prev
                pMask = mask
                busy = false
                showPortraitControls()
            }
        }
    }

    private fun showPortraitControls() {
        card.visibility = View.VISIBLE
        cardText.text = "قوة تمويه الخلفية"
        progress.visibility = View.GONE
        blurSeek.visibility = View.VISIBLE
        blurSeek.progress = prefs.portraitBlur
        cardButtons.visibility = View.VISIBLE
        cardButtons.removeAllViews()
        val save = chip(act, "حفظ نسخة بورتريه", true)
        save.setOnClickListener { savePortrait() }
        val cancel = chip(act, "إلغاء")
        cancel.setOnClickListener { cancelPortrait() }
        val p1 = LinearLayout.LayoutParams(WRAP, WRAP)
        p1.marginEnd = act.dp(10)
        cardButtons.addView(save, p1)
        cardButtons.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP))
        renderPortraitPreview(prefs.portraitBlur)
    }

    private fun renderPortraitPreview(p: Int) {
        val prev = pPreview ?: return
        val mask = pMask ?: return
        val my = ++token
        previewExec.execute {
            val out = try { PortraitEngine.render(prev, mask, p / 100f) } catch (e: Exception) { null }
            ui {
                if (my == token && out != null && card.visibility == View.VISIBLE) {
                    zoomView.compare = false
                    zoomView.bmp = out
                }
            }
        }
    }

    private fun savePortrait() {
        val full = pFull ?: return
        val mask = pMask ?: return
        val src = pSource ?: return
        val p = blurSeek.progress
        prefs.portraitBlur = p
        busy = true
        showCard("جارٍ تطبيق البورتريه بالدقة الكاملة…", true)
        exec.execute {
            try {
                val out = PortraitEngine.render(full, mask, p / 100f) { q -> ui { progress.progress = q } }
                val old = list.firstOrNull { o -> o.isAi && !o.isVideo && o.baseName == src.baseName }
                if (old != null) MediaStorage.delete(act, old.uri)
                val uri = MediaStorage.saveBitmapJpeg(act, out, src.baseName + "_AI", prefs.jpegQuality)
                val fresh = loadList()
                ui {
                    busy = false
                    hideCard()
                    clearPortrait()
                    if (uri == null) {
                        act.toast("فشل الحفظ")
                    } else {
                        applyFresh(fresh, src.id)
                        zoomView.bmp = full
                        zoomView.bmp2 = out
                        zoomView.compare = true
                        revealAnim()
                        act.toast("تم حفظ نسخة البورتريه (الأصل محفوظ)")
                    }
                }
            } catch (e: OutOfMemoryError) {
                ui { busy = false; hideCard(); act.toast("الذاكرة لا تكفي") }
            } catch (e: Exception) {
                ui { busy = false; hideCard(); act.toast("فشل: " + (e.message ?: "")) }
            }
        }
    }

    private fun cancelPortrait() {
        token++
        hideCard()
        clearPortrait()
        zoomView.compare = false
        zoomView.bmp2 = null
        zoomView.bmp = curBmp
    }

    private fun clearPortrait() {
        pFull = null
        pPreview = null
        pMask = null
        pSource = null
    }
}
