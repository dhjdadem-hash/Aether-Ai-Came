package com.aether.camera.ultra.ui

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import com.aether.camera.ultra.MainActivity
import com.aether.camera.ultra.media.MediaStorage

class SettingsScreen(private val act: MainActivity) : Screen {
    private val prefs = act.prefs
    private val root = FrameLayout(act)
    override val view: View = root
    private val header = LinearLayout(act)
    private val scroll = ScrollView(act)
    private val list = LinearLayout(act)
    private val values = ArrayList<Pair<TextView, () -> String>>()

    init {
        root.setBackgroundColor(Color.parseColor("#0B0B12"))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(act.dp(12), 0, act.dp(12), act.dp(8))
        val back = GlassIconButton(act, IconView.Kind.BACK, 42)
        back.icon.rotation = 180f
        back.onTap { act.close() }
        header.addView(back, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        val t = label(act, "الإعدادات", 20f, Color.WHITE, true)
        t.setPadding(act.dp(12), 0, 0, 0)
        header.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(header, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        list.orientation = LinearLayout.VERTICAL
        list.setPadding(act.dp(14), act.dp(8), act.dp(14), act.dp(30))
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        build()
    }

    override fun onInsets(top: Int, bottom: Int) {
        header.setPadding(act.dp(12), top + act.dp(6), act.dp(12), act.dp(8))
        header.post { scroll.setPadding(0, header.height, 0, bottom) ; scroll.clipToPadding = false }
    }

    override fun onResume() { refreshValues() }

    private fun section(title: String) {
        val t = label(act, title, 13f, K.CYAN, true)
        t.setPadding(act.dp(4), act.dp(18), act.dp(4), act.dp(6))
        list.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(act, 18f)
        c.setPadding(act.dp(14), act.dp(4), act.dp(14), act.dp(4))
        list.addView(c, LinearLayout.LayoutParams(MATCH, WRAP))
        return c
    }

    private fun choiceRow(parent: LinearLayout, title: String, options: List<String>, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, act.dp(12), 0, act.dp(12))
        row.addView(label(act, title, 15f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        val v = label(act, "", 14f, K.CYAN, true)
        row.addView(v, LinearLayout.LayoutParams(WRAP, WRAP))
        values.add(Pair(v, { options[get().coerceIn(0, options.size - 1)] }))
        row.setOnClickListener {
            AlertDialog.Builder(act).setTitle(title)
                .setSingleChoiceItems(options.toTypedArray(), get()) { d, which ->
                    set(which)
                    d.dismiss()
                    refreshValues()
                }.show()
        }
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, act.dp(10), 0, act.dp(10))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(act, title, 15f, Color.WHITE), LinearLayout.LayoutParams(MATCH, WRAP))
        if (sub.isNotEmpty()) col.addView(label(act, sub, 11f, K.WHITE55), LinearLayout.LayoutParams(MATCH, WRAP))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = SwitchCompat(act)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, on -> set(on) }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun actionRow(parent: LinearLayout, title: String, sub: String, onClick: () -> Unit) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(0, act.dp(12), 0, act.dp(12))
        row.addView(label(act, title, 15f, Color.WHITE), LinearLayout.LayoutParams(MATCH, WRAP))
        if (sub.isNotEmpty()) row.addView(label(act, sub, 11f, K.WHITE55), LinearLayout.LayoutParams(MATCH, WRAP))
        row.setOnClickListener { onClick() }
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun build() {
        section("التصوير")
        var c = card()
        choiceRow(c, "نسبة الأبعاد الافتراضية", listOf("4:3", "16:9", "1:1"), { prefs.aspect }, { prefs.aspect = it })
        choiceRow(c, "جودة JPEG", listOf("80", "90", "95", "100"),
            { when (prefs.jpegQuality) { 80 -> 0; 90 -> 1; 95 -> 2; else -> 3 } },
            { prefs.jpegQuality = when (it) { 0 -> 80; 1 -> 90; 2 -> 95; else -> 100 } })
        switchRow(c, "الشبكة", "خطوط الثلثين على المعاينة", { prefs.grid }, { prefs.grid = it })
        switchRow(c, "صوت الغالق", "", { prefs.shutterSound }, { prefs.shutterSound = it })
        choiceRow(c, "حد الزوم الأقصى", listOf("10x", "30x", "120x"),
            { when (prefs.maxZoom) { 10 -> 0; 30 -> 1; else -> 2 } },
            { prefs.maxZoom = when (it) { 0 -> 10; 1 -> 30; else -> 120 } })

        section("الذكاء الاصطناعي والألوان")
        c = card()
        switchRow(c, "AI Color تلقائيًا", "تصحيح لون محلي بعد كل التقاط (توازن أبيض + تباين + تشبع طبيعي)", { prefs.aiColor }, { prefs.aiColor = it })
        choiceRow(c, "قوة AI Color", listOf("خفيف", "طبيعي", "قوي"), { prefs.aiStrength }, { prefs.aiStrength = it })
        switchRow(c, "حفظ الأصل مع النسخة المعالَجة", "عند الإيقاف تُحفظ النسخة المعالَجة فقط", { prefs.saveOriginal }, { prefs.saveOriginal = it })

        section("الفيديو")
        c = card()
        choiceRow(c, "تثبيت الفيديو الافتراضي", listOf("إيقاف", "عادي", "نشط"), { prefs.stabMode }, { prefs.stabMode = it })

        section("الكاميرا الثانية و0.8x")
        c = card()
        actionRow(c, "تقرير قدرات الكاميرا", "فحص حقيقي لكل الكاميرات واختبار الكاميرا الثانية 2MP") { act.open(ReportScreen(act)) }
        actionRow(c, "إلغاء اختيار عدسة 0.8x اليدوي", "يعيد الاكتشاف التلقائي") {
            prefs.wideOverrideId = ""
            act.rescan()
            act.toast("أُعيد الاكتشاف التلقائي")
        }

        section("التخزين والخصوصية")
        c = card()
        actionRow(c, "إدارة التخزين", "اضغط لعرض المساحة") { showStorage() }
        actionRow(c, "الأذونات", "فتح إعدادات التطبيق في النظام") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.fromParts("package", act.packageName, null)
            act.startActivity(i)
        }
        actionRow(c, "الخصوصية", "كل المعالجة تتم على هاتفك. لا تُرسل أي صورة إلى أي خادم.") {}

        section("حول")
        c = card()
        actionRow(c, "AETHER Camera AI Ultra 2.0", "Camera2 · معالجة محلية · ML Kit للبورتريه") {}
        refreshValues()
    }

    private fun refreshValues() {
        for (p in values) p.first.text = p.second()
    }

    private fun showStorage() {
        Thread {
            val items = MediaStorage.list(act)
            var total = 0L
            for (i in items) total += i.size
            val free = MediaStorage.freeBytes()
            val trash = prefs.trashMap()
            act.runOnUiThread {
                AlertDialog.Builder(act).setTitle("التخزين")
                    .setMessage(
                        "ملفات AETHER: " + items.size + " (" + f1(total / 1048576f) + " MB)\n" +
                            "في سلة المحذوفات: " + trash.size + "\n" +
                            "المساحة الحرة على الجهاز: " + f1(free / 1073741824f) + " GB"
                    ).setPositiveButton("حسنًا", null).show()
            }
        }.start()
    }
}
