package com.aether.camera.ultra.camera

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.CamcorderProfile
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.util.Size
import com.aether.camera.ultra.ui.f1
import com.aether.camera.ultra.ui.f2
import java.util.Locale
import kotlin.math.atan
import kotlin.math.hypot

data class CamInfo(
    val id: String,
    val facing: Int,
    val sensorOrientation: Int,
    val focalMm: Float,
    val equivMm: Float,
    val fovDeg: Float,
    val sensorW: Float,
    val sensorH: Float,
    val pixelW: Int,
    val pixelH: Int,
    val megapixels: Float,
    val caps: List<Int>,
    val physicalIds: List<String>,
    val zoomMin: Float,
    val zoomMax: Float,
    val zoomRatioApi: Boolean,
    val maxDigital: Float,
    val minFocusDiopter: Float,
    val hasAf: Boolean,
    val isoMin: Int,
    val isoMax: Int,
    val expMinNs: Long,
    val expMaxNs: Long,
    val evMin: Int,
    val evMax: Int,
    val evStep: Float,
    val awbModes: List<Int>,
    val flash: Boolean,
    val eisModes: List<Int>,
    val oisModes: List<Int>,
    val nrModes: List<Int>,
    val sceneModes: List<Int>,
    val fpsRanges: List<Pair<Int, Int>>,
    val jpegSizes: List<Size>,
    val colorFilter: Int,
    val hardwareLevel: Int
) {
    val isFront: Boolean get() = facing == CameraCharacteristics.LENS_FACING_FRONT
    val isBack: Boolean get() = facing == CameraCharacteristics.LENS_FACING_BACK
    val isMono: Boolean get() = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME)
    val depthOnly: Boolean
        get() = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT) &&
            !caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)
    val manualSensor: Boolean get() = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
    val hasRaw: Boolean get() = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
    val isLogical: Boolean get() = physicalIds.size > 1
    val usable: Boolean get() = !depthOnly && jpegSizes.isNotEmpty()
    val maxJpeg: Size? get() = jpegSizes.maxByOrNull { it.width.toLong() * it.height }
    val previewStabilization: Boolean get() = eisModes.contains(2)
}

class VideoQ(val quality: Int, val label: String, val w: Int, val h: Int)

sealed class WideSource {
    object None : WideSource()
    class ZoomRatio(val minRatio: Float) : WideSource()
    class Cam(
        val cameraId: String,
        val physicalId: String?,
        val experimental: Boolean,
        val fovDeg: Float,
        val megapixels: Float
    ) : WideSource()
}

class ScanResult(
    val all: List<CamInfo>,
    val physical: Map<String, CamInfo>,
    val main: CamInfo?,
    val front: CamInfo?,
    val second: CamInfo?,
    val wide: WideSource,
    val wideNote: String
)

object DeviceScanner {

    private fun toList(a: IntArray?): List<Int> = a?.toList() ?: emptyList()

    fun describe(m: CameraManager, id: String): CamInfo = describe(id, m.getCameraCharacteristics(id))

    fun describe(id: String, c: CameraCharacteristics): CamInfo {
        val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
        val ss = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val sw = ss?.width ?: 0f
        val sh = ss?.height ?: 0f
        val diag = hypot(sw.toDouble(), sh.toDouble())
        val fov = if (focal > 0f && diag > 0.0) Math.toDegrees(2.0 * atan(diag / (2.0 * focal))).toFloat() else 0f
        val equiv = if (diag > 0.0) (focal * 43.27 / diag).toFloat() else 0f
        val pa = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
        val pw = pa?.width ?: 0
        val ph = pa?.height ?: 0
        var zMin = 1f
        var zMax = 1f
        var zApi = false
        if (Build.VERSION.SDK_INT >= 30) {
            val r = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (r != null) {
                zMin = r.lower
                zMax = r.upper
                zApi = true
            }
        }
        val maxDig = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
        if (!zApi) zMax = maxDig
        val af = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
        val hasAf = af?.any { it != CameraCharacteristics.CONTROL_AF_MODE_OFF } ?: false
        val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val ev = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val jpeg = map?.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        val fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?.map { Pair(it.lower, it.upper) } ?: emptyList()
        val phys: List<String> = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.toList() else emptyList()
        return CamInfo(
            id = id,
            facing = c.get(CameraCharacteristics.LENS_FACING) ?: CameraCharacteristics.LENS_FACING_BACK,
            sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90,
            focalMm = focal,
            equivMm = equiv,
            fovDeg = fov,
            sensorW = sw,
            sensorH = sh,
            pixelW = pw,
            pixelH = ph,
            megapixels = pw.toFloat() * ph.toFloat() / 1_000_000f,
            caps = toList(c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)),
            physicalIds = phys,
            zoomMin = zMin,
            zoomMax = zMax,
            zoomRatioApi = zApi,
            maxDigital = maxDig,
            minFocusDiopter = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
            hasAf = hasAf,
            isoMin = iso?.lower ?: 0,
            isoMax = iso?.upper ?: 0,
            expMinNs = exp?.lower ?: 0L,
            expMaxNs = exp?.upper ?: 0L,
            evMin = ev?.lower ?: 0,
            evMax = ev?.upper ?: 0,
            evStep = evStep,
            awbModes = toList(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)),
            flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false,
            eisModes = toList(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)),
            oisModes = toList(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)),
            nrModes = toList(c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)),
            sceneModes = toList(c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)),
            fpsRanges = fps,
            jpegSizes = jpeg,
            colorFilter = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: -1,
            hardwareLevel = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL) ?: -1
        )
    }

    fun videoQualities(id: String): List<VideoQ> {
        val n = id.toIntOrNull() ?: return emptyList()
        val out = ArrayList<VideoQ>()
        val defs = listOf(
            Pair(CamcorderProfile.QUALITY_8KUHD, "8K"),
            Pair(CamcorderProfile.QUALITY_2160P, "4K"),
            Pair(CamcorderProfile.QUALITY_1080P, "1080p"),
            Pair(CamcorderProfile.QUALITY_720P, "720p")
        )
        for (d in defs) {
            try {
                if (CamcorderProfile.hasProfile(n, d.first)) {
                    val p = CamcorderProfile.get(n, d.first)
                    if (p != null) out.add(VideoQ(d.first, d.second, p.videoFrameWidth, p.videoFrameHeight))
                }
            } catch (e: Exception) {
                // تجاهل
            }
        }
        return out
    }

    fun scan(ctx: Context, overrideId: String): ScanResult {
        val m = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val infos = ArrayList<CamInfo>()
        for (id in m.cameraIdList) {
            try { infos.add(describe(m, id)) } catch (e: Exception) { /* تجاهل */ }
        }
        val physical = HashMap<String, CamInfo>()
        for (i in infos) {
            for (pid in i.physicalIds) {
                if (infos.none { it.id == pid }) {
                    try { physical[pid] = describe(m, pid) } catch (e: Exception) { /* مخفية */ }
                }
            }
        }
        val backs = infos.filter { it.isBack && it.usable }
        val main = backs.maxByOrNull { it.megapixels }
        val front = infos.firstOrNull { it.isFront && it.usable }
        val others = backs.filter { it.id != main?.id }
        val second = others.minByOrNull { it.megapixels }

        var wide: WideSource = WideSource.None
        var note: String
        val mainFov = main?.fovDeg ?: 0f

        if (main == null) {
            note = "لا توجد كاميرا خلفية قابلة للاستخدام."
        } else if (Build.VERSION.SDK_INT >= 30 && main.zoomRatioApi && main.zoomMin <= 0.81f) {
            wide = WideSource.ZoomRatio(main.zoomMin)
            note = "الكاميرا الرئيسية تعلن نطاق زوم يبدأ من ${f2(main.zoomMin)}x، لذلك يمكن الوصول إلى 0.8x عبر الكاميرا المنطقية."
        } else {
            note = ""
            var found: WideSource.Cam? = null
            if (overrideId.isNotEmpty()) {
                val inList = infos.firstOrNull { it.id == overrideId }
                val inPhys = physical[overrideId]
                if (inList != null) {
                    found = WideSource.Cam(inList.id, null, true, inList.fovDeg, inList.megapixels)
                    note = "تم اختيار الكاميرا ${inList.id} يدويًا كعدسة 0.8x (تجريبي)."
                } else if (inPhys != null) {
                    val parent = infos.firstOrNull { it.physicalIds.contains(overrideId) }
                    if (parent != null) {
                        found = WideSource.Cam(parent.id, overrideId, true, inPhys.fovDeg, inPhys.megapixels)
                        note = "تم اختيار الكاميرا الفيزيائية $overrideId يدويًا كعدسة 0.8x (تجريبي)."
                    }
                }
            }
            if (found == null) {
                for (pid in main.physicalIds) {
                    val pi = physical[pid] ?: infos.firstOrNull { it.id == pid }
                    if (pi != null && pi.fovDeg > mainFov * 1.15f && !pi.isMono) {
                        val parent = main.id
                        found = WideSource.Cam(parent, pid, false, pi.fovDeg, pi.megapixels)
                        note = "وُجدت عدسة فيزيائية أوسع (مجال ${f1(pi.fovDeg)}° مقابل ${f1(mainFov)}°)."
                        break
                    }
                }
            }
            if (found == null) {
                for (o in others) {
                    if (o.fovDeg > mainFov * 1.12f && !o.isMono) {
                        found = WideSource.Cam(o.id, null, false, o.fovDeg, o.megapixels)
                        note = "الكاميرا ${o.id} (${f1(o.megapixels)}MP) مجال رؤيتها أوسع من الرئيسية (${f1(o.fovDeg)}° مقابل ${f1(mainFov)}°)."
                        break
                    }
                }
            }
            if (found != null) {
                wide = found
            } else {
                note = "لا توجد عدسة واسعة قابلة للوصول من التطبيقات."
                if (second != null) {
                    note += " الكاميرا ${second.id} (${f1(second.megapixels)}MP) مجالها ${f1(second.fovDeg)}° مقابل ${f1(mainFov)}° للرئيسية، فليست أوسع. " +
                        "يمكنك تجربتها يدويًا من «تقرير قدرات الكاميرا»."
                }
            }
        }
        return ScanResult(infos, physical, main, front, second, wide, note)
    }

    fun thermalText(ctx: Context): String {
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "طبيعية"
                PowerManager.THERMAL_STATUS_LIGHT -> "خفيفة"
                PowerManager.THERMAL_STATUS_MODERATE -> "متوسطة"
                PowerManager.THERMAL_STATUS_SEVERE -> "عالية"
                PowerManager.THERMAL_STATUS_CRITICAL -> "حرجة"
                else -> "مرتفعة جدًا"
            }
        } catch (e: Exception) {
            "غير متاحة"
        }
    }

    fun systemLines(ctx: Context): List<String> {
        val out = ArrayList<String>()
        out.add("الجهاز: ${Build.MANUFACTURER} ${Build.MODEL}")
        out.add("أندرويد ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            out.add("الذاكرة: ${mi.totalMem / (1024L * 1024L)}MB (متاح ${mi.availMem / (1024L * 1024L)}MB)")
        } catch (e: Exception) { /* تجاهل */ }
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            out.add("التخزين الحر: ${st.availableBytes / (1024L * 1024L)}MB")
        } catch (e: Exception) { /* تجاهل */ }
        out.add("حرارة الجهاز: ${thermalText(ctx)}")
        return out
    }

    fun capName(c: Int): String = when (c) {
        0 -> "BACKWARD_COMPATIBLE"
        1 -> "MANUAL_SENSOR"
        2 -> "MANUAL_POST_PROCESSING"
        3 -> "RAW"
        6 -> "BURST_CAPTURE"
        8 -> "DEPTH_OUTPUT"
        9 -> "HIGH_SPEED_VIDEO"
        11 -> "LOGICAL_MULTI_CAMERA"
        12 -> "MONOCHROME"
        16 -> "ULTRA_HIGH_RES_SENSOR"
        18 -> "10BIT_VIDEO"
        else -> "CAP_$c"
    }

    fun facingName(f: Int): String = when (f) {
        CameraCharacteristics.LENS_FACING_FRONT -> "أمامية"
        CameraCharacteristics.LENS_FACING_BACK -> "خلفية"
        else -> "خارجية"
    }

    @Suppress("unused")
    fun fmtShutter(ns: Long): String {
        if (ns <= 0L) return "-"
        val s = ns / 1_000_000_000.0
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/" + Math.round(1.0 / s)
    }
}
