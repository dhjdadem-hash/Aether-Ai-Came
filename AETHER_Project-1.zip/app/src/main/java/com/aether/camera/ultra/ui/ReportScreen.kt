package com.aether.camera.ultra.ui

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.aether.camera.ultra.MainActivity
import com.aether.camera.ultra.camera.CamInfo
import com.aether.camera.ultra.camera.CameraProbe
import com.aether.camera.ultra.camera.DeviceScanner
import com.aether.camera.ultra.camera.ScanResult
import com.aether.camera.ultra.camera.WideSource
import java.util.Locale

class ReportScreen(private val act: MainActivity) : Screen {
    private val root = FrameLayout(act)
    override val view: View = root
    private val header = LinearLayout(act)
    private val scroll = ScrollView(act)
    private val list = LinearLayout(act)
    private val fullText = StringBuilder()

    init {
        root.setBackgroundColor(Color.parseColor("#0B0B12"))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(act.dp(12), 0, act.dp(12), act.dp(8))
        val back = GlassIconButton(act, IconView.Kind.BACK, 42)
        back.icon.rotation = 180f
        back.onTap { act.close() }
        header.addView(back, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        val t = label(act, "تقرير قدرات الكاميرا", 19f, Color.WHITE, true)
        t.setPadding(act.dp(12), 0, act.dp(12), 0)
        header.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val share = GlassIconButton(act, IconView.Kind.SHARE, 42)
        share.onTap { shareReport() }
        header.addView(share, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        root.addView(header, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        list.orientation = LinearLayout.VERTICAL
        list.setPadding(act.dp(14), act.dp(8), act.dp(14), act.dp(30))
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        build()
    }

    override fun onInsets(top: Int, bottom: Int) {
        header.setPadding(act.dp(12), top + act.dp(6), act.dp(12), act.dp(8))
        header.post { scroll.setPadding(0, header.height, 0, bottom); scroll.clipToPadding = false }
    }

    private fun card(title: String, body: String): LinearLayout {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(act, 18f)
        c.setPadding(act.dp(14), act.dp(12), act.dp(14), act.dp(12))
        c.addView(label(act, title, 15f, K.CYAN, true), LinearLayout.LayoutParams(MATCH, WRAP))
        val b = label(act, body, 12.5f, Color.WHITE)
        b.setTextIsSelectable(true)
        b.setPadding(0, act.dp(6), 0, 0)
        c.addView(b, LinearLayout.LayoutParams(MATCH, WRAP))
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.bottomMargin = act.dp(12)
        list.addView(c, p)
        fullText.append("== ").append(title).append(" ==\n").append(body).append("\n\n")
        return c
    }

    private fun yn(b: Boolean) = if (b) "نعم" else "لا"

    private fun camBody(i: CamInfo): String {
        val sb = StringBuilder()
        sb.append("الدقة: ").append(i.pixelW).append('×').append(i.pixelH).append(" (").append(f1(i.megapixels)).append("MP)\n")
        sb.append("البعد البؤري: ").append(f2(i.focalMm)).append("mm (≈").append(f1(i.equivMm)).append("mm مكافئ) · مجال الرؤية القطري: ").append(f1(i.fovDeg)).append("°\n")
        sb.append("المستشعر: ").append(f2(i.sensorW)).append('×').append(f2(i.sensorH)).append("mm\n")
        sb.append("منطقية: ").append(yn(i.isLogical)).append(" · فيزيائية: ").append(if (i.physicalIds.isEmpty()) "-" else i.physicalIds.joinToString(",")).append('\n')
        sb.append("الزوم: ").append(f2(i.zoomMin)).append("x → ").append(f1(i.zoomMax)).append("x")
        sb.append(if (i.zoomRatioApi) " (CONTROL_ZOOM_RATIO)" else " (قص رقمي)").append('\n')
        sb.append("التركيز: ").append(if (i.hasAf) "تلقائي" else "ثابت").append(" · أقرب تركيز: ")
        sb.append(if (i.minFocusDiopter > 0f) f1(100f / i.minFocusDiopter) + "سم" else "غير معروف").append('\n')
        sb.append("ISO: ").append(i.isoMin).append('–').append(i.isoMax).append(" · الغالق: ")
        sb.append(DeviceScanner.fmtShutter(i.expMinNs)).append(" – ").append(DeviceScanner.fmtShutter(i.expMaxNs)).append('\n')
        sb.append("EV: ").append(i.evMin).append("..").append(i.evMax).append(" (خطوة ").append(f2(i.evStep)).append(")\n")
        sb.append("فلاش LED: ").append(yn(i.flash)).append('\n')
        sb.append("تثبيت: EIS ").append(yn(i.eisModes.contains(1))).append(" · OIS ").append(yn(i.oisModes.contains(1)))
        sb.append(" · تثبيت المعاينة ").append(yn(i.previewStabilization)).append('\n')
        sb.append("مصفوفة الألوان: ").append(if (i.isMono) "أحادية اللون (Monochrome)" else "ملوّنة (رمز ${i.colorFilter})").append('\n')
        sb.append("RAW: ").append(yn(i.hasRaw)).append(" · تحكم يدوي بالمستشعر: ").append(yn(i.manualSensor)).append('\n')
        val mj = i.maxJpeg
        sb.append("أكبر JPEG: ").append(if (mj != null) mj.width.toString() + "×" + mj.height else "-").append('\n')
        sb.append("القدرات: ").append(i.caps.joinToString(", ") { DeviceScanner.capName(it) }).append('\n')
        val vq = DeviceScanner.videoQualities(i.id)
        sb.append("الفيديو المدعوم: ").append(if (vq.isEmpty()) "لا شيء" else vq.joinToString(" · ") { it.label + " (" + it.w + "×" + it.h + ")" }).append('\n')
        val fr = i.fpsRanges.map { it.first.toString() + "-" + it.second }.distinct()
        sb.append("نطاقات الإطارات: ").append(fr.joinToString(" | "))
        return sb.toString()
    }

    private fun build() {
        val sc: ScanResult = act.scan ?: run { act.rescan(); act.scan } ?: return
        card("الجهاز", DeviceScanner.systemLines(act).joinToString("\n"))

        val w = sc.wide
        val kind = when (w) {
            is WideSource.ZoomRatio -> "الحالة: 0.8x متاحة عبر الكاميرا المنطقية (zoomRatio)"
            is WideSource.Cam -> "الحالة: 0.8x عبر الكاميرا " + w.cameraId + (if (w.physicalId != null) " (فيزيائية " + w.physicalId + ")" else "") +
                (if (w.experimental) " — اختيار يدوي تجريبي" else " — عدسة أوسع مكتشفة")
            else -> "الحالة: لا توجد عدسة واسعة قابلة للوصول"
        }
        card("نتيجة فحص 0.8x", kind + "\n" + sc.wideNote)

        for (i in sc.all) {
            val title = "كاميرا " + i.id + " — " + DeviceScanner.facingName(i.facing) +
                (if (i.id == sc.main?.id) " (الرئيسية)" else "") + (if (i.id == sc.second?.id) " (الثانية)" else "")
            val c = card(title, camBody(i))
            if (i.isBack) addTestBlock(c, i.id, null, i)
        }
        for ((pid, pi) in sc.physical) {
            val parent = sc.all.firstOrNull { it.physicalIds.contains(pid) }
            val c = card("كاميرا فيزيائية " + pid + " (داخل المنطقية " + (parent?.id ?: "?") + ")", camBody(pi))
            if (parent != null) addTestBlock(c, parent.id, pid, pi)
        }
    }

    private fun addTestBlock(c: LinearLayout, camId: String, physId: String?, info: CamInfo) {
        val result = label(act, "", 12.5f, Color.WHITE)
        result.setPadding(0, act.dp(8), 0, 0)
        val img = ImageView(act)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        val test = chip(act, "اختبار هذه الكاميرا", true)
        val use = chip(act, "اعتمدها كعدسة 0.8x (تجريبي)")
        use.visibility = View.GONE
        val p1 = LinearLayout.LayoutParams(WRAP, WRAP)
        p1.marginEnd = act.dp(8)
        row.addView(test, p1)
        row.addView(use, LinearLayout.LayoutParams(WRAP, WRAP))
        val hp = LinearLayout.LayoutParams(MATCH, WRAP)
        hp.topMargin = act.dp(10)
        c.addView(row, hp)
        c.addView(result, LinearLayout.LayoutParams(MATCH, WRAP))
        c.addView(img, LinearLayout.LayoutParams(act.dp(160), act.dp(120)).also { it.topMargin = act.dp(8) })

        test.setOnClickListener {
            test.text = "جارٍ الاختبار…"
            result.text = ""
            Thread {
                val r = CameraProbe.probe(act, camId, physId)
                act.runOnUiThread {
                    test.text = "اختبار هذه الكاميرا"
                    if (!r.ok) {
                        result.text = "فشل الاختبار: " + r.error
                        fullText.append("اختبار ").append(camId).append(": فشل — ").append(r.error).append("\n")
                    } else {
                        img.setImageBitmap(r.thumb)
                        img.visibility = View.VISIBLE
                        val colorTxt = if (r.grayish) "باهتة/رمادية تقريبًا (تشبع " + f2(r.avgSat) + ")" else "ملوّنة (تشبع " + f2(r.avgSat) + ")"
                        val txt = "نجح الفتح والتقاط إطار " + r.width + "×" + r.height + "\n" +
                            "الألوان: " + colorTxt + "\n" +
                            "السطوع: " + f2(r.avgLuma) + " · الحدة: " + f1(r.sharp) + "\n" +
                            "مجال الرؤية: " + f1(info.fovDeg) + "° مقابل " + f1(act.scan?.main?.fovDeg ?: 0f) + "° للرئيسية"
                        result.text = txt
                        fullText.append("اختبار ").append(camId).append(": ").append(txt.replace('\n', ' ')).append("\n")
                        use.visibility = View.VISIBLE
                    }
                }
            }.start()
        }
        use.setOnClickListener {
            act.prefs.wideOverrideId = physId ?: camId
            act.rescan()
            act.toast("تم اعتماد الكاميرا " + (physId ?: camId) + " كعدسة 0.8x. سيُطبَّق AI Color تلقائيًا عليها.")
        }
    }

    private fun shareReport() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, "تقرير AETHER Camera\n\n" + fullText.toString())
        act.startActivity(Intent.createChooser(i, "مشاركة التقرير"))
    }

    @Suppress("unused")
    private fun unusedLocale(): Locale = Locale.US

    @Suppress("unused")
    private fun unusedTv(t: TextView) = t
}
