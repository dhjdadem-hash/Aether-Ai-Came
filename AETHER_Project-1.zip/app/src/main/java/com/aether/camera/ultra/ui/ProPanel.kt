package com.aether.camera.ultra.ui

import android.content.Context
import android.graphics.Color
import android.hardware.camera2.CaptureRequest
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.aether.camera.ultra.camera.CamInfo
import com.aether.camera.ultra.camera.CameraEngine
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/** لوحة التحكم اليدوي: كل شريط يغيّر إعداد الالتقاط الحقيقي في Camera2. */
class ProPanel(private val ctx: Context, private val engine: CameraEngine) {
    val view = LinearLayout(ctx)

    private var info: CamInfo? = null
    private val tabNames = listOf("ISO", "SS", "FOCUS", "WB", "EV")
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private val seek = SeekBar(ctx)
    private val valueText = label(ctx, "", 13f, Color.WHITE, true)
    private val autoChip = chip(ctx, "AUTO", true)
    private val note = label(ctx, "", 11f, K.WHITE55)

    private var isoP = 300
    private var expP = 500
    private var focP = 0
    private var wbIdx = 0
    private var evIdx = 0
    private var isoAuto = true
    private var expAuto = true
    private var focAuto = true
    private var wbModes: List<Int> = listOf(CaptureRequest.CONTROL_AWB_MODE_AUTO)
    private var updating = false

    init {
        view.orientation = LinearLayout.VERTICAL
        view.background = glass(ctx, 20f, true)
        view.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
        val tabs = LinearLayout(ctx)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER
        for (i in tabNames.indices) {
            val t = label(ctx, tabNames[i], 13f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6))
            t.setOnClickListener { selectTab(i) }
            tabViews.add(t)
            tabs.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        view.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(valueText, LinearLayout.LayoutParams(ctx.dp(84), WRAP))
        row.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(autoChip, LinearLayout.LayoutParams(WRAP, WRAP))
        view.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        view.addView(note, LinearLayout.LayoutParams(MATCH, WRAP))
        seek.max = 1000
        seek.progressTintList = android.content.res.ColorStateList.valueOf(K.CYAN)
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(K.CYAN)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && !updating) onSeek(p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        autoChip.setOnClickListener { toggleAuto() }
        selectTab(0)
    }

    fun bind(i: CamInfo) {
        info = i
        wbModes = i.awbModes.filter { it in 1..8 }.ifEmpty { listOf(CaptureRequest.CONTROL_AWB_MODE_AUTO) }
        resetAll()
        selectTab(tab)
    }

    fun resetAll() {
        isoAuto = true; expAuto = true; focAuto = true; wbIdx = 0; evIdx = 0
        engine.manualIso = -1
        engine.manualExpNs = -1L
        engine.manualFocus = -1f
        engine.wbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO
        engine.evIndex = 0
    }

    private fun isoValue(p: Int): Int {
        val i = info ?: return 100
        val lo = max(1, i.isoMin).toDouble()
        val hi = max(lo, i.isoMax.toDouble())
        return (lo * (hi / lo).pow(p / 1000.0)).roundToInt()
    }

    private fun expValue(p: Int): Long {
        val i = info ?: return 16_666_666L
        val lo = max(1L, i.expMinNs).toDouble()
        val hi = max(lo, minOf(i.expMaxNs, 2_000_000_000L).toDouble())
        return (lo * (hi / lo).pow(p / 1000.0)).toLong()
    }

    private fun shutterText(ns: Long): String {
        val s = ns / 1_000_000_000.0
        return if (s >= 0.4) f1(s.toFloat()) + "s" else "1/" + Math.round(1.0 / s)
    }

    private fun wbName(m: Int): String = when (m) {
        CaptureRequest.CONTROL_AWB_MODE_AUTO -> "تلقائي"
        CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT -> "متوهج"
        CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT -> "فلورسنت"
        CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT -> "فلورسنت دافئ"
        CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT -> "نهار"
        CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT -> "غائم"
        CaptureRequest.CONTROL_AWB_MODE_TWILIGHT -> "غروب"
        CaptureRequest.CONTROL_AWB_MODE_SHADE -> "ظل"
        else -> "وضع $m"
    }

    private fun selectTab(i: Int) {
        tab = i
        for (k in tabViews.indices) {
            tabViews[k].setTextColor(if (k == i) K.CYAN else Color.WHITE)
        }
        val inf = info
        updating = true
        note.text = ""
        autoChip.visibility = View.VISIBLE
        seek.isEnabled = true
        when (i) {
            0 -> {
                seek.progress = isoP
                if (inf != null && !inf.manualSensor) { seek.isEnabled = false; note.text = "ISO اليدوي غير مدعوم في هذه الكاميرا" }
                else if (!isoAuto && expAuto) note.text = "زمن الغالق يبقى على آخر قيمة تلقائية"
            }
            1 -> {
                seek.progress = expP
                if (inf != null && !inf.manualSensor) { seek.isEnabled = false; note.text = "الغالق اليدوي غير مدعوم في هذه الكاميرا" }
                else if (!expAuto && isoAuto) note.text = "ISO يبقى على آخر قيمة تلقائية"
            }
            2 -> {
                seek.progress = focP
                if (inf != null && inf.minFocusDiopter <= 0f) { seek.isEnabled = false; note.text = "الكاميرا ذات تركيز ثابت" }
            }
            3 -> {
                seek.max = max(1, wbModes.size - 1)
                seek.progress = wbIdx
                autoChip.visibility = View.GONE
            }
            else -> {
                val e = inf
                if (e != null && e.evMax > e.evMin) {
                    seek.max = e.evMax - e.evMin
                    seek.progress = evIdx - e.evMin
                } else {
                    seek.isEnabled = false
                    note.text = "تعويض التعريض غير مدعوم"
                }
                autoChip.visibility = View.GONE
            }
        }
        if (i != 3 && i != 4) seek.max = 1000
        if (i == 0 || i == 1 || i == 2) seek.progress = when (i) { 0 -> isoP; 1 -> expP; else -> focP }
        updating = false
        refreshText()
    }

    private fun refreshText() {
        val inf = info
        autoChip.setTextColor(
            when (tab) {
                0 -> if (isoAuto) K.CYAN else Color.WHITE
                1 -> if (expAuto) K.CYAN else Color.WHITE
                2 -> if (focAuto) K.CYAN else Color.WHITE
                else -> Color.WHITE
            }
        )
        valueText.text = when (tab) {
            0 -> if (isoAuto) "ISO تلقائي" else "ISO " + isoValue(isoP)
            1 -> if (expAuto) "غالق تلقائي" else shutterText(expValue(expP))
            2 -> if (focAuto || inf == null || inf.minFocusDiopter <= 0f) "تركيز تلقائي"
                 else if (focP <= 5) "لانهائي"
                 else f2(1f / max(0.01f, inf.minFocusDiopter * focP / 1000f)) + "م"
            3 -> wbName(wbModes.getOrElse(wbIdx) { CaptureRequest.CONTROL_AWB_MODE_AUTO })
            else -> if (inf == null) "EV" else "EV " + f1(evIdx * inf.evStep)
        }
    }

    private fun onSeek(p: Int) {
        val inf = info
        when (tab) {
            0 -> { isoP = p; isoAuto = false; engine.manualIso = isoValue(p) }
            1 -> { expP = p; expAuto = false; engine.manualExpNs = expValue(p) }
            2 -> {
                focP = p; focAuto = false
                if (inf != null) engine.manualFocus = inf.minFocusDiopter * p / 1000f
            }
            3 -> { wbIdx = p; engine.wbMode = wbModes.getOrElse(p) { CaptureRequest.CONTROL_AWB_MODE_AUTO } }
            else -> {
                if (inf != null) { evIdx = p + inf.evMin; engine.evIndex = evIdx }
            }
        }
        refreshText()
        engine.refresh()
    }

    private fun toggleAuto() {
        when (tab) {
            0 -> { isoAuto = true; engine.manualIso = -1 }
            1 -> { expAuto = true; engine.manualExpNs = -1L }
            2 -> { focAuto = true; engine.manualFocus = -1f }
            else -> {}
        }
        refreshText()
        selectTabKeep()
        engine.refresh()
    }

    private fun selectTabKeep() {
        val inf = info
        if (tab == 0 && inf != null) note.text = if (!inf.manualSensor) "ISO اليدوي غير مدعوم في هذه الكاميرا" else ""
        if (tab == 1 && inf != null) note.text = if (!inf.manualSensor) "الغالق اليدوي غير مدعوم في هذه الكاميرا" else ""
    }
}
