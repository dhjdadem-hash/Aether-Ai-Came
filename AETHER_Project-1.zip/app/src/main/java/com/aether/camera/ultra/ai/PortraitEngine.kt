package com.aether.camera.ultra.ai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** بورتريه: عزل الشخص بنموذج ML Kit محلي ثم تمويه الخلفية فعليًا. */
object PortraitEngine {

    class Mask(val w: Int, val h: Int, val data: FloatArray, val coverage: Float)

    /** يُستدعى خارج الخيط الرئيسي. يعيد القناع أو null مع نص الخطأ في [error]. */
    fun segment(src: Bitmap, errorOut: Array<String?>): Mask? {
        val sc = min(1f, 640f / max(src.width, src.height).toFloat())
        val small = Bitmap.createScaledBitmap(src, max(2, (src.width * sc).toInt()), max(2, (src.height * sc).toInt()), true)
        val opts = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        val seg = Segmentation.getClient(opts)
        val latch = CountDownLatch(1)
        var result: com.google.mlkit.vision.segmentation.SegmentationMask? = null
        var err: String? = null
        try {
            seg.process(InputImage.fromBitmap(small, 0))
                .addOnSuccessListener { m -> result = m; latch.countDown() }
                .addOnFailureListener { e -> err = e.message ?: "فشل التقسيم"; latch.countDown() }
            latch.await(20, TimeUnit.SECONDS)
        } catch (e: Exception) {
            err = e.message
        }
        val m = result
        try { seg.close() } catch (e: Exception) { /* تجاهل */ }
        if (small !== src) small.recycle()
        if (m == null) {
            errorOut[0] = err ?: "انتهت مهلة اكتشاف الشخص"
            return null
        }
        val mw = m.width
        val mh = m.height
        val buf = m.buffer
        buf.rewind()
        val data = FloatArray(mw * mh)
        var fg = 0
        for (i in data.indices) {
            val v = buf.getFloat()
            data[i] = v
            if (v > 0.5f) fg++
        }
        val cov = fg.toFloat() / data.size.toFloat()
        if (cov < 0.02f) {
            errorOut[0] = "لم يتم اكتشاف شخص واضح في الصورة"
            return null
        }
        return Mask(mw, mh, data, cov)
    }

    private fun smooth(v: Float): Float {
        val t = ((v - 0.3f) / 0.4f).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun sample(mk: Mask, u: Float, v: Float): Float {
        val fx = u * (mk.w - 1)
        val fy = v * (mk.h - 1)
        val x0 = floor(fx).toInt().coerceIn(0, mk.w - 1)
        val y0 = floor(fy).toInt().coerceIn(0, mk.h - 1)
        val x1 = min(x0 + 1, mk.w - 1)
        val y1 = min(y0 + 1, mk.h - 1)
        val ax = fx - x0
        val ay = fy - y0
        val a = mk.data[y0 * mk.w + x0] * (1 - ax) + mk.data[y0 * mk.w + x1] * ax
        val b = mk.data[y1 * mk.w + x0] * (1 - ax) + mk.data[y1 * mk.w + x1] * ax
        return smooth(a * (1 - ay) + b * ay)
    }

    private fun boxBlur(src: IntArray, w: Int, h: Int, r: Int): IntArray {
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        val d = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = src[row + i.coerceIn(0, w - 1)]
                sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (x in 0 until w) {
                tmp[row + x] = (0xFF shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val a = src[row + min(x + r + 1, w - 1)]
                val b = src[row + max(x - r, 0)]
                sr += ((a shr 16) and 255) - ((b shr 16) and 255)
                sg += ((a shr 8) and 255) - ((b shr 8) and 255)
                sb += (a and 255) - (b and 255)
            }
        }
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = tmp[i.coerceIn(0, h - 1) * w + x]
                sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (y in 0 until h) {
                out[y * w + x] = (0xFF shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val a = tmp[min(y + r + 1, h - 1) * w + x]
                val b = tmp[max(y - r, 0) * w + x]
                sr += ((a shr 16) and 255) - ((b shr 16) and 255)
                sg += ((a shr 8) and 255) - ((b shr 8) and 255)
                sb += (a and 255) - (b and 255)
            }
        }
        return out
    }

    /** strength من 0 إلى 1. */
    fun render(src: Bitmap, mask: Mask, strength: Float, progress: (Int) -> Unit = {}): Bitmap {
        val w = src.width
        val h = src.height
        progress(5)
        val sc = min(1f, 720f / max(w, h).toFloat())
        val bw = max(4, (w * sc).toInt())
        val bh = max(4, (h * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, bw, bh, true)
        var arr = IntArray(bw * bh)
        small.getPixels(arr, 0, bw, 0, 0, bw, bh)
        if (small !== src) small.recycle()
        val radius = max(1, (2f + strength * 18f * (bw / 720f)).toInt())
        for (k in 0 until 3) {
            arr = boxBlur(arr, bw, bh, radius)
            progress(10 + k * 20)
        }
        val bs = Bitmap.createBitmap(arr, bw, bh, Bitmap.Config.ARGB_8888)
        val big = Bitmap.createScaledBitmap(bs, w, h, true)
        if (big !== bs) bs.recycle()
        val bigPx = IntArray(w * h)
        big.getPixels(bigPx, 0, w, 0, 0, w, h)
        if (big !== src) big.recycle()
        progress(75)
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (y in 0 until h) {
            val v = y.toFloat() / max(1, h - 1).toFloat()
            val row = y * w
            for (x in 0 until w) {
                val m = sample(mask, x.toFloat() / max(1, w - 1).toFloat(), v)
                if (m >= 0.999f) continue
                val i = row + x
                val a = px[i]
                val b = bigPx[i]
                val inv = 1f - m
                val r = (((a shr 16) and 255) * m + ((b shr 16) and 255) * inv).toInt()
                val g = (((a shr 8) and 255) * m + ((b shr 8) and 255) * inv).toInt()
                val bl = ((a and 255) * m + (b and 255) * inv).toInt()
                px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
            if (y % 128 == 0) progress(75 + 24 * y / h)
        }
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        progress(100)
        return out
    }
}
