package com.aether.camera.ultra.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val MATCH: Int = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP: Int = ViewGroup.LayoutParams.WRAP_CONTENT

object K {
    val CYAN: Int = Color.parseColor("#4FE3FF")
    val VIOLET: Int = Color.parseColor("#9B7BFF")
    val WHITE80: Int = Color.parseColor("#CCFFFFFF")
    val WHITE55: Int = Color.parseColor("#8CFFFFFF")
    val GLASS_TOP: Int = Color.parseColor("#47FFFFFF")
    val GLASS_BOT: Int = Color.parseColor("#14FFFFFF")
    val GLASS_STROKE: Int = Color.parseColor("#59FFFFFF")
    val DARK_TOP: Int = Color.parseColor("#C0181820")
    val DARK_BOT: Int = Color.parseColor("#A0101018")
    val PANEL: Int = Color.parseColor("#F20B0B12")
    val RED: Int = Color.parseColor("#FF3B30")
    val YELLOW: Int = Color.parseColor("#FFD60A")
    val GREEN: Int = Color.parseColor("#30D158")
    val SCRIM: Int = Color.parseColor("#99000000")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun View.dp(v: Int): Int = context.dp(v)
fun View.dpf(v: Float): Float = context.dpf(v)

fun f1(v: Float): String = String.format(Locale.US, "%.1f", v)
fun f2(v: Float): String = String.format(Locale.US, "%.2f", v)

fun glass(ctx: Context, radiusDp: Float = 22f, dark: Boolean = false, selected: Boolean = false): Drawable {
    val colors = if (dark) intArrayOf(K.DARK_TOP, K.DARK_BOT) else intArrayOf(K.GLASS_TOP, K.GLASS_BOT)
    val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
    g.cornerRadius = ctx.dpf(radiusDp)
    g.setStroke(ctx.dp(1), if (selected) K.CYAN else K.GLASS_STROKE)
    return g
}

fun label(ctx: Context, text: String, sizeSp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
    val t = TextView(ctx)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

fun View.onTap(action: () -> Unit) {
    setOnClickListener {
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        action()
    }
}

fun chip(ctx: Context, text: String, selected: Boolean = false): TextView {
    val t = label(ctx, text, 13f, if (selected) K.CYAN else Color.WHITE, selected)
    t.gravity = Gravity.CENTER
    t.setPadding(ctx.dp(14), ctx.dp(7), ctx.dp(14), ctx.dp(7))
    t.background = glass(ctx, 18f, false, selected)
    return t
}

class IconView(ctx: Context, initial: Kind) : View(ctx) {
    enum class Kind {
        BOLT, BOLT_AUTO, BOLT_OFF, BOLT_TORCH, FLIP, GEAR, TIMER, BACK, CLOSE, SHARE,
        HEART, HEART_FILL, TRASH, INFO, WAND, COMPARE, CHECK, PLAY, SLIDERS, GRID, UNDO, PORTRAIT
    }

    var kind: Kind = initial
        set(v) { field = v; invalidate() }
    var tint: Int = Color.WHITE
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width - paddingLeft - paddingRight
        val h = height - paddingTop - paddingBottom
        val s = min(w, h).toFloat()
        if (s <= 0f) return
        canvas.save()
        canvas.translate(paddingLeft + (w - s) / 2f, paddingTop + (h - s) / 2f)
        val u = s / 24f
        canvas.scale(u, u)
        p.color = tint
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.9f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        tp.color = tint
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        path.reset()
        when (kind) {
            Kind.BOLT, Kind.BOLT_AUTO, Kind.BOLT_OFF, Kind.BOLT_TORCH -> {
                path.moveTo(13f, 2.5f); path.lineTo(5.5f, 13.5f); path.lineTo(11f, 13.5f)
                path.lineTo(10f, 21.5f); path.lineTo(18.5f, 10f); path.lineTo(13f, 10f); path.close()
                if (kind == Kind.BOLT_TORCH) p.style = Paint.Style.FILL_AND_STROKE
                canvas.drawPath(path, p)
                p.style = Paint.Style.STROKE
                if (kind == Kind.BOLT_AUTO) { tp.textSize = 9f; canvas.drawText("A", 19f, 8.5f, tp) }
                if (kind == Kind.BOLT_OFF) canvas.drawLine(4f, 4f, 20f, 20f, p)
            }
            Kind.FLIP -> {
                canvas.drawLine(4f, 8f, 20f, 8f, p); canvas.drawLine(16f, 4f, 20f, 8f, p); canvas.drawLine(16f, 12f, 20f, 8f, p)
                canvas.drawLine(20f, 16f, 4f, 16f, p); canvas.drawLine(8f, 12f, 4f, 16f, p); canvas.drawLine(8f, 20f, 4f, 16f, p)
            }
            Kind.GEAR -> {
                canvas.drawCircle(12f, 12f, 3.2f, p)
                canvas.drawCircle(12f, 12f, 7f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cx = cos(a).toFloat()
                    val sn = sin(a).toFloat()
                    canvas.drawLine(12f + cx * 7f, 12f + sn * 7f, 12f + cx * 9.8f, 12f + sn * 9.8f, p)
                }
            }
            Kind.TIMER -> {
                canvas.drawCircle(12f, 13.5f, 7.5f, p)
                canvas.drawLine(12f, 13.5f, 12f, 9.5f, p)
                canvas.drawLine(9.5f, 3f, 14.5f, 3f, p)
            }
            Kind.BACK -> {
                path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f)
                canvas.drawPath(path, p)
            }
            Kind.CLOSE -> {
                canvas.drawLine(6f, 6f, 18f, 18f, p); canvas.drawLine(18f, 6f, 6f, 18f, p)
            }
            Kind.SHARE -> {
                canvas.drawCircle(18f, 5f, 2.5f, p); canvas.drawCircle(6f, 12f, 2.5f, p); canvas.drawCircle(18f, 19f, 2.5f, p)
                canvas.drawLine(8.2f, 10.8f, 15.8f, 6.2f, p); canvas.drawLine(8.2f, 13.2f, 15.8f, 17.8f, p)
            }
            Kind.HEART, Kind.HEART_FILL -> {
                path.moveTo(12f, 20.5f)
                path.cubicTo(5f, 15f, 3f, 10.5f, 5.3f, 7.2f)
                path.cubicTo(7.3f, 4.5f, 11f, 5f, 12f, 8.2f)
                path.cubicTo(13f, 5f, 16.7f, 4.5f, 18.7f, 7.2f)
                path.cubicTo(21f, 10.5f, 19f, 15f, 12f, 20.5f)
                path.close()
                if (kind == Kind.HEART_FILL) { p.color = K.RED; p.style = Paint.Style.FILL_AND_STROKE }
                canvas.drawPath(path, p)
            }
            Kind.TRASH -> {
                canvas.drawRoundRect(RectF(6f, 8f, 18f, 20.5f), 2f, 2f, p)
                canvas.drawLine(4f, 6f, 20f, 6f, p)
                path.moveTo(9f, 6f); path.lineTo(9f, 3.5f); path.lineTo(15f, 3.5f); path.lineTo(15f, 6f)
                canvas.drawPath(path, p)
                canvas.drawLine(10f, 11f, 10f, 17f, p); canvas.drawLine(14f, 11f, 14f, 17f, p)
            }
            Kind.INFO -> {
                canvas.drawCircle(12f, 12f, 9f, p)
                canvas.drawLine(12f, 11f, 12f, 17f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(12f, 7.6f, 1.2f, p)
                p.style = Paint.Style.STROKE
            }
            Kind.WAND -> {
                path.moveTo(12f, 3f); path.lineTo(14.2f, 9.8f); path.lineTo(21f, 12f); path.lineTo(14.2f, 14.2f)
                path.lineTo(12f, 21f); path.lineTo(9.8f, 14.2f); path.lineTo(3f, 12f); path.lineTo(9.8f, 9.8f); path.close()
                canvas.drawPath(path, p)
            }
            Kind.COMPARE -> {
                canvas.drawRoundRect(RectF(3.5f, 5f, 20.5f, 19f), 2.5f, 2.5f, p)
                canvas.drawLine(12f, 5f, 12f, 19f, p)
                p.style = Paint.Style.FILL
                p.alpha = 110
                canvas.drawRect(RectF(4.5f, 6f, 12f, 18f), p)
                p.style = Paint.Style.STROKE
            }
            Kind.CHECK -> {
                path.moveTo(5f, 12.5f); path.lineTo(10f, 17.5f); path.lineTo(19f, 7f)
                canvas.drawPath(path, p)
            }
            Kind.PLAY -> {
                path.moveTo(8f, 5f); path.lineTo(19f, 12f); path.lineTo(8f, 19f); path.close()
                p.style = Paint.Style.FILL
                canvas.drawPath(path, p)
            }
            Kind.SLIDERS -> {
                canvas.drawLine(4f, 7f, 20f, 7f, p); canvas.drawLine(4f, 12f, 20f, 12f, p); canvas.drawLine(4f, 17f, 20f, 17f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(9f, 7f, 2.2f, p); canvas.drawCircle(15f, 12f, 2.2f, p); canvas.drawCircle(8f, 17f, 2.2f, p)
            }
            Kind.GRID -> {
                canvas.drawRoundRect(RectF(3f, 3f, 21f, 21f), 2f, 2f, p)
                canvas.drawLine(9f, 3f, 9f, 21f, p); canvas.drawLine(15f, 3f, 15f, 21f, p)
                canvas.drawLine(3f, 9f, 21f, 9f, p); canvas.drawLine(3f, 15f, 21f, 15f, p)
            }
            Kind.UNDO -> {
                path.moveTo(9f, 14f); path.lineTo(4f, 9f); path.lineTo(9f, 4f)
                canvas.drawPath(path, p)
                path.reset()
                path.moveTo(4f, 9f); path.lineTo(15f, 9f)
                path.cubicTo(18.5f, 9f, 20f, 11.5f, 20f, 14f)
                path.cubicTo(20f, 16.5f, 18.5f, 19f, 15f, 19f)
                path.lineTo(9f, 19f)
                canvas.drawPath(path, p)
            }
            Kind.PORTRAIT -> {
                canvas.drawCircle(12f, 8f, 3.4f, p)
                path.moveTo(5f, 20f)
                path.cubicTo(5f, 13.5f, 19f, 13.5f, 19f, 20f)
                canvas.drawPath(path, p)
            }
        }
        canvas.restore()
    }
}

class GlassIconButton(ctx: Context, kind: IconView.Kind, private val sizeDp: Int = 44) : FrameLayout(ctx) {
    val icon = IconView(ctx, kind)

    init {
        background = glass(ctx, sizeDp / 2f)
        val pad = ctx.dp(sizeDp / 4 + 1)
        icon.setPadding(pad, pad, pad, pad)
        addView(icon, FrameLayout.LayoutParams(MATCH, MATCH))
        isClickable = true
    }

    fun setActive(on: Boolean) {
        icon.tint = if (on) K.CYAN else Color.WHITE
        background = glass(context, sizeDp / 2f, false, on)
    }
}

class ShutterView(ctx: Context) : View(ctx) {
    var videoMode: Boolean = false
        set(v) { field = v; invalidate() }
    var recording: Boolean = false
        set(v) { field = v; invalidate() }
    private var pressedScale = 1f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        ring.style = Paint.Style.STROKE
        ring.color = Color.WHITE
    }

    override fun onDraw(canvas: Canvas) {
        ring.strokeWidth = dpf(4f)
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - ring.strokeWidth / 2f
        canvas.drawCircle(cx, cy, r, ring)
        val inner = r - dpf(6f)
        if (recording) {
            fill.color = K.RED
            val s = inner * 0.55f
            canvas.drawRoundRect(RectF(cx - s, cy - s, cx + s, cy + s), dpf(8f), dpf(8f), fill)
        } else {
            fill.color = if (videoMode) K.RED else Color.WHITE
            canvas.drawCircle(cx, cy, inner * pressedScale, fill)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressedScale = 0.86f; invalidate() }
            MotionEvent.ACTION_UP -> { pressedScale = 1f; invalidate(); performClick() }
            MotionEvent.ACTION_CANCEL -> { pressedScale = 1f; invalidate() }
            else -> {}
        }
        return true
    }
}

class GridOverlay(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.color = Color.parseColor("#66FFFFFF")
        p.strokeWidth = 1.2f
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawLine(w / 3f, 0f, w / 3f, h, p)
        canvas.drawLine(w * 2f / 3f, 0f, w * 2f / 3f, h, p)
        canvas.drawLine(0f, h / 3f, w, h / 3f, p)
        canvas.drawLine(0f, h * 2f / 3f, w, h * 2f / 3f, p)
    }
}

/** قرص زوم لوغاريتمي: اسحب يمينًا/يسارًا لتغيير التكبير من الحد الأدنى حتى 120x. */
class ZoomDial(ctx: Context) : View(ctx) {
    var minZ = 1f
    var maxZ = 120f
    var value = 1f
        set(v) { field = v; invalidate() }
    var onChange: ((Float) -> Unit)? = null
    var onTouching: ((Boolean) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val majors = floatArrayOf(0.8f, 1f, 2f, 3f, 5f, 10f, 20f, 30f, 50f, 80f, 120f)
    private val minors = floatArrayOf(0.9f, 1.2f, 1.4f, 1.6f, 1.8f, 2.5f, 4f, 6f, 7f, 8f, 9f, 15f, 25f, 40f, 60f, 70f, 100f)
    private var lastX = 0f

    private fun pxPerLn(): Float = width / 3.2f

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val h = height.toFloat()
        val k = pxPerLn()
        val lv = ln(value)
        p.strokeCap = Paint.Cap.ROUND
        p.textAlign = Paint.Align.CENTER
        p.textSize = dpf(11f)
        for (z in minors) {
            if (z < minZ - 0.001f || z > maxZ + 0.001f) continue
            val x = cx + (ln(z) - lv) * k
            if (x < 0 || x > width) continue
            p.color = K.WHITE55
            p.strokeWidth = dpf(1f)
            canvas.drawLine(x, h * 0.42f, x, h * 0.62f, p)
        }
        for (z in majors) {
            if (z < minZ - 0.001f || z > maxZ + 0.001f) continue
            val x = cx + (ln(z) - lv) * k
            if (x < 0 || x > width) continue
            val near = abs(x - cx) < dpf(16f)
            p.color = if (near) K.CYAN else Color.WHITE
            p.strokeWidth = dpf(1.6f)
            canvas.drawLine(x, h * 0.35f, x, h * 0.70f, p)
            p.style = Paint.Style.FILL
            val txt = if (z == 0.8f) "0.8" else z.toInt().toString()
            canvas.drawText(txt, x, h * 0.28f, p)
        }
        p.color = K.CYAN
        p.strokeWidth = dpf(2.4f)
        canvas.drawLine(cx, h * 0.30f, cx, h * 0.92f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                parent?.requestDisallowInterceptTouchEvent(true)
                onTouching?.invoke(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                lastX = e.x
                val nl = ln(value) - dx / pxPerLn()
                val nv = exp(nl.toDouble()).toFloat().coerceIn(minZ, maxZ)
                value = nv
                onChange?.invoke(nv)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onTouching?.invoke(false)
            else -> {}
        }
        return true
    }
}
