package com.aether.camera.ultra

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.aether.camera.ultra.camera.DeviceScanner
import com.aether.camera.ultra.camera.ScanResult
import com.aether.camera.ultra.media.ThumbLoader
import com.aether.camera.ultra.ui.CameraScreen
import com.aether.camera.ultra.ui.MATCH
import com.aether.camera.ultra.ui.Screen

class MainActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var thumbs: ThumbLoader
    private lateinit var rootLayout: FrameLayout
    private lateinit var camera: CameraScreen
    private val stack = ArrayList<Screen>()
    var scan: ScanResult? = null
        private set
    var insetTop = 0
        private set
    var insetBottom = 0
        private set

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (::camera.isInitialized) camera.onPermissionResult()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        thumbs = ThumbLoader(this)
        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.BLACK)
        setContentView(rootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            insetTop = b.top
            insetBottom = b.bottom
            for (s in stack) s.onInsets(b.top, b.bottom)
            insets
        }
        rescan()
        camera = CameraScreen(this)
        stack.add(camera)
        rootLayout.addView(camera.view, FrameLayout.LayoutParams(MATCH, MATCH))
        camera.onInsets(insetTop, insetBottom)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val top = stack.last()
                if (top.onBack()) return
                if (stack.size > 1) close() else finish()
            }
        })
        if (!hasCameraPermission()) requestAppPermissions()
    }

    fun rescan() {
        try {
            scan = DeviceScanner.scan(this, prefs.wideOverrideId)
        } catch (e: Exception) {
            toast("تعذر فحص الكاميرات: ${e.message}")
        }
    }

    fun hasCameraPermission(): Boolean =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun hasAudioPermission(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun requestAppPermissions() {
        permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    fun open(s: Screen) {
        val old = stack.last()
        old.onPause()
        stack.add(s)
        val v = s.view
        v.alpha = 0f
        rootLayout.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        s.onInsets(insetTop, insetBottom)
        v.post {
            v.translationY = v.height * 0.06f
            v.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }
        s.onResume()
    }

    fun close() {
        if (stack.size <= 1) return
        val s = stack.removeAt(stack.size - 1)
        s.onPause()
        val v: View = s.view
        v.animate().alpha(0f).translationY(v.height * 0.06f).setDuration(180).withEndAction {
            rootLayout.removeView(v)
        }.start()
        stack.last().onResume()
    }

    override fun onResume() {
        super.onResume()
        if (stack.isNotEmpty()) stack.last().onResume()
    }

    override fun onPause() {
        super.onPause()
        if (stack.isNotEmpty()) stack.last().onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        thumbs.clear()
    }
}
