package com.aether.camera.ultra.media

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.Executors

class ThumbLoader(private val ctx: Context) {
    private val cache = LruCache<String, Bitmap>(120)
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(uri: Uri, px: Int, done: (Bitmap?) -> Unit) {
        val key = "$uri@$px"
        val hit = cache.get(key)
        if (hit != null) { done(hit); return }
        pool.execute {
            val b = MediaStorage.thumbnail(ctx, uri, px)
            if (b != null) cache.put(key, b)
            main.post { done(b) }
        }
    }

    fun clear() = cache.evictAll()
}
