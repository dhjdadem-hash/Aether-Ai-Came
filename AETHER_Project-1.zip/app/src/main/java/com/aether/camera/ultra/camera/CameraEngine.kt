package com.aether.camera.ultra.camera

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.CamcorderProfile
import android.media.ImageReader
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.TextureView
import com.aether.camera.ultra.media.MediaStorage
import com.aether.camera.ultra.media.PhotoPipeline
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

interface EngineCallbacks {
    fun onOpened(info: CamInfo)
    fun onError(message: String)
    fun onPhoto(out: PhotoPipeline.Out)
    fun onRecordingStarted()
    fun onRecordingFinished(uri: Uri?, message: String, ok: Boolean)
    fun onNote(message: String)
}

class CameraEngine(
    private val ctx: Context,
    private val tv: TextureView,
    private val cb: EngineCallbacks
) {
    private val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("AetherCamera").also { it.start() }
    private val bg = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executor { r -> bg.post(r) }
    private val io = Executors.newSingleThreadExecutor()

    // إعدادات يقرؤها المحرك عند بناء كل طلب
    @Volatile var uiZoom = 1f
    @Volatile var zoomDivisor = 1f
    @Volatile var flashMode = 0            // 0 إيقاف، 1 تلقائي، 2 تشغيل، 3 مصباح
    @Volatile var aspect = 0               // 0 = 4:3، 1 = 16:9، 2 = 1:1
    @Volatile var videoMode = false
    @Volatile var stabMode = 1
    @Volatile var nightScene = false
    @Volatile var manualOn = false
    @Volatile var manualIso = -1
    @Volatile var manualExpNs = -1L
    @Volatile var manualFocus = -1f
    @Volatile var wbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO
    @Volatile var evIndex = 0
    @Volatile var jpegQuality = 95
    @Volatile var videoFps = 30

    @Volatile var recording = false
        private set
    @Volatile var recordStartMs = 0L
        private set

    var info: CamInfo? = null
        private set

    private var chars: CameraCharacteristics? = null
    private var camId = ""
    private var physId: String? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewBuilder: CaptureRequest.Builder? = null
    private var recordBuilder: CaptureRequest.Builder? = null
    private var jpegReader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var recorder: MediaRecorder? = null
    private var recSurface: Surface? = null
    private var tempFile: File? = null
    private var lastIso = 200
    private var lastExpNs = 16_666_666L
    private var retries = 0
    @Volatile private var closed = true
    private var stopPending = false
    private var hwMin = 1f
    private var hwMax = 1f
    private var zoomApi = false
    private val paramsQueue = ConcurrentLinkedQueue<PhotoPipeline.Params>()

    // ---------- فتح وإغلاق ----------

    fun open(cameraId: String, physicalId: String?, divisor: Float) {
        zoomDivisor = divisor
        bg.post { openInternal(cameraId, physicalId) }
    }

    fun close() {
        closed = true
        bg.post {
            if (recording) stopRecordingInternal(true)
            closeInternal()
        }
    }

    fun release() {
        closed = true
        bg.post {
            if (recording) stopRecordingInternal(true)
            closeInternal()
            thread.quitSafely()
        }
        io.shutdown()
    }

    fun onSurfaceAvailable() {
        bg.post { if (device != null && session == null && !recording) startPreviewSession() }
    }

    private fun fail(msg: String) {
        main.post { cb.onError(msg) }
    }

    private fun closeInternal() {
        try { session?.close() } catch (e: Exception) { /* تجاهل */ }
        session = null
        try { device?.close() } catch (e: Exception) { /* تجاهل */ }
        device = null
        try { jpegReader?.close() } catch (e: Exception) { /* تجاهل */ }
        jpegReader = null
        try { previewSurface?.release() } catch (e: Exception) { /* تجاهل */ }
        previewSurface = null
        previewBuilder = null
        recordBuilder = null
    }

    private fun openInternal(id: String, physical: String?) {
        closed = false
        closeInternal()
        try {
            val c = manager.getCameraCharacteristics(id)
            chars = c
            camId = id
            physId = physical
            val inf = DeviceScanner.describe(id, c)
            info = inf
            zoomApi = Build.VERSION.SDK_INT >= 30 && inf.zoomRatioApi
            hwMin = if (zoomApi) min(inf.zoomMin, 1f) else 1f
            hwMax = max(1f, min(inf.zoomMax, 30f))
            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (closed || camId != id) { camera.close(); return }
                    device = camera
                    retries = 0
                    main.post { cb.onOpened(inf) }
                    startPreviewSession()
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    if (device === camera) {
                        device = null
                        session = null
                        if (recording) stopRecordingInternal(true)
                        fail("انقطع الاتصال بالكاميرا")
                    }
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    if (device === camera) device = null
                    if (error == CameraDevice.StateCallback.ERROR_CAMERA_IN_USE && retries < 3 && !closed) {
                        retries++
                        bg.postDelayed({ if (!closed) openInternal(id, physical) }, 450)
                        return
                    }
                    fail(errorText(error))
                }
            }, bg)
        } catch (e: SecurityException) {
            fail("لا توجد صلاحية الكاميرا")
        } catch (e: Exception) {
            fail("تعذر فتح الكاميرا $id: ${e.message}")
        }
    }

    private fun errorText(e: Int): String = when (e) {
        CameraDevice.StateCallback.ERROR_CAMERA_IN_USE -> "الكاميرا مستخدمة من تطبيق آخر"
        CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE -> "تم فتح عدد كبير من الكاميرات"
        CameraDevice.StateCallback.ERROR_CAMERA_DISABLED -> "الكاميرا معطلة بسياسة الجهاز"
        CameraDevice.StateCallback.ERROR_CAMERA_DEVICE -> "خطأ في جهاز الكاميرا"
        CameraDevice.StateCallback.ERROR_CAMERA_SERVICE -> "خطأ في خدمة الكاميرا"
        else -> "خطأ غير معروف في الكاميرا ($e)"
    }

    // ---------- اختيار الأحجام ----------

    private fun pickSize(sizes: Array<Size>?, rw: Int, rh: Int, maxPx: Long): Size {
        val list = sizes?.toList() ?: emptyList()
        val target = rw.toDouble() / rh.toDouble()
        val ok = list.filter { it.width.toLong() * it.height <= maxPx }
        val pool = if (ok.isNotEmpty()) ok else list
        if (pool.isEmpty()) return Size(1280, 720)
        val sorted = pool.sortedWith(
            compareBy<Size>(
                { Math.round(abs(it.width.toDouble() / it.height - target) * 100) },
                { -(it.width.toLong() * it.height) }
            )
        )
        return sorted[0]
    }

    private fun previewRatio(): Pair<Int, Int> = if (videoMode || aspect == 1) Pair(16, 9) else Pair(4, 3)

    // ---------- جلسة المعاينة ----------

    private fun startPreviewSession() {
        val dev = device ?: return
        if (closed) return
        if (!tv.isAvailable) return
        val st = tv.surfaceTexture ?: return
        try {
            val map = chars?.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val pr = previewRatio()
            val ps = pickSize(map?.getOutputSizes(SurfaceTexture::class.java), pr.first, pr.second, 2_100_000L)
            st.setDefaultBufferSize(ps.width, ps.height)
            val old = previewSurface
            val surf = Surface(st)
            previewSurface = surf
            val jr = if (aspect == 1) Pair(16, 9) else Pair(4, 3)
            val js = pickSize(map?.getOutputSizes(ImageFormat.JPEG), jr.first, jr.second, Long.MAX_VALUE)
            try { jpegReader?.close() } catch (e: Exception) { /* تجاهل */ }
            val reader = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 3)
            reader.setOnImageAvailableListener(imageListener, bg)
            jpegReader = reader
            createSession(dev, listOf(surf, reader.surface), physId, { s ->
                session = s
                try {
                    val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                    b.addTarget(surf)
                    previewBuilder = b
                    applyControls(b, false, false)
                    s.setRepeatingRequest(b.build(), repeatCb, bg)
                    applyTransform()
                    try { old?.release() } catch (e: Exception) { /* تجاهل */ }
                } catch (e: Exception) {
                    fail("تعذر بدء المعاينة: ${e.message}")
                }
            }, { fail("فشل إعداد جلسة الكاميرا") })
        } catch (e: Exception) {
            fail("تعذر إعداد المعاينة: ${e.message}")
        }
    }

    private fun createSession(
        dev: CameraDevice,
        surfaces: List<Surface>,
        physical: String?,
        onReady: (CameraCaptureSession) -> Unit,
        onFail: () -> Unit
    ) {
        val scb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                if (device !== dev || closed) { s.close(); return }
                onReady(s)
            }

            override fun onConfigureFailed(s: CameraCaptureSession) {
                onFail()
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 28 && physical != null) {
                val cfgs = ArrayList<OutputConfiguration>()
                for (sf in surfaces) {
                    val oc = OutputConfiguration(sf)
                    oc.setPhysicalCameraId(physical)
                    cfgs.add(oc)
                }
                dev.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, cfgs, executor, scb))
            } else {
                dev.createCaptureSession(surfaces, scb, bg)
            }
        } catch (e: Exception) {
            fail("تعذر إنشاء الجلسة: ${e.message}")
        }
    }

    // ---------- الطلبات ----------

    private fun has(arr: IntArray?, v: Int): Boolean = arr != null && arr.contains(v)

    private fun hwZoom(): Float = (uiZoom / zoomDivisor).coerceIn(hwMin, hwMax)

    fun extraZoom(): Float {
        val want = uiZoom / zoomDivisor
        val hw = want.coerceIn(hwMin, hwMax)
        return if (want > hw) want / hw else 1f
    }

    private fun cropRect(): Rect? {
        val a = chars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return null
        val z = max(hwZoom(), 1f)
        val cw = (a.width() / z).toInt()
        val ch = (a.height() / z).toInt()
        val l = a.left + (a.width() - cw) / 2
        val t = a.top + (a.height() - ch) / 2
        return Rect(l, t, l + cw, t + ch)
    }

    private fun applyZoomTo(b: CaptureRequest.Builder) {
        val hw = hwZoom()
        if (zoomApi) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hw)
        } else {
            val r = cropRect()
            if (r != null) b.set(CaptureRequest.SCALER_CROP_REGION, r)
        }
    }

    private fun applyControls(b: CaptureRequest.Builder, video: Boolean, still: Boolean) {
        val c = chars ?: return
        val inf = info ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        applyZoomTo(b)

        // التركيز
        val afModes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
        if (manualOn && manualFocus >= 0f && inf.minFocusDiopter > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocus.coerceIn(0f, inf.minFocusDiopter))
        } else {
            val want = if (video) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            if (has(afModes, want)) b.set(CaptureRequest.CONTROL_AF_MODE, want)
            else if (has(afModes, CaptureRequest.CONTROL_AF_MODE_AUTO)) b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
        }

        // التعريض
        val manualAe = manualOn && inf.manualSensor && (manualIso > 0 || manualExpNs > 0L)
        if (manualAe) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            val iso = if (manualIso > 0) manualIso else lastIso
            var exp = if (manualExpNs > 0L) manualExpNs else lastExpNs
            if (video) exp = min(exp, 1_000_000_000L / max(videoFps, 1))
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso.coerceIn(inf.isoMin, max(inf.isoMin, inf.isoMax)))
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp.coerceIn(inf.expMinNs, max(inf.expMinNs, inf.expMaxNs)))
        } else {
            var ae = CaptureRequest.CONTROL_AE_MODE_ON
            if (still && inf.flash && !inf.isFront) {
                if (flashMode == 1) ae = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                if (flashMode == 2) ae = CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
            }
            b.set(CaptureRequest.CONTROL_AE_MODE, ae)
            if (inf.evMax > inf.evMin) {
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex.coerceIn(inf.evMin, inf.evMax))
            }
        }

        // توازن اللون الأبيض
        if (inf.awbModes.contains(wbMode)) b.set(CaptureRequest.CONTROL_AWB_MODE, wbMode)

        // الفلاش / المصباح
        val torch = inf.flash && (flashMode == 3 || (video && flashMode == 2))
        b.set(CaptureRequest.FLASH_MODE, if (torch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)

        // الوضع الليلي
        if (nightScene && !manualAe && inf.sceneModes.contains(CaptureRequest.CONTROL_SCENE_MODE_NIGHT)) {
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_USE_SCENE_MODE)
            b.set(CaptureRequest.CONTROL_SCENE_MODE, CaptureRequest.CONTROL_SCENE_MODE_NIGHT)
        }

        if (still) {
            if (inf.nrModes.contains(CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)) {
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            }
            val edges = c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
            if (has(edges, CaptureRequest.EDGE_MODE_HIGH_QUALITY)) {
                b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            }
        }

        if (video) {
            var eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            var ois = CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF
            if (stabMode >= 1) {
                if (inf.eisModes.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)) eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
                if (inf.oisModes.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)) ois = CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            }
            if (stabMode >= 2 && Build.VERSION.SDK_INT >= 33 && inf.previewStabilization) {
                eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
            }
            b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, eis)
            if (inf.oisModes.isNotEmpty()) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, ois)
            val fps = videoFps
            var best: Pair<Int, Int>? = null
            for (r in inf.fpsRanges) {
                if (r.first <= fps && fps <= r.second) {
                    if (best == null || (r.second - r.first) < (best.second - best.first)) best = r
                }
            }
            if (best != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range.create(best.first, best.second))
        }
    }

    private val repeatCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            val i = result.get(CaptureResult.SENSOR_SENSITIVITY)
            if (i != null) lastIso = i
            val e = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            if (e != null) lastExpNs = e
        }
    }

    private fun currentBuilder(): CaptureRequest.Builder? = if (recording) recordBuilder else previewBuilder

    private fun applyTransform() {
        val front = chars?.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        val extra = extraZoom()
        main.post {
            tv.scaleX = (if (front) -1f else 1f) * extra
            tv.scaleY = extra
        }
    }

    /** يُستدعى عند تغيير الزوم أو إعدادات Pro. */
    fun refresh() {
        bg.post {
            val s = session
            val b = currentBuilder()
            if (s != null && b != null) {
                try {
                    applyControls(b, recording, false)
                    s.setRepeatingRequest(b.build(), repeatCb, bg)
                } catch (e: Exception) { /* تجاهل */ }
                applyTransform()
            }
        }
    }

    /** إعادة بناء الجلسة عند تغيير النسبة أو الوضع (صورة/فيديو). */
    fun restartPreview() {
        bg.post {
            if (device != null && !recording) {
                session = null
                startPreviewSession()
            }
        }
    }

    fun focusAt(nx: Float, ny: Float) {
        bg.post {
            val c = chars
            val s = session
            val b = currentBuilder()
            if (c != null && s != null && b != null) {
                try {
                    val arr = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                    val crop = cropRect()
                    if (arr != null && crop != null) {
                        val orient = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                        val pt = when (orient) {
                            90 -> Pair(ny, 1f - nx)
                            180 -> Pair(1f - nx, 1f - ny)
                            270 -> Pair(1f - ny, nx)
                            else -> Pair(nx, ny)
                        }
                        val cx = crop.left + (pt.first.coerceIn(0f, 1f) * crop.width()).toInt()
                        val cy = crop.top + (pt.second.coerceIn(0f, 1f) * crop.height()).toInt()
                        val half = (max(arr.width(), arr.height()) * 0.06f).toInt()
                        val x = (cx - half).coerceIn(arr.left, max(arr.left, arr.right - 2 * half - 1))
                        val y = (cy - half).coerceIn(arr.top, max(arr.top, arr.bottom - 2 * half - 1))
                        val rects = arrayOf(MeteringRectangle(x, y, 2 * half, 2 * half, MeteringRectangle.METERING_WEIGHT_MAX - 1))
                        val maxAf = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
                        val maxAe = c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0
                        if (maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, rects)
                        if (maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, rects)
                        if (!(manualOn && manualFocus >= 0f)) {
                            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                            s.capture(b.build(), null, bg)
                            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
                        }
                        s.setRepeatingRequest(b.build(), repeatCb, bg)
                    }
                } catch (e: Exception) { /* تجاهل */ }
            }
        }
    }

    // ---------- التقاط الصور ----------

    private val imageListener = ImageReader.OnImageAvailableListener { r ->
        val img = try { r.acquireNextImage() } catch (e: Exception) { null }
        if (img != null) {
            val bytes: ByteArray = try {
                val buf = img.planes[0].buffer
                val arr = ByteArray(buf.remaining())
                buf.get(arr)
                arr
            } finally {
                img.close()
            }
            val p = paramsQueue.poll() ?: PhotoPipeline.Params()
            io.execute {
                val out = PhotoPipeline.process(ctx, bytes, p)
                main.post { cb.onPhoto(out) }
            }
        }
    }

    private val stillCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
            paramsQueue.poll()
            fail("فشل الالتقاط (رمز ${failure.reason})")
        }
    }

    private fun jpegOrientation(devOri: Int): Int {
        val c = chars ?: return 90
        val sensor = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        var d = (((if (devOri < 0) 0 else devOri) + 45) / 90 * 90) % 360
        if (c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) d = -d
        return (sensor + d + 360) % 360
    }

    fun capture(deviceOrientation: Int, params: PhotoPipeline.Params) {
        bg.post { captureInternal(deviceOrientation, params) }
    }

    private fun captureInternal(orient: Int, params: PhotoPipeline.Params) {
        val dev = device
        val s = session
        val reader = jpegReader
        val inf = info
        if (dev == null || s == null || reader == null || inf == null || recording) {
            fail("الكاميرا غير جاهزة للالتقاط")
            return
        }
        paramsQueue.offer(params)
        val manualAe = manualOn && inf.manualSensor && (manualIso > 0 || manualExpNs > 0L)
        val useFlash = inf.flash && !inf.isFront && !manualAe && (flashMode == 1 || flashMode == 2)
        val shoot = Runnable {
            try {
                val sb = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                sb.addTarget(reader.surface)
                applyControls(sb, false, true)
                sb.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation(orient))
                sb.set(CaptureRequest.JPEG_QUALITY, jpegQuality.toByte())
                s.capture(sb.build(), stillCb, bg)
            } catch (e: Exception) {
                paramsQueue.poll()
                fail("تعذر الالتقاط: ${e.message}")
            }
        }
        if (useFlash) {
            try {
                val pb = previewBuilder
                if (pb != null) {
                    applyControls(pb, false, true)
                    pb.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START)
                    s.capture(pb.build(), null, bg)
                    pb.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_IDLE)
                    s.setRepeatingRequest(pb.build(), repeatCb, bg)
                }
            } catch (e: Exception) { /* نتابع بدون precapture */ }
            bg.postDelayed(shoot, 700)
            bg.postDelayed({
                val pb2 = previewBuilder
                val s2 = session
                if (pb2 != null && s2 != null) {
                    try {
                        applyControls(pb2, false, false)
                        s2.setRepeatingRequest(pb2.build(), repeatCb, bg)
                    } catch (e: Exception) { /* تجاهل */ }
                }
            }, 1600)
        } else {
            shoot.run()
        }
    }

    // ---------- تسجيل الفيديو ----------

    fun startRecording(quality: Int, fps: Int, withAudio: Boolean, deviceOrientation: Int) {
        bg.post { startRecordingInternal(quality, fps, withAudio, deviceOrientation, 0) }
    }

    private fun startRecordingInternal(quality: Int, fps: Int, audio: Boolean, orient: Int, attempt: Int) {
        val dev = device
        val c = chars
        if (dev == null || c == null || recording) { fail("الكاميرا غير جاهزة للتسجيل"); return }
        val idNum = camId.toIntOrNull() ?: 0
        var q = quality
        if (!CamcorderProfile.hasProfile(idNum, q)) {
            q = if (CamcorderProfile.hasProfile(idNum, CamcorderProfile.QUALITY_1080P)) CamcorderProfile.QUALITY_1080P
            else CamcorderProfile.QUALITY_720P
        }
        if (!CamcorderProfile.hasProfile(idNum, q)) { fail("هذه الكاميرا لا تدعم تسجيل الفيديو"); return }
        val prof = CamcorderProfile.get(idNum, q)
        if (prof == null) { fail("تعذر قراءة إعدادات الفيديو"); return }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.cacheDir
        val free = try { StatFs(dir.path).availableBytes } catch (e: Exception) { Long.MAX_VALUE }
        if (free < 300L * 1024L * 1024L) { fail("المساحة غير كافية للتسجيل (أقل من 300MB)"); return }
        val withAudio = audio && ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val f = File(dir, "rec_" + System.currentTimeMillis() + ".mp4")
        tempFile = f
        videoFps = fps
        val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            if (withAudio) mr.setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(f.absolutePath)
            val rate = if (prof.videoFrameRate > 0) fps.toLong() * prof.videoBitRate / prof.videoFrameRate else prof.videoBitRate.toLong()
            mr.setVideoEncodingBitRate(min(rate, 120_000_000L).toInt())
            mr.setVideoFrameRate(fps)
            mr.setVideoSize(prof.videoFrameWidth, prof.videoFrameHeight)
            mr.setVideoEncoder(prof.videoCodec)
            if (withAudio) {
                mr.setAudioEncoder(prof.audioCodec)
                mr.setAudioEncodingBitRate(prof.audioBitRate)
                mr.setAudioSamplingRate(prof.audioSampleRate)
                mr.setAudioChannels(prof.audioChannels)
            }
            mr.setOrientationHint(jpegOrientation(orient))
            mr.setOnErrorListener { _, what, _ ->
                if (recording) {
                    bg.post { stopRecordingInternal(true) }
                    fail("خطأ في المسجل ($what)")
                }
            }
            mr.prepare()
        } catch (e: Exception) {
            try { mr.release() } catch (e2: Exception) { /* تجاهل */ }
            f.delete()
            if (attempt == 0 && (q != CamcorderProfile.QUALITY_1080P || fps != 30)) {
                main.post { cb.onNote("الإعداد غير مدعوم، تم التحويل إلى 1080p/30") }
                startRecordingInternal(CamcorderProfile.QUALITY_1080P, 30, audio, orient, 1)
            } else {
                fail("تعذر تجهيز المسجل: ${e.message}")
            }
            return
        }
        recorder = mr
        val rs = mr.surface
        recSurface = rs
        val st = tv.surfaceTexture
        if (st == null) { cleanupRecorder(); fail("المعاينة غير جاهزة"); return }
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val ps = pickSize(map?.getOutputSizes(SurfaceTexture::class.java), prof.videoFrameWidth, prof.videoFrameHeight, 2_100_000L)
        st.setDefaultBufferSize(ps.width, ps.height)
        val oldSurf = previewSurface
        val surf = Surface(st)
        previewSurface = surf
        createSession(dev, listOf(surf, rs), physId, { s ->
            session = s
            try {
                val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                b.addTarget(surf)
                b.addTarget(rs)
                recordBuilder = b
                videoFps = fps
                applyControls(b, true, false)
                s.setRepeatingRequest(b.build(), repeatCb, bg)
                mr.start()
                recording = true
                stopPending = false
                recordStartMs = SystemClock.elapsedRealtime()
                try { oldSurf?.release() } catch (e: Exception) { /* تجاهل */ }
                main.post { cb.onRecordingStarted() }
            } catch (e: Exception) {
                cleanupRecorder()
                f.delete()
                if (attempt == 0 && (q != CamcorderProfile.QUALITY_1080P || fps != 30)) {
                    main.post { cb.onNote("تعذر هذا الإعداد، تم التحويل إلى 1080p/30") }
                    startRecordingInternal(CamcorderProfile.QUALITY_1080P, 30, audio, orient, 1)
                } else {
                    fail("تعذر بدء التسجيل: ${e.message}")
                    startPreviewSession()
                }
            }
        }, {
            cleanupRecorder()
            f.delete()
            if (attempt == 0 && (q != CamcorderProfile.QUALITY_1080P || fps != 30)) {
                main.post { cb.onNote("الجهاز لا يدعم هذه الدقة، تم التحويل إلى 1080p/30") }
                startRecordingInternal(CamcorderProfile.QUALITY_1080P, 30, audio, orient, 1)
            } else {
                fail("لا يدعم الجهاز إعداد التسجيل المطلوب")
                startPreviewSession()
            }
        })
    }

    private fun cleanupRecorder() {
        try { recorder?.reset() } catch (e: Exception) { /* تجاهل */ }
        try { recorder?.release() } catch (e: Exception) { /* تجاهل */ }
        recorder = null
        try { recSurface?.release() } catch (e: Exception) { /* تجاهل */ }
        recSurface = null
    }

    fun stopRecording() {
        bg.post { stopRecordingInternal(false) }
    }

    private fun stopRecordingInternal(force: Boolean) {
        val mr = recorder
        if (mr == null || !recording) return
        val elapsed = SystemClock.elapsedRealtime() - recordStartMs
        if (!force && elapsed < 1300L) {
            if (!stopPending) {
                stopPending = true
                bg.postDelayed({ stopRecordingInternal(false) }, 1350L - elapsed)
            }
            return
        }
        recording = false
        try { session?.stopRepeating() } catch (e: Exception) { /* تجاهل */ }
        try { session?.abortCaptures() } catch (e: Exception) { /* تجاهل */ }
        var stopOk = true
        try { mr.stop() } catch (e: RuntimeException) { stopOk = false }
        cleanupRecorder()
        val f = tempFile
        tempFile = null
        var uri: Uri? = null
        var msg: String
        var ok = false
        if (f == null) {
            msg = "لا يوجد ملف تسجيل"
        } else {
            val dur = videoDuration(f)
            if (dur >= 500L) {
                val name = "AETHER_" + MediaStorage.stamp()
                uri = MediaStorage.saveVideo(ctx, f, name)
                if (uri != null) {
                    f.delete()
                    ok = true
                    msg = if (stopOk) "تم حفظ الفيديو (" + (dur / 1000L) + " ث)" else "تم استرجاع الفيديو وحفظه (" + (dur / 1000L) + " ث)"
                } else {
                    msg = "تعذر النسخ إلى المعرض. الملف محفوظ في: " + f.absolutePath
                }
            } else if (f.exists() && f.length() > 2048L) {
                val rec = File(f.parentFile, "recovered_" + f.name)
                msg = if (f.renameTo(rec)) "التسجيل غير مكتمل وتم حفظ ملف جزئي في: " + rec.absolutePath else "التسجيل غير مكتمل"
            } else {
                f.delete()
                msg = "التسجيل قصير جدًا ولم يُحفظ"
            }
        }
        val finalMsg = msg
        val finalOk = ok
        val finalUri = uri
        main.post { cb.onRecordingFinished(finalUri, finalMsg, finalOk) }
        session = null
        startPreviewSession()
    }

    private fun videoDuration(f: File): Long {
        if (!f.exists() || f.length() < 1024L) return -1L
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
        } catch (e: Exception) {
            -1L
        } finally {
            try { r.release() } catch (e: Exception) { /* تجاهل */ }
        }
    }
}
