package com.aether.camera.ultra.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.CamcorderProfile
import android.media.MediaActionSound
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import android.graphics.SurfaceTexture
import com.aether.camera.ultra.MainActivity
import com.aether.camera.ultra.ai.ColorEngine
import com.aether.camera.ultra.camera.CamInfo
import com.aether.camera.ultra.camera.CameraEngine
import com.aether.camera.ultra.camera.DeviceScanner
import com.aether.camera.ultra.camera.EngineCallbacks
import com.aether.camera.ultra.camera.VideoQ
import com.aether.camera.ultra.camera.WideSource
import com.aether.camera.ultra.media.MediaStorage
import com.aether.camera.ultra.media.PhotoPipeline
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max

class CameraScreen(private val act: MainActivity) : Screen, EngineCallbacks {

    enum class Mode(val title: String) {
        PHOTO("صورة"), VIDEO("فيديو"), PRO("برو"), PORTRAIT("بورتريه"), NIGHT("ليلي")
    }

    private val prefs = act.prefs
    private val root = FrameLayout(act)
    override val view: View = root
    private val handler = Handler(Looper.getMainLooper())
    private val textureView = TextureView(act)
    private val engine = CameraEngine(act, textureView, this)
    private val proPanel = ProPanel(act, engine)
    private val sound = MediaActionSound()

    private var mode = Mode.PHOTO
    private var usingFront = false
    private var wideActive = false
    private var uiZoom = 1f
    private var devOrientation = 0
    private var recording = false
    private var startingRec = false
    private var permissionOk = false
    private var countdownActive = false
    private var tempMsgActive = false
    private var warnText = ""
    private var videoQ: List<VideoQ> = emptyList()
    private var manualVideo = false
    private var paused = true

    // عناصر الواجهة
    private val previewHolder = FrameLayout(act)
    private val grid = GridOverlay(act)
    private val maskTop = View(act)
    private val maskBottom = View(act)
    private val focusRing = View(act)
    private val flashOverlay = View(act)
    private val topBar = LinearLayout(act)
    private val flashBtn = GlassIconButton(act, IconView.Kind.BOLT_OFF, 42)
    private val timerBtn = GlassIconButton(act, IconView.Kind.TIMER, 42)
    private val studioBtn = GlassIconButton(act, IconView.Kind.GRID, 42)
    private val gearBtn = GlassIconButton(act, IconView.Kind.GEAR, 42)
    private val ratioChip = chip(act, "4:3")
    private val aiChip = label(act, "AI", 13f, Color.WHITE, true)
    private val videoBar = LinearLayout(act)
    private val qualityChip = chip(act, "1080p")
    private val fpsChip = chip(act, "30 fps")
    private val stabChip = chip(act, "ثبات")
    private val manualChip = chip(act, "يدوي")
    private val msgPill = label(act, "", 13f, Color.WHITE)
    private val recBar = LinearLayout(act)
    private val recText = label(act, "00:00", 15f, Color.WHITE, true)
    private val countdownText = label(act, "", 110f, Color.WHITE, true)
    private val bottomPanel = LinearLayout(act)
    private val zoomBlock = FrameLayout(act)
    private val pillsRow = LinearLayout(act)
    private val dial = ZoomDial(act)
    private val presets = floatArrayOf(0.8f, 1f, 2f, 5f, 10f)
    private val pills = ArrayList<TextView>()
    private val modeScroll = HorizontalScrollView(act)
    private val modeRow = LinearLayout(act)
    private val modeViews = ArrayList<TextView>()
    private val thumb = ImageView(act)
    private val shutter = ShutterView(act)
    private val flipBtn = GlassIconButton(act, IconView.Kind.FLIP, 52)
    private val permView = LinearLayout(act)

    private val orientation = object : OrientationEventListener(act) {
        override fun onOrientationChanged(o: Int) {
            if (o != ORIENTATION_UNKNOWN) devOrientation = o
        }
    }

    private val hideMsg = Runnable { tempMsgActive = false; refreshWarn() }
    private val dialHide = Runnable { hideDial() }
    private var recTicker: Runnable? = null

    init {
        buildUi()
        try {
            sound.load(MediaActionSound.SHUTTER_CLICK)
            sound.load(MediaActionSound.START_VIDEO_RECORDING)
            sound.load(MediaActionSound.STOP_VIDEO_RECORDING)
        } catch (e: Exception) { /* تجاهل */ }
    }

    // ---------------- بناء الواجهة ----------------

    private fun lp(w: Int, h: Int, g: Int = Gravity.TOP or Gravity.START) = FrameLayout.LayoutParams(w, h, g)

    private fun buildUi() {
        root.setBackgroundColor(Color.BLACK)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR

        previewHolder.clipChildren = true
        previewHolder.addView(textureView, lp(MATCH, MATCH))
        previewHolder.addView(grid, lp(MATCH, MATCH))
        maskTop.setBackgroundColor(Color.BLACK)
        maskBottom.setBackgroundColor(Color.BLACK)
        previewHolder.addView(maskTop, lp(MATCH, 0, Gravity.TOP))
        previewHolder.addView(maskBottom, lp(MATCH, 0, Gravity.BOTTOM))
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.RECTANGLE
        ring.cornerRadius = act.dpf(14f)
        ring.setStroke(act.dp(2), K.CYAN)
        ring.setColor(Color.TRANSPARENT)
        focusRing.background = ring
        focusRing.alpha = 0f
        previewHolder.addView(focusRing, lp(act.dp(70), act.dp(70)))
        root.addView(previewHolder, lp(MATCH, MATCH))

        flashOverlay.setBackgroundColor(Color.WHITE)
        flashOverlay.alpha = 0f
        flashOverlay.isClickable = false
        root.addView(flashOverlay, lp(MATCH, MATCH))

        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { engine.onSurfaceAvailable() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }

        // اللمس: قرص للزوم + نقرة للتركيز
        val scaleDet = ScaleGestureDetector(act, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(uiZoom * d.scaleFactor)
                showDial()
                return true
            }
        })
        val tapDet = GestureDetector(act, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (permissionOk) onTapFocus(e.x, e.y)
                return true
            }
        })
        previewHolder.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress) tapDet.onTouchEvent(e)
            true
        }

        // الشريط العلوي
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(act.dp(12), 0, act.dp(12), 0)
        fun addTop(v: View, w: Int = act.dp(42), h: Int = act.dp(42)) {
            val p = LinearLayout.LayoutParams(w, h)
            p.marginEnd = act.dp(8)
            topBar.addView(v, p)
        }
        addTop(flashBtn)
        addTop(timerBtn)
        addTop(ratioChip, WRAP, act.dp(36))
        aiChip.gravity = Gravity.CENTER
        aiChip.background = glass(act, 9f)
        addTop(aiChip, act.dp(36), act.dp(36))
        val spacer = View(act)
        topBar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        addTop(studioBtn)
        addTop(gearBtn)
        root.addView(topBar, lp(MATCH, WRAP, Gravity.TOP))

        // شريط الفيديو
        videoBar.orientation = LinearLayout.HORIZONTAL
        videoBar.gravity = Gravity.CENTER
        for (c in listOf(qualityChip, fpsChip, stabChip, manualChip)) {
            val p = LinearLayout.LayoutParams(WRAP, act.dp(36))
            p.marginStart = act.dp(4); p.marginEnd = act.dp(4)
            videoBar.addView(c, p)
        }
        videoBar.visibility = View.GONE
        root.addView(videoBar, lp(MATCH, WRAP, Gravity.TOP))

        // شريط التسجيل
        recBar.orientation = LinearLayout.HORIZONTAL
        recBar.gravity = Gravity.CENTER
        recBar.background = glass(act, 18f, true)
        recBar.setPadding(act.dp(14), act.dp(6), act.dp(14), act.dp(6))
        val dot = View(act)
        val dotBg = GradientDrawable()
        dotBg.shape = GradientDrawable.OVAL
        dotBg.setColor(K.RED)
        dot.background = dotBg
        recBar.addView(dot, LinearLayout.LayoutParams(act.dp(10), act.dp(10)).also { it.marginEnd = act.dp(8) })
        recBar.addView(recText, LinearLayout.LayoutParams(WRAP, WRAP))
        recBar.visibility = View.GONE
        root.addView(recBar, lp(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        msgPill.gravity = Gravity.CENTER
        msgPill.background = glass(act, 16f, true)
        msgPill.setPadding(act.dp(14), act.dp(7), act.dp(14), act.dp(7))
        msgPill.visibility = View.GONE
        root.addView(msgPill, lp(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        countdownText.gravity = Gravity.CENTER
        countdownText.visibility = View.GONE
        root.addView(countdownText, lp(MATCH, MATCH))

        // اللوحة السفلية
        bottomPanel.orientation = LinearLayout.VERTICAL
        val bgGrad = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#00000000"), Color.parseColor("#B3000000"))
        )
        bottomPanel.background = bgGrad
        proPanel.view.visibility = View.GONE
        bottomPanel.addView(proPanel.view, LinearLayout.LayoutParams(MATCH, WRAP).also {
            it.marginStart = act.dp(12); it.marginEnd = act.dp(12); it.bottomMargin = act.dp(6)
        })

        pillsRow.orientation = LinearLayout.HORIZONTAL
        pillsRow.gravity = Gravity.CENTER
        for (i in presets.indices) {
            val t = label(act, "", 13f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.minWidth = act.dp(40)
            t.setPadding(act.dp(8), 0, act.dp(8), 0)
            val z = presets[i]
            t.setOnClickListener { onPresetTap(z) }
            t.setOnLongClickListener { showDial(); true }
            val p = LinearLayout.LayoutParams(WRAP, act.dp(38))
            p.marginStart = act.dp(4); p.marginEnd = act.dp(4)
            pillsRow.addView(t, p)
            pills.add(t)
        }
        zoomBlock.addView(pillsRow, lp(MATCH, MATCH, Gravity.CENTER))
        dial.background = glass(act, 22f, true)
        dial.visibility = View.INVISIBLE
        dial.alpha = 0f
        dial.onChange = { z -> setZoom(z); handler.removeCallbacks(dialHide) }
        dial.onTouching = { t -> if (t) handler.removeCallbacks(dialHide) else handler.postDelayed(dialHide, 1800) }
        zoomBlock.addView(dial, lp(MATCH, MATCH).also { it.marginStart = act.dp(24); it.marginEnd = act.dp(24) })
        bottomPanel.addView(zoomBlock, LinearLayout.LayoutParams(MATCH, act.dp(46)))

        modeScroll.isHorizontalScrollBarEnabled = false
        modeScroll.isFillViewport = true
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeRow.gravity = Gravity.CENTER
        for (m in Mode.values()) {
            val t = label(act, m.title, 15f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(8))
            t.setOnClickListener { setMode(m) }
            modeRow.addView(t, LinearLayout.LayoutParams(WRAP, act.dp(40)))
            modeViews.add(t)
        }
        modeScroll.addView(modeRow, FrameLayout.LayoutParams(MATCH, MATCH))
        bottomPanel.addView(modeScroll, LinearLayout.LayoutParams(MATCH, act.dp(42)))

        val shutterRow = FrameLayout(act)
        val tb = GradientDrawable()
        tb.cornerRadius = act.dpf(14f)
        tb.setColor(Color.parseColor("#33FFFFFF"))
        tb.setStroke(act.dp(1), K.GLASS_STROKE)
        thumb.background = tb
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.clipToOutline = true
        thumb.outlineProvider = ViewOutlineProvider.BACKGROUND
        thumb.setOnClickListener { openLatest() }
        shutterRow.addView(thumb, lp(act.dp(54), act.dp(54), Gravity.CENTER_VERTICAL or Gravity.START).also { it.marginStart = act.dp(34) })
        shutterRow.addView(shutter, lp(act.dp(80), act.dp(80), Gravity.CENTER))
        shutter.setOnClickListener { onShutter() }
        shutterRow.addView(flipBtn, lp(act.dp(54), act.dp(54), Gravity.CENTER_VERTICAL or Gravity.END).also { it.marginEnd = act.dp(34) })
        bottomPanel.addView(shutterRow, LinearLayout.LayoutParams(MATCH, act.dp(100)))
        root.addView(bottomPanel, lp(MATCH, WRAP, Gravity.BOTTOM))

        // شاشة الإذن
        permView.orientation = LinearLayout.VERTICAL
        permView.gravity = Gravity.CENTER
        permView.setBackgroundColor(Color.parseColor("#E6000000"))
        val pt = label(act, "يحتاج التطبيق إلى إذن الكاميرا ليعمل", 16f, Color.WHITE, true)
        pt.gravity = Gravity.CENTER
        permView.addView(pt, LinearLayout.LayoutParams(WRAP, WRAP))
        val pb = chip(act, "منح الإذن", true)
        pb.setOnClickListener { act.requestAppPermissions() }
        permView.addView(pb, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = act.dp(16) })
        permView.visibility = View.GONE
        root.addView(permView, lp(MATCH, MATCH))

        wireActions()
        updateModeBar()
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) layoutPreview()
        }
    }

    private fun wireActions() {
        flashBtn.onTap { cycleFlash() }
        timerBtn.onTap {
            prefs.timerSec = when (prefs.timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerBtn.setActive(prefs.timerSec > 0)
            showMsg(if (prefs.timerSec == 0) "المؤقت متوقف" else "المؤقت: ${prefs.timerSec} ثوانٍ")
        }
        ratioChip.onTap { cycleAspect() }
        aiChip.onTap {
            prefs.aiColor = !prefs.aiColor
            updateAiChip()
            showMsg(if (prefs.aiColor) "AI Color مفعّل: يُطبَّق بعد الالتقاط ويُحفظ الأصل" else "AI Color متوقف")
        }
        gearBtn.onTap { act.open(SettingsScreen(act)) }
        studioBtn.onTap { act.open(StudioScreen(act)) }
        flipBtn.onTap { flipCamera() }
        manualChip.onTap {
            manualVideo = !manualVideo
            applyManualState()
        }
        qualityChip.onTap { cycleQuality() }
        fpsChip.onTap { cycleFps() }
        stabChip.onTap { cycleStab() }
    }

    override fun onInsets(top: Int, bottom: Int) {
        (topBar.layoutParams as FrameLayout.LayoutParams).topMargin = top + act.dp(8)
        (videoBar.layoutParams as FrameLayout.LayoutParams).topMargin = top + act.dp(58)
        (recBar.layoutParams as FrameLayout.LayoutParams).topMargin = top + act.dp(64)
        (msgPill.layoutParams as FrameLayout.LayoutParams).topMargin = top + act.dp(108)
        bottomPanel.setPadding(0, act.dp(10), 0, bottom + act.dp(8))
        topBar.requestLayout()
        layoutPreview()
    }

    private fun layoutPreview() {
        val w = root.width
        if (w <= 0) return
        val asp = if (mode == Mode.VIDEO) 1 else prefs.aspect
        val ph: Int
        val top: Int
        if (asp == 1) {
            ph = w * 16 / 9
            top = 0
        } else {
            ph = w * 4 / 3
            top = act.insetTop + act.dp(64)
        }
        val p = previewHolder.layoutParams as FrameLayout.LayoutParams
        if (p.height != ph || p.topMargin != top || p.width != w) {
            p.width = w
            p.height = ph
            p.topMargin = top
            previewHolder.layoutParams = p
        }
        val sq = (ph - w) / 2
        (maskTop.layoutParams as FrameLayout.LayoutParams).height = if (asp == 2) sq else 0
        (maskBottom.layoutParams as FrameLayout.LayoutParams).height = if (asp == 2) sq else 0
        maskTop.requestLayout()
        maskBottom.requestLayout()
        grid.visibility = if (prefs.grid) View.VISIBLE else View.GONE
    }

    // ---------------- دورة الحياة ----------------

    override fun onResume() {
        paused = false
        permissionOk = act.hasCameraPermission()
        permView.visibility = if (permissionOk) View.GONE else View.VISIBLE
        orientation.enable()
        if (act.scan == null) act.rescan()
        applyPrefsToUi()
        if (permissionOk) openCamera()
        refreshThumb()
    }

    override fun onPause() {
        paused = true
        handler.removeCallbacks(dialHide)
        cancelCountdown()
        orientation.disable()
        engine.close()
    }

    fun onPermissionResult() {
        permissionOk = act.hasCameraPermission()
        permView.visibility = if (permissionOk) View.GONE else View.VISIBLE
        if (permissionOk && !paused) openCamera()
    }

    override fun onBack(): Boolean {
        if (recording) { showMsg("أوقف التسجيل أولًا"); return true }
        return false
    }

    private fun applyPrefsToUi() {
        engine.aspect = prefs.aspect
        engine.jpegQuality = prefs.jpegQuality
        engine.stabMode = prefs.stabMode
        engine.flashMode = prefs.flashMode
        engine.videoMode = mode == Mode.VIDEO
        engine.nightScene = mode == Mode.NIGHT
        ratioChip.text = aspectLabel(prefs.aspect)
        timerBtn.setActive(prefs.timerSec > 0)
        updateFlashIcon()
        updateAiChip()
        applyManualState()
        layoutPreview()
        updateModeBar()
        updateZoomUi()
        updateVideoChips()
    }

    private fun aspectLabel(a: Int) = when (a) { 1 -> "16:9"; 2 -> "1:1"; else -> "4:3" }

    private fun openCamera() {
        val sc = act.scan ?: return
        val id: String
        var phys: String? = null
        var div = 1f
        if (usingFront) {
            id = sc.front?.id ?: run { showMsg("لا توجد كاميرا أمامية"); usingFront = false; return }
        } else {
            val w = sc.wide
            if (wideActive && w is WideSource.Cam) {
                id = w.cameraId
                phys = w.physicalId
                div = 0.8f
            } else {
                wideActive = false
                id = sc.main?.id ?: run { showMsg("لا توجد كاميرا خلفية"); return }
            }
        }
        engine.uiZoom = uiZoom
        engine.open(id, phys, div)
    }

    // ---------------- الزوم ----------------

    private fun minZoom(): Float {
        if (usingFront) return 1f
        return when (val w = act.scan?.wide) {
            is WideSource.ZoomRatio -> max(0.6f, w.minRatio)
            is WideSource.Cam -> 0.8f
            else -> 1f
        }
    }

    private fun wideAvailable(): Boolean {
        val w = act.scan?.wide
        return !usingFront && (w is WideSource.ZoomRatio || w is WideSource.Cam)
    }

    private fun setZoom(z: Float) {
        val minZ = minZoom()
        val maxZ = prefs.maxZoom.toFloat()
        val nz = z.coerceIn(minZ, maxZ)
        val w = act.scan?.wide
        if (!usingFront && w is WideSource.Cam) {
            if (wideActive && nz >= 1.0f) {
                wideActive = false
                uiZoom = nz
                openCamera()
                updateZoomUi()
                return
            }
            if (!wideActive && nz < 1.0f) {
                wideActive = true
                uiZoom = max(0.8f, nz)
                openCamera()
                updateZoomUi()
                return
            }
        }
        uiZoom = nz
        engine.uiZoom = nz
        engine.refresh()
        updateZoomUi()
    }

    private fun onPresetTap(z: Float) {
        if (z < 1f && !wideAvailable()) { showWideExplain(); return }
        if (abs(uiZoom - z) < 0.05f) { showDial(); return }
        val crossesCam = act.scan?.wide is WideSource.Cam && ((uiZoom >= 1f) != (z >= 1f))
        if (crossesCam) { setZoom(z); return }
        val a = ValueAnimator.ofFloat(ln(uiZoom), ln(z))
        a.duration = 240
        a.addUpdateListener { setZoom(exp(it.animatedValue as Float)) }
        a.start()
    }

    private fun showWideExplain() {
        val sc = act.scan
        val msg = (sc?.wideNote ?: "") + "\n\nلن أعرض 0.8x كاذبة: لا أستخدم القص الرقمي على أنه زاوية واسعة. " +
            "افتح «تقرير قدرات الكاميرا» لاختبار الكاميرا الثانية فعليًا."
        AlertDialog.Builder(act)
            .setTitle("0.8x غير متاح حاليًا")
            .setMessage(msg)
            .setPositiveButton("تقرير الكاميرا") { _, _ -> act.open(ReportScreen(act)) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun fmtPreset(z: Float): String = if (z < 1f) f1(z) + "x" else z.toInt().toString() + "x"

    private fun updateZoomUi() {
        var active = 0
        for (i in presets.indices) if (uiZoom >= presets[i] - 0.05f) active = i
        for (i in presets.indices) {
            val p = pills[i]
            val z = presets[i]
            p.visibility = if ((usingFront && z < 1f) || z > prefs.maxZoom) View.GONE else View.VISIBLE
            val isActive = i == active
            p.text = if (isActive && abs(uiZoom - z) >= 0.05f) f1(uiZoom) + "x" else fmtPreset(z)
            p.setTextColor(if (isActive) K.CYAN else Color.WHITE)
            p.alpha = if (z < 1f && !wideAvailable()) 0.45f else 1f
            p.background = glass(act, 19f, true, isActive)
        }
        dial.minZ = minZoom()
        dial.maxZ = prefs.maxZoom.toFloat()
        dial.value = uiZoom
        val extra = engine.extraZoom()
        warnText = if (extra > 1.01f) "تكبير برمجي ×" + f1(extra) + " — لا تُضاف تفاصيل حقيقية والجودة تنخفض"
        else if (uiZoom > 5f) "تكبير رقمي — الجودة تنخفض"
        else ""
        refreshWarn()
    }

    private fun showDial() {
        handler.removeCallbacks(dialHide)
        dial.visibility = View.VISIBLE
        dial.animate().alpha(1f).setDuration(120).start()
        pillsRow.animate().alpha(0f).setDuration(120).start()
        handler.postDelayed(dialHide, 1800)
    }

    private fun hideDial() {
        dial.animate().alpha(0f).setDuration(200).withEndAction { dial.visibility = View.INVISIBLE }.start()
        pillsRow.animate().alpha(1f).setDuration(200).start()
    }

    // ---------------- رسائل ----------------

    private fun showMsg(t: String, ms: Long = 2600L) {
        tempMsgActive = true
        msgPill.text = t
        msgPill.visibility = View.VISIBLE
        handler.removeCallbacks(hideMsg)
        handler.postDelayed(hideMsg, ms)
    }

    private fun refreshWarn() {
        if (tempMsgActive) return
        if (warnText.isEmpty()) {
            msgPill.visibility = View.GONE
        } else {
            msgPill.text = warnText
            msgPill.visibility = View.VISIBLE
        }
    }

    // ---------------- الأوضاع والإعدادات السريعة ----------------

    private fun updateModeBar() {
        for (i in modeViews.indices) {
            val sel = Mode.values()[i] == mode
            modeViews[i].setTextColor(if (sel) K.YELLOW else Color.WHITE)
            modeViews[i].alpha = if (recording && !sel) 0.35f else 1f
        }
    }

    private fun setMode(m: Mode) {
        if (recording) { showMsg("أوقف التسجيل لتغيير الوضع"); return }
        if (m == mode) return
        val oldVideo = mode == Mode.VIDEO
        mode = m
        engine.videoMode = m == Mode.VIDEO
        engine.nightScene = m == Mode.NIGHT
        shutter.videoMode = m == Mode.VIDEO
        videoBar.visibility = if (m == Mode.VIDEO) View.VISIBLE else View.GONE
        if (m != Mode.VIDEO) manualVideo = false
        applyManualState()
        updateModeBar()
        layoutPreview()
        if (oldVideo != (m == Mode.VIDEO)) engine.restartPreview() else engine.refresh()
        updateFlashIcon()
        if (m == Mode.PORTRAIT) showMsg("بورتريه: تمويه الخلفية يتطلب وجود شخص في الإطار")
        if (m == Mode.NIGHT) showMsg("ليلي: وضع المشهد الليلي في الكاميرا + معالجة ألوان للإضاءة الضعيفة")
    }

    private fun applyManualState() {
        val on = mode == Mode.PRO || (mode == Mode.VIDEO && manualVideo)
        proPanel.view.visibility = if (on) View.VISIBLE else View.GONE
        engine.manualOn = on
        manualChip.setTextColor(if (manualVideo) K.CYAN else Color.WHITE)
        manualChip.background = glass(act, 18f, false, manualVideo)
        engine.refresh()
    }

    private fun flashModes(): List<Int> = if (mode == Mode.VIDEO) listOf(0, 3) else listOf(0, 1, 2, 3)

    private fun cycleFlash() {
        val inf = engine.info
        if (inf != null && !inf.flash) { showMsg("هذه الكاميرا بلا فلاش LED"); return }
        val list = flashModes()
        val cur = list.indexOf(prefs.flashMode)
        prefs.flashMode = list[(cur + 1) % list.size]
        engine.flashMode = prefs.flashMode
        updateFlashIcon()
        engine.refresh()
        showMsg(
            when (prefs.flashMode) {
                0 -> "الفلاش: إيقاف"
                1 -> "الفلاش: تلقائي"
                2 -> "الفلاش: تشغيل عند الالتقاط"
                else -> "المصباح: يعمل باستمرار"
            }
        )
    }

    private fun updateFlashIcon() {
        val list = flashModes()
        if (!list.contains(prefs.flashMode)) { prefs.flashMode = 0; engine.flashMode = 0 }
        flashBtn.icon.kind = when (prefs.flashMode) {
            1 -> IconView.Kind.BOLT_AUTO
            2 -> IconView.Kind.BOLT
            3 -> IconView.Kind.BOLT_TORCH
            else -> IconView.Kind.BOLT_OFF
        }
        flashBtn.setActive(prefs.flashMode != 0)
    }

    private fun cycleAspect() {
        if (mode == Mode.VIDEO) { showMsg("الفيديو يستخدم نسبة 16:9"); return }
        if (recording) return
        prefs.aspect = (prefs.aspect + 1) % 3
        engine.aspect = prefs.aspect
        ratioChip.text = aspectLabel(prefs.aspect)
        layoutPreview()
        engine.restartPreview()
    }

    private fun updateAiChip() {
        val on = prefs.aiColor || wideActive || mode == Mode.NIGHT
        aiChip.setTextColor(if (on) K.CYAN else Color.WHITE)
        aiChip.background = glass(act, 9f, false, on)
    }

    // ---------------- الفيديو: خيارات ----------------

    private fun currentQuality(): Int {
        val pref = prefs.videoQuality
        if (videoQ.any { it.quality == pref }) return pref
        val q1080 = videoQ.firstOrNull { it.quality == CamcorderProfile.QUALITY_1080P }
        return q1080?.quality ?: videoQ.firstOrNull()?.quality ?: -1
    }

    private fun fpsOptions(): List<Int> {
        val inf = engine.info ?: return listOf(30)
        val out = ArrayList<Int>()
        for (f in listOf(24, 30, 60)) if (inf.fpsRanges.any { it.first <= f && f <= it.second }) out.add(f)
        return if (out.isEmpty()) listOf(30) else out
    }

    private fun updateVideoChips() {
        val q = videoQ.firstOrNull { it.quality == currentQuality() }
        qualityChip.text = if (q != null) q.label else "—"
        val fps = if (fpsOptions().contains(prefs.videoFps)) prefs.videoFps else 30
        fpsChip.text = fps.toString() + " fps"
        stabChip.text = when (prefs.stabMode) { 0 -> "ثبات: إيقاف"; 1 -> "ثبات: عادي"; else -> "ثبات: نشط" }
    }

    private fun cycleQuality() {
        if (recording) return
        if (videoQ.isEmpty()) { showMsg("لا توجد ملفات فيديو مدعومة لهذه الكاميرا"); return }
        val i = videoQ.indexOfFirst { it.quality == currentQuality() }
        val n = videoQ[(i + 1) % videoQ.size]
        prefs.videoQuality = n.quality
        updateVideoChips()
        showMsg("الدقة: ${n.label} (${n.w}×${n.h}) — مدعومة من ملفات الجهاز")
    }

    private fun cycleFps() {
        if (recording) return
        val opts = fpsOptions()
        val i = opts.indexOf(prefs.videoFps)
        prefs.videoFps = opts[(i + 1) % opts.size]
        updateVideoChips()
        showMsg("إن لم يدعم الجهاز هذا المعدل مع الدقة، سأعود تلقائيًا إلى 1080p/30 وأخبرك")
    }

    private fun cycleStab() {
        if (recording) return
        prefs.stabMode = (prefs.stabMode + 1) % 3
        engine.stabMode = prefs.stabMode
        updateVideoChips()
        val inf = engine.info
        val eis = inf != null && inf.eisModes.contains(1)
        val ois = inf != null && inf.oisModes.contains(1)
        val pv = inf != null && inf.previewStabilization
        showMsg(
            "EIS: " + (if (eis) "متاح" else "غير متاح") + " · OIS: " + (if (ois) "متاح" else "غير متاح") +
                " · نشط الكامل: " + (if (pv) "متاح" else "غير متاح"),
            4000L
        )
        engine.refresh()
    }

    // ---------------- الالتقاط والتسجيل ----------------

    private fun onShutter() {
        if (!permissionOk) { act.requestAppPermissions(); return }
        if (mode == Mode.VIDEO) { toggleRecording(); return }
        if (countdownActive) { cancelCountdown(); return }
        val t = prefs.timerSec
        if (t > 0) startCountdown(t) else takePhoto()
    }

    private fun takePhoto() {
        if (engine.info == null) { showMsg("الكاميرا لم تفتح بعد"); return }
        if (prefs.shutterSound) try { sound.play(MediaActionSound.SHUTTER_CLICK) } catch (e: Exception) { /* تجاهل */ }
        flashOverlay.animate().cancel()
        flashOverlay.alpha = 0.7f
        flashOverlay.animate().alpha(0f).setDuration(180).start()
        val ai = prefs.aiColor || wideActive || mode == Mode.NIGHT
        val preset = when {
            wideActive -> ColorEngine.WIDE2MP
            mode == Mode.NIGHT -> ColorEngine.NIGHT
            else -> ColorEngine.byStrength(prefs.aiStrength)
        }
        val params = PhotoPipeline.Params(
            aspect = prefs.aspect,
            extraZoom = engine.extraZoom(),
            aiColor = ai,
            preset = preset,
            portrait = mode == Mode.PORTRAIT,
            portraitBlur = prefs.portraitBlur / 100f,
            saveOriginal = prefs.saveOriginal,
            quality = prefs.jpegQuality
        )
        if (ai || mode == Mode.PORTRAIT || params.extraZoom > 1.02f) showMsg("جارٍ المعالجة والحفظ…", 6000L)
        engine.capture(devOrientation, params)
    }

    private fun startCountdown(sec: Int) {
        countdownActive = true
        var n = sec
        val tick = object : Runnable {
            override fun run() {
                if (!countdownActive) return
                if (n <= 0) {
                    countdownText.visibility = View.GONE
                    countdownActive = false
                    takePhoto()
                    return
                }
                countdownText.text = n.toString()
                countdownText.visibility = View.VISIBLE
                n--
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(tick)
    }

    private fun cancelCountdown() {
        countdownActive = false
        countdownText.visibility = View.GONE
    }

    private fun toggleRecording() {
        if (startingRec) return
        if (!recording) {
            val q = currentQuality()
            if (q < 0) { showMsg("لا يدعم الجهاز تسجيل الفيديو بهذه الكاميرا"); return }
            val fps = if (fpsOptions().contains(prefs.videoFps)) prefs.videoFps else 30
            engine.stabMode = prefs.stabMode
            engine.videoFps = fps
            startingRec = true
            engine.startRecording(q, fps, act.hasAudioPermission(), devOrientation)
            if (!act.hasAudioPermission()) showMsg("بدون صوت: لم تُمنح صلاحية الميكروفون", 3000L)
        } else {
            engine.stopRecording()
        }
    }

    private fun startTicker() {
        val r = object : Runnable {
            override fun run() {
                if (!recording) return
                val s = (SystemClock.elapsedRealtime() - engine.recordStartMs) / 1000L
                val free = MediaStorage.freeBytes()
                recText.text = String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60) +
                    "  ·  " + f1(free / 1073741824f) + "GB"
                if (free < 120L * 1024L * 1024L) {
                    showMsg("توقف التسجيل: المساحة شبه ممتلئة", 4000L)
                    engine.stopRecording()
                    return
                }
                handler.postDelayed(this, 500)
            }
        }
        recTicker = r
        handler.post(r)
    }

    private fun flipCamera() {
        if (recording) { showMsg("لا يمكن تبديل الكاميرا أثناء التسجيل"); return }
        val sc = act.scan
        if (sc?.front == null) { showMsg("لا توجد كاميرا أمامية"); return }
        usingFront = !usingFront
        wideActive = false
        uiZoom = 1f
        engine.uiZoom = 1f
        updateZoomUi()
        updateFlashIcon()
        updateAiChip()
        openCamera()
    }

    private fun onTapFocus(x: Float, y: Float) {
        val w = previewHolder.width.toFloat()
        val h = previewHolder.height.toFloat()
        if (w <= 0f || h <= 0f) return
        focusRing.animate().cancel()
        focusRing.translationX = x - act.dp(35)
        focusRing.translationY = y - act.dp(35)
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.alpha = 1f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(180).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(700).setDuration(300).start()
        }.start()
        engine.focusAt(x / w, y / h)
    }

    // ---------------- المعرض ----------------

    private fun refreshThumb() {
        Thread {
            val hidden = prefs.trashMap().keys
            val li = MediaStorage.latest(act, hidden)
            act.runOnUiThread {
                if (li == null) thumb.setImageDrawable(null)
                else act.thumbs.load(li.uri, 160) { b -> thumb.setImageBitmap(b) }
            }
        }.start()
    }

    private fun openLatest() {
        Thread {
            val hidden = prefs.trashMap().keys
            val list = MediaStorage.list(act).filter { !hidden.contains(it.id) }
            act.runOnUiThread {
                if (list.isEmpty()) showMsg("لا توجد ملفات بعد") else act.open(ViewerScreen(act, list, 0, false))
            }
        }.start()
    }

    // ---------------- ردود المحرك ----------------

    override fun onOpened(info: CamInfo) {
        videoQ = DeviceScanner.videoQualities(info.id)
        proPanel.bind(info)
        updateVideoChips()
        updateZoomUi()
        updateAiChip()
        if (wideActive) {
            showMsg("عدسة 0.8x: الكاميرا ${info.id} (${f1(info.megapixels)}MP) — AI Color تلقائي لتحسين الألوان", 3800L)
        }
    }

    override fun onError(message: String) {
        startingRec = false
        showMsg(message, 4500L)
    }

    override fun onPhoto(out: PhotoPipeline.Out) {
        showMsg(out.message, 4000L)
        refreshThumb()
    }

    override fun onRecordingStarted() {
        startingRec = false
        recording = true
        shutter.recording = true
        videoBar.visibility = View.GONE
        recBar.visibility = View.VISIBLE
        updateModeBar()
        if (prefs.shutterSound) try { sound.play(MediaActionSound.START_VIDEO_RECORDING) } catch (e: Exception) { /* تجاهل */ }
        startTicker()
    }

    override fun onRecordingFinished(uri: Uri?, message: String, ok: Boolean) {
        startingRec = false
        recording = false
        shutter.recording = false
        recBar.visibility = View.GONE
        if (mode == Mode.VIDEO) videoBar.visibility = View.VISIBLE
        updateModeBar()
        if (prefs.shutterSound) try { sound.play(MediaActionSound.STOP_VIDEO_RECORDING) } catch (e: Exception) { /* تجاهل */ }
        showMsg(message, 4500L)
        refreshThumb()
    }

    override fun onNote(message: String) {
        showMsg(message, 3500L)
    }
}
