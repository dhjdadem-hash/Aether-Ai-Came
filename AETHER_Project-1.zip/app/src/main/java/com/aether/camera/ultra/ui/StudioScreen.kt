package com.aether.camera.ultra.ui

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aether.camera.ultra.MainActivity
import com.aether.camera.ultra.media.MediaItem
import com.aether.camera.ultra.media.MediaStorage
import java.util.Locale

class StudioScreen(private val act: MainActivity) : Screen {
    private val prefs = act.prefs
    private val root = FrameLayout(act)
    override val view: View = root
    private val recycler = RecyclerView(act)
    private val header = LinearLayout(act)
    private val normalBar = LinearLayout(act)
    private val selBar = LinearLayout(act)
    private val title = label(act, "الاستوديو", 20f, Color.WHITE, true)
    private val selCount = label(act, "", 17f, Color.WHITE, true)
    private val emptyText = label(act, "لا توجد ملفات هنا بعد", 15f, K.WHITE55)
    private val chips = ArrayList<TextView>()
    private val emptyTrash = chip(act, "إفراغ السلة")
    private var all: List<MediaItem> = emptyList()
    private var shown: List<MediaItem> = emptyList()
    private var filter = 0
    private val selected = LinkedHashSet<Long>()
    private val cellPx = act.resources.displayMetrics.widthPixels / 3
    private val adapter = Adapter()
    private val names = listOf("الكل", "صور", "فيديو", "المفضلة", "المحذوفات")

    init {
        root.setBackgroundColor(Color.BLACK)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        header.orientation = LinearLayout.VERTICAL
        header.setBackgroundColor(Color.parseColor("#F2000000"))

        normalBar.orientation = LinearLayout.HORIZONTAL
        normalBar.gravity = Gravity.CENTER_VERTICAL
        val back = GlassIconButton(act, IconView.Kind.BACK, 42)
        back.icon.rotation = 180f
        back.onTap { act.close() }
        normalBar.addView(back, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        title.setPadding(act.dp(12), 0, act.dp(12), 0)
        normalBar.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        emptyTrash.visibility = View.GONE
        emptyTrash.onTap { confirmEmptyTrash() }
        normalBar.addView(emptyTrash, LinearLayout.LayoutParams(WRAP, WRAP))

        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.gravity = Gravity.CENTER_VERTICAL
        selBar.visibility = View.GONE
        val close = GlassIconButton(act, IconView.Kind.CLOSE, 42)
        close.onTap { clearSelection() }
        selBar.addView(close, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        selCount.setPadding(act.dp(12), 0, act.dp(12), 0)
        selBar.addView(selCount, LinearLayout.LayoutParams(0, WRAP, 1f))
        val share = GlassIconButton(act, IconView.Kind.SHARE, 42)
        share.onTap { shareSelected() }
        val fav = GlassIconButton(act, IconView.Kind.HEART, 42)
        fav.onTap { favSelected() }
        val restore = GlassIconButton(act, IconView.Kind.UNDO, 42)
        restore.onTap { restoreSelected() }
        val del = GlassIconButton(act, IconView.Kind.TRASH, 42)
        del.onTap { deleteSelected() }
        for (b in listOf(share, fav, restore, del)) {
            val p = LinearLayout.LayoutParams(act.dp(42), act.dp(42))
            p.marginStart = act.dp(8)
            selBar.addView(b, p)
        }
        selBar.tag = restore

        val bars = FrameLayout(act)
        bars.addView(normalBar, FrameLayout.LayoutParams(MATCH, WRAP))
        bars.addView(selBar, FrameLayout.LayoutParams(MATCH, WRAP))
        bars.setPadding(act.dp(12), 0, act.dp(12), 0)
        header.addView(bars, LinearLayout.LayoutParams(MATCH, WRAP))

        val chipScroll = HorizontalScrollView(act)
        chipScroll.isHorizontalScrollBarEnabled = false
        val chipRow = LinearLayout(act)
        chipRow.orientation = LinearLayout.HORIZONTAL
        chipRow.setPadding(act.dp(12), act.dp(8), act.dp(12), act.dp(8))
        for (i in names.indices) {
            val c = chip(act, names[i], i == 0)
            c.setOnClickListener { setFilter(i) }
            val p = LinearLayout.LayoutParams(WRAP, WRAP)
            p.marginEnd = act.dp(8)
            chipRow.addView(c, p)
            chips.add(c)
        }
        chipScroll.addView(chipRow)
        header.addView(chipScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = GridLayoutManager(act, 3)
        recycler.adapter = adapter
        recycler.clipToPadding = false
        root.addView(recycler, FrameLayout.LayoutParams(MATCH, MATCH))
        emptyText.gravity = Gravity.CENTER
        root.addView(emptyText, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(header, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
    }

    override fun onInsets(top: Int, bottom: Int) {
        header.setPadding(0, top + act.dp(6), 0, 0)
        header.post {
            recycler.setPadding(0, header.height, 0, bottom + act.dp(8))
        }
    }

    override fun onResume() {
        reload()
    }

    override fun onBack(): Boolean {
        if (selected.isNotEmpty()) { clearSelection(); return true }
        return false
    }

    private fun reload() {
        Thread {
            val list = MediaStorage.list(act)
            val now = System.currentTimeMillis()
            val trash = prefs.trashMap()
            val old = ArrayList<Long>()
            for ((id, ts) in trash) if (now - ts > 30L * 24L * 3600L * 1000L) old.add(id)
            if (old.isNotEmpty()) {
                for (it in list) if (old.contains(it.id)) MediaStorage.delete(act, it.uri)
                prefs.untrash(old)
            }
            val fresh = if (old.isEmpty()) list else list.filter { !old.contains(it.id) }
            act.runOnUiThread {
                all = fresh
                applyFilter()
            }
        }.start()
    }

    private fun setFilter(i: Int) {
        filter = i
        clearSelection()
        for (k in chips.indices) {
            chips[k].setTextColor(if (k == i) K.CYAN else Color.WHITE)
            chips[k].background = glass(act, 18f, false, k == i)
        }
        emptyTrash.visibility = if (i == 4) View.VISIBLE else View.GONE
        applyFilter()
    }

    private fun applyFilter() {
        val trash = prefs.trashMap()
        shown = when (filter) {
            1 -> all.filter { !it.isVideo && !trash.containsKey(it.id) }
            2 -> all.filter { it.isVideo && !trash.containsKey(it.id) }
            3 -> all.filter { prefs.isFav(it.id) && !trash.containsKey(it.id) }
            4 -> all.filter { trash.containsKey(it.id) }
            else -> all.filter { !trash.containsKey(it.id) }
        }
        title.text = "الاستوديو (" + shown.size + ")"
        emptyText.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun clearSelection() {
        selected.clear()
        updateSelUi()
        adapter.notifyDataSetChanged()
    }

    private fun updateSelUi() {
        val sel = selected.isNotEmpty()
        selBar.visibility = if (sel) View.VISIBLE else View.GONE
        normalBar.visibility = if (sel) View.GONE else View.VISIBLE
        selCount.text = selected.size.toString() + " محدد"
        val restoreBtn = selBar.tag as View
        restoreBtn.visibility = if (filter == 4) View.VISIBLE else View.GONE
    }

    private fun selectedItems(): List<MediaItem> = shown.filter { selected.contains(it.id) }

    private fun shareSelected() {
        val items = selectedItems()
        if (items.isEmpty()) return
        val uris = ArrayList<Uri>()
        for (i in items) uris.add(i.uri)
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "*/*"
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.startActivity(Intent.createChooser(intent, "مشاركة"))
    }

    private fun favSelected() {
        val items = selectedItems()
        val allFav = items.all { prefs.isFav(it.id) }
        for (i in items) prefs.setFav(i.id, !allFav)
        clearSelection()
        applyFilter()
    }

    private fun restoreSelected() {
        prefs.untrash(selected.toList())
        clearSelection()
        applyFilter()
    }

    private fun deleteSelected() {
        val items = selectedItems()
        if (items.isEmpty()) return
        if (filter == 4) {
            AlertDialog.Builder(act)
                .setTitle("حذف نهائي")
                .setMessage("سيتم حذف " + items.size + " عنصر نهائيًا ولا يمكن استرجاعها.")
                .setPositiveButton("حذف") { _, _ -> purge(items) }
                .setNegativeButton("إلغاء", null)
                .show()
        } else {
            prefs.trash(items.map { it.id })
            act.toast("نُقلت " + items.size + " عنصر إلى سلة المحذوفات (تُحذف نهائيًا بعد 30 يومًا)")
            clearSelection()
            applyFilter()
        }
    }

    private fun purge(items: List<MediaItem>) {
        Thread {
            var failed = 0
            for (i in items) {
                if (!MediaStorage.delete(act, i.uri)) failed++
            }
            prefs.untrash(items.map { it.id })
            act.runOnUiThread {
                if (failed > 0) act.toast("تعذر حذف $failed عنصر (ربما أُنشئ بنسخة سابقة من التطبيق)")
                clearSelection()
                reload()
            }
        }.start()
    }

    private fun confirmEmptyTrash() {
        val trash = prefs.trashMap()
        val items = all.filter { trash.containsKey(it.id) }
        if (items.isEmpty()) { act.toast("السلة فارغة"); return }
        AlertDialog.Builder(act)
            .setTitle("إفراغ السلة")
            .setMessage("حذف " + items.size + " عنصر نهائيًا؟")
            .setPositiveButton("إفراغ") { _, _ -> purge(items) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun onItemClick(pos: Int) {
        if (pos < 0 || pos >= shown.size) return
        val item = shown[pos]
        if (selected.isNotEmpty()) {
            if (!selected.add(item.id)) selected.remove(item.id)
            updateSelUi()
            adapter.notifyItemChanged(pos)
        } else {
            act.open(ViewerScreen(act, shown, pos, filter == 4))
        }
    }

    private fun onItemLong(pos: Int) {
        if (pos < 0 || pos >= shown.size) return
        selected.add(shown[pos].id)
        updateSelUi()
        adapter.notifyItemChanged(pos)
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000L
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    inner class VH(
        val cellView: FrameLayout,
        val iv: ImageView,
        val badge: TextView,
        val heart: IconView,
        val check: FrameLayout
    ) : RecyclerView.ViewHolder(cellView)

    inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val f = FrameLayout(act)
            f.layoutParams = RecyclerView.LayoutParams(cellPx, cellPx)
            f.setPadding(1, 1, 1, 1)
            val iv = ImageView(act)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setBackgroundColor(Color.parseColor("#1A1A22"))
            f.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            val badge = label(act, "", 11f, Color.WHITE, true)
            badge.setPadding(act.dp(6), act.dp(2), act.dp(6), act.dp(2))
            badge.background = glass(act, 8f, true)
            badge.visibility = View.GONE
            f.addView(badge, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).also {
                it.marginStart = act.dp(5); it.bottomMargin = act.dp(5)
            })
            val heart = IconView(act, IconView.Kind.HEART_FILL)
            heart.visibility = View.GONE
            f.addView(heart, FrameLayout.LayoutParams(act.dp(20), act.dp(20), Gravity.TOP or Gravity.END).also {
                it.topMargin = act.dp(5); it.marginEnd = act.dp(5)
            })
            val check = FrameLayout(act)
            check.setBackgroundColor(Color.parseColor("#664FE3FF"))
            val ck = IconView(act, IconView.Kind.CHECK)
            ck.setPadding(act.dp(10), act.dp(10), act.dp(10), act.dp(10))
            check.addView(ck, FrameLayout.LayoutParams(act.dp(44), act.dp(44), Gravity.CENTER))
            check.visibility = View.GONE
            f.addView(check, FrameLayout.LayoutParams(MATCH, MATCH))
            return VH(f, iv, badge, heart, check)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = shown[position]
            h.iv.setImageDrawable(null)
            h.iv.tag = item.id
            act.thumbs.load(item.uri, 256) { b ->
                if (h.iv.tag == item.id) h.iv.setImageBitmap(b)
            }
            when {
                item.isVideo -> { h.badge.text = "▶ " + fmtDur(item.durationMs); h.badge.visibility = View.VISIBLE }
                item.isAi -> { h.badge.text = "AI"; h.badge.visibility = View.VISIBLE }
                else -> h.badge.visibility = View.GONE
            }
            h.heart.visibility = if (prefs.isFav(item.id)) View.VISIBLE else View.GONE
            h.check.visibility = if (selected.contains(item.id)) View.VISIBLE else View.GONE
            h.cellView.setOnClickListener { onItemClick(h.bindingAdapterPosition) }
            h.cellView.setOnLongClickListener { onItemLong(h.bindingAdapterPosition); true }
        }
    }
}
