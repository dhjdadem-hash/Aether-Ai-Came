package com.aether.camera.ultra.media

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.util.Size
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.sqrt

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val isVideo: Boolean,
    val dateMs: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long
) {
    val isAi: Boolean get() = name.contains("_AI.")
    val baseName: String get() = name.substringBeforeLast('.').removeSuffix("_AI")
}

object MediaStorage {
    const val ALBUM = "AETHER"

    fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun saveJpeg(ctx: Context, bytes: ByteArray, displayName: String): Uri? {
        val cv = ContentValues()
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "$displayName.jpg")
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/$ALBUM")
        cv.put(MediaStore.Images.Media.IS_PENDING, 1)
        val res = ctx.contentResolver
        val uri = res.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        return try {
            val os = res.openOutputStream(uri) ?: throw IllegalStateException("no stream")
            os.use { it.write(bytes) }
            val done = ContentValues()
            done.put(MediaStore.Images.Media.IS_PENDING, 0)
            res.update(uri, done, null, null)
            uri
        } catch (e: Exception) {
            try { res.delete(uri, null, null) } catch (e2: Exception) { /* تجاهل */ }
            null
        }
    }

    fun saveBitmapJpeg(ctx: Context, bmp: Bitmap, displayName: String, quality: Int): Uri? {
        val bos = ByteArrayOutputStream(1 shl 20)
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos)
        return saveJpeg(ctx, bos.toByteArray(), displayName)
    }

    fun saveVideo(ctx: Context, file: File, displayName: String): Uri? {
        val cv = ContentValues()
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/$ALBUM")
        cv.put(MediaStore.Video.Media.IS_PENDING, 1)
        val res = ctx.contentResolver
        val uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        return try {
            val os = res.openOutputStream(uri) ?: throw IllegalStateException("no stream")
            file.inputStream().use { inp -> os.use { out -> inp.copyTo(out) } }
            val len = res.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
            if (len != file.length()) throw IllegalStateException("size mismatch")
            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            res.update(uri, done, null, null)
            uri
        } catch (e: Exception) {
            try { res.delete(uri, null, null) } catch (e2: Exception) { /* تجاهل */ }
            null
        }
    }

    fun list(ctx: Context): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        query(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Pictures/$ALBUM%", false, out)
        query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/$ALBUM%", true, out)
        out.sortByDescending { it.dateMs }
        return out
    }

    fun latest(ctx: Context, hidden: Set<Long>): MediaItem? = list(ctx).firstOrNull { !hidden.contains(it.id) }

    private fun query(ctx: Context, base: Uri, pathLike: String, video: Boolean, out: MutableList<MediaItem>) {
        val cols = ArrayList<String>()
        cols.add(MediaStore.MediaColumns._ID)
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME)
        cols.add(MediaStore.MediaColumns.DATE_ADDED)
        cols.add(MediaStore.MediaColumns.SIZE)
        cols.add(MediaStore.MediaColumns.WIDTH)
        cols.add(MediaStore.MediaColumns.HEIGHT)
        if (video) cols.add(MediaStore.MediaColumns.DURATION)
        try {
            val c = ctx.contentResolver.query(
                base, cols.toTypedArray(),
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", arrayOf(pathLike),
                MediaStore.MediaColumns.DATE_ADDED + " DESC"
            ) ?: return
            c.use {
                val iId = it.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDate = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val iSize = it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iW = it.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
                val iH = it.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
                val iDur = if (video) it.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION) else -1
                while (it.moveToNext()) {
                    val id = it.getLong(iId)
                    out.add(
                        MediaItem(
                            id, ContentUris.withAppendedId(base, id), it.getString(iName) ?: "",
                            video, it.getLong(iDate) * 1000L, it.getLong(iSize),
                            it.getInt(iW), it.getInt(iH), if (iDur >= 0) it.getLong(iDur) else 0L
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // تجاهل: قد لا تتوفر الأعمدة
        }
    }

    fun delete(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.delete(uri, null, null) > 0
    } catch (e: Exception) {
        false
    }

    private fun limit(d: ImageDecoder, w: Int, h: Int, maxPx: Int) {
        val px = w.toLong() * h.toLong()
        if (px > maxPx) {
            val s = sqrt(maxPx.toDouble() / px.toDouble())
            d.setTargetSize(max(1, (w * s).toInt()), max(1, (h * s).toInt()))
        }
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        d.isMutableRequired = true
    }

    fun decode(ctx: Context, uri: Uri, maxPixels: Int): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
            limit(d, info.size.width, info.size.height, maxPixels)
        }
    } catch (e: Exception) {
        null
    }

    fun decodeBytes(bytes: ByteArray, maxPixels: Int): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { d, info, _ ->
            limit(d, info.size.width, info.size.height, maxPixels)
        }
    } catch (e: Exception) {
        null
    }

    fun thumbnail(ctx: Context, uri: Uri, px: Int): Bitmap? = try {
        ctx.contentResolver.loadThumbnail(uri, Size(px, px), null)
    } catch (e: Exception) {
        null
    }

    fun freeBytes(): Long = try {
        StatFs(Environment.getExternalStorageDirectory().path).availableBytes
    } catch (e: Exception) {
        0L
    }
}
