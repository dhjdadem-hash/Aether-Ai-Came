package com.aether.camera.ultra.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/** عارض صور: تكبير بالقرص، سحب، نقر مزدوج، سحب جانبي للتنقل، ومقارنة قبل/بعد بخط قابل للسحب. */
class ZoomImageView(ctx: Context) : View(ctx) {

    var bmp: Bitmap? = null
        set(v) { field = v; fit(); invalidate() }
    var bmp2: Bitmap? = null
        set(v) { field = v; invalidate() }
    var compare: Boolean = false
        set(v) { field = v; invalidate() }
    var divider: Float = 0.5f
        set(v) { field = v; invalidate() }
    var scanFrac: Float = -1f
        set(v) { field = v; invalidate() }
    var onSwipe: ((Int) -> Unit)? = null
    var onTap: (() -> Unit)? = null

    private var scale = 1f
    private var baseScale = 1f
    private var tx = 0f
    private var ty = 0f
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var lastTapT = 0L
    private var lastTapX = 0f
    private val ui = Handler(Looper.getMainLooper())
    private val singleTap = Runnable { onTap?.invoke() }
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomTo((scale * d.scaleFactor).coerceIn(baseScale, baseScale * 8f), d.focusX, d.focusY)
            return true
        }
    })

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    private fun fit() {
        val b = bmp ?: return
        if (width == 0 || height == 0) return
        baseScale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        scale = baseScale
        clampPos()
    }

    private fun clampPos() {
        val b = bmp ?: return
        val cw = b.width * scale
        val ch = b.height * scale
        tx = if (cw <= width) (width - cw) / 2f else tx.coerceIn(width - cw, 0f)
        ty = if (ch <= height) (height - ch) / 2f else ty.coerceIn(height - ch, 0f)
    }

    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val k = target / scale
        tx = fx - (fx - tx) * k
        ty = fy - (fy - ty) * k
        scale = target
        clampPos()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scale, scale)
        canvas.drawBitmap(b, 0f, 0f, paint)
        val b2 = bmp2
        if (compare && b2 != null) {
            val cut = (divider * width - tx) / scale
            canvas.save()
            canvas.clipRect(cut, 0f, b.width.toFloat(), b.height.toFloat())
            dst.set(0f, 0f, b.width.toFloat(), b.height.toFloat())
            canvas.drawBitmap(b2, null, dst, paint)
            canvas.restore()
        }
        canvas.restore()

        if (compare && b2 != null) {
            val x = divider * width
            linePaint.color = Color.WHITE
            linePaint.strokeWidth = dpf(2f)
            canvas.drawLine(x, 0f, x, height.toFloat(), linePaint)
            linePaint.color = K.CYAN
            canvas.drawCircle(x, height / 2f, dpf(14f), linePaint)
            linePaint.color = Color.BLACK
            canvas.drawCircle(x, height / 2f, dpf(10f), linePaint)
            textPaint.color = Color.WHITE
            textPaint.typeface = Typeface.DEFAULT_BOLD
            textPaint.textSize = dpf(13f)
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("الأصل", dpf(12f), dpf(24f), textPaint)
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("AI", width - dpf(12f), dpf(24f), textPaint)
        }
        if (scanFrac >= 0f) {
            val x = scanFrac.coerceIn(0f, 1f) * width
            linePaint.color = Color.parseColor("#66000000")
            canvas.drawRect(x, 0f, width.toFloat(), height.toFloat(), linePaint)
            linePaint.color = K.CYAN
            linePaint.strokeWidth = dpf(3f)
            canvas.drawLine(x, 0f, x, height.toFloat(), linePaint)
            linePaint.color = Color.parseColor("#334FE3FF")
            canvas.drawRect(x - dpf(26f), 0f, x, height.toFloat(), linePaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (compare && bmp2 != null) {
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                divider = (e.x / width).coerceIn(0.02f, 0.98f)
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            return true
        }
        scaleDet.onTouchEvent(e)
        if (scaleDet.isInProgress) { moved = true; return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1) {
                    if (abs(e.x - downX) > dpf(8f) || abs(e.y - downY) > dpf(8f)) moved = true
                    if (scale > baseScale * 1.01f) {
                        tx += e.x - lastX
                        ty += e.y - lastY
                        clampPos()
                        invalidate()
                    }
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_POINTER_DOWN -> {
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (!moved) {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastTapT < 300L && abs(e.x - lastTapX) < dpf(40f)) {
                        ui.removeCallbacks(singleTap)
                        lastTapT = 0L
                        val target = if (scale > baseScale * 1.1f) baseScale else baseScale * 2.5f
                        zoomTo(target, e.x, e.y)
                    } else {
                        lastTapT = now
                        lastTapX = e.x
                        ui.postDelayed(singleTap, 300L)
                    }
                } else if (scale <= baseScale * 1.02f && abs(dx) > dpf(70f) && abs(dx) > abs(dy) * 1.5f) {
                    onSwipe?.invoke(if (dx < 0) 1 else -1)
                }
            }
            else -> {}
        }
        return true
    }
}
