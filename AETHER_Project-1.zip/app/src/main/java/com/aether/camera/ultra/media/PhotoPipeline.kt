package com.aether.camera.ultra.media

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.aether.camera.ultra.ai.ColorEngine
import com.aether.camera.ultra.ai.PortraitEngine
import com.aether.camera.ultra.ui.f1
import kotlin.math.max
import kotlin.math.min

object PhotoPipeline {

    class Params(
        val aspect: Int = 0,
        val extraZoom: Float = 1f,
        val aiColor: Boolean = false,
        val preset: ColorEngine.Preset = ColorEngine.NATURAL,
        val portrait: Boolean = false,
        val portraitBlur: Float = 0.6f,
        val saveOriginal: Boolean = true,
        val quality: Int = 95
    )

    class Out(val originalUri: Uri?, val resultUri: Uri?, val message: String, val ok: Boolean)

    fun cropSquare(b: Bitmap): Bitmap {
        val s = min(b.width, b.height)
        return Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
    }

    fun digitalZoom(b: Bitmap, z: Float): Bitmap {
        val cw = max(8, (b.width / z).toInt())
        val ch = max(8, (b.height / z).toInt())
        val crop = Bitmap.createBitmap(b, (b.width - cw) / 2, (b.height - ch) / 2, cw, ch)
        return Bitmap.createScaledBitmap(crop, b.width, b.height, true)
    }

    fun process(ctx: Context, bytes: ByteArray, p: Params): Out {
        val base = "AETHER_" + MediaStorage.stamp()
        val needsCrop = p.aspect == 2 || p.extraZoom > 1.02f
        val needsPost = needsCrop || p.aiColor || p.portrait
        var orig: Uri? = null
        if (p.saveOriginal || !needsPost) orig = MediaStorage.saveJpeg(ctx, bytes, base)
        if (!needsPost) {
            return Out(orig, null, if (orig != null) "تم حفظ الصورة" else "فشل حفظ الصورة", orig != null)
        }
        val notes = ArrayList<String>()
        var bmp: Bitmap? = MediaStorage.decodeBytes(bytes, 12_000_000)
        if (bmp == null) {
            if (orig == null) orig = MediaStorage.saveJpeg(ctx, bytes, base)
            return Out(orig, null, "تم حفظ الأصل فقط (تعذر فك الصورة للمعالجة)", orig != null)
        }
        try {
            if (p.aspect == 2) bmp = cropSquare(bmp)
            if (p.extraZoom > 1.02f) {
                bmp = digitalZoom(bmp, p.extraZoom)
                notes.add("تكبير برمجي ×" + f1(p.extraZoom) + " (بدون إضافة تفاصيل)")
            }
            if (p.portrait) {
                val err = arrayOfNulls<String>(1)
                val mask = PortraitEngine.segment(bmp, err)
                if (mask != null) {
                    bmp = PortraitEngine.render(bmp, mask, p.portraitBlur)
                    notes.add("بورتريه: تمويه الخلفية")
                } else {
                    notes.add(err[0] ?: "تعذر البورتريه")
                }
            }
            if (p.aiColor) {
                val r = ColorEngine.enhance(bmp, p.preset)
                bmp = r.bitmap
                notes.add("AI Color (" + p.preset.name + "): " + r.stats.describe())
            }
            val res = MediaStorage.saveBitmapJpeg(ctx, bmp, base + "_AI", p.quality)
            if (orig == null && res == null) orig = MediaStorage.saveJpeg(ctx, bytes, base)
            val ok = res != null || orig != null
            val msg = if (ok) "تم الحفظ — " + notes.joinToString(" · ") else "فشل الحفظ"
            return Out(orig, res, msg, ok)
        } catch (e: OutOfMemoryError) {
            if (orig == null) orig = MediaStorage.saveJpeg(ctx, bytes, base)
            return Out(orig, null, "تم حفظ الأصل فقط (الذاكرة لا تكفي للمعالجة)", orig != null)
        } catch (e: Exception) {
            if (orig == null) orig = MediaStorage.saveJpeg(ctx, bytes, base)
            return Out(orig, null, "تم حفظ الأصل فقط: " + (e.message ?: ""), orig != null)
        }
    }
}
