package com.aether.camera.ultra.ui

import android.view.View

interface Screen {
    val view: View
    fun onInsets(top: Int, bottom: Int) {}
    fun onResume() {}
    fun onPause() {}
    fun onBack(): Boolean = false
}
