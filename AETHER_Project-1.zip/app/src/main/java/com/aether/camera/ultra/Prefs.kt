package com.aether.camera.ultra

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("aether_prefs", Context.MODE_PRIVATE)

    var aspect: Int
        get() = sp.getInt("aspect", 0)
        set(v) { sp.edit().putInt("aspect", v).apply() }
    var jpegQuality: Int
        get() = sp.getInt("jpegQuality", 95)
        set(v) { sp.edit().putInt("jpegQuality", v).apply() }
    var saveOriginal: Boolean
        get() = sp.getBoolean("saveOriginal", true)
        set(v) { sp.edit().putBoolean("saveOriginal", v).apply() }
    var aiColor: Boolean
        get() = sp.getBoolean("aiColor", false)
        set(v) { sp.edit().putBoolean("aiColor", v).apply() }
    var aiStrength: Int
        get() = sp.getInt("aiStrength", 1)
        set(v) { sp.edit().putInt("aiStrength", v).apply() }
    var grid: Boolean
        get() = sp.getBoolean("grid", true)
        set(v) { sp.edit().putBoolean("grid", v).apply() }
    var shutterSound: Boolean
        get() = sp.getBoolean("shutterSound", true)
        set(v) { sp.edit().putBoolean("shutterSound", v).apply() }
    var maxZoom: Int
        get() = sp.getInt("maxZoom", 120)
        set(v) { sp.edit().putInt("maxZoom", v).apply() }
    var stabMode: Int
        get() = sp.getInt("stabMode", 1)
        set(v) { sp.edit().putInt("stabMode", v).apply() }
    var videoQuality: Int
        get() = sp.getInt("videoQuality", -1)
        set(v) { sp.edit().putInt("videoQuality", v).apply() }
    var videoFps: Int
        get() = sp.getInt("videoFps", 30)
        set(v) { sp.edit().putInt("videoFps", v).apply() }
    var flashMode: Int
        get() = sp.getInt("flashMode", 0)
        set(v) { sp.edit().putInt("flashMode", v).apply() }
    var timerSec: Int
        get() = sp.getInt("timerSec", 0)
        set(v) { sp.edit().putInt("timerSec", v).apply() }
    var portraitBlur: Int
        get() = sp.getInt("portraitBlur", 60)
        set(v) { sp.edit().putInt("portraitBlur", v).apply() }
    var wideOverrideId: String
        get() = sp.getString("wideOverrideId", "") ?: ""
        set(v) { sp.edit().putString("wideOverrideId", v).apply() }

    private fun strSet(key: String): MutableSet<String> =
        HashSet(sp.getStringSet(key, emptySet()) ?: emptySet())

    fun isFav(id: Long): Boolean = strSet("fav").contains(id.toString())
    fun setFav(id: Long, on: Boolean) {
        val s = strSet("fav")
        if (on) s.add(id.toString()) else s.remove(id.toString())
        sp.edit().putStringSet("fav", s).apply()
    }

    fun isTrashed(id: Long): Boolean = trashMap().containsKey(id)
    fun trashMap(): Map<Long, Long> {
        val m = HashMap<Long, Long>()
        for (e in strSet("trash")) {
            val p = e.split(":")
            if (p.size == 2) {
                val a = p[0].toLongOrNull()
                val b = p[1].toLongOrNull()
                if (a != null && b != null) m[a] = b
            }
        }
        return m
    }
    fun trash(ids: Collection<Long>) {
        val s = strSet("trash")
        val now = System.currentTimeMillis()
        for (id in ids) s.add("$id:$now")
        sp.edit().putStringSet("trash", s).apply()
    }
    fun untrash(ids: Collection<Long>) {
        val m = trashMap()
        val s = HashSet<String>()
        for ((k, v) in m) if (!ids.contains(k)) s.add("$k:$v")
        sp.edit().putStringSet("trash", s).apply()
    }
}
