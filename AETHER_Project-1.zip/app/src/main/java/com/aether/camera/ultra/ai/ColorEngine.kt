package com.aether.camera.ultra.ai

import android.graphics.Bitmap
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** معالجة ألوان محلية حقيقية: توازن أبيض + مستويات + تشبع ذكي + تقليل ضوضاء لوني + وضوح. */
object ColorEngine {

    class Preset(
        val name: String,
        val wb: Float,
        val sat: Float,
        val nr: Float,
        val clarity: Float,
        val gammaMin: Float,
        val gammaMax: Float,
        val target: Float
    )

    val LIGHT = Preset("خفيف", 0.45f, 0.8f, 0.4f, 0.15f, 0.85f, 1.1f, 0.44f)
    val NATURAL = Preset("طبيعي", 0.65f, 1.0f, 0.5f, 0.25f, 0.78f, 1.15f, 0.46f)
    val STRONG = Preset("قوي", 0.85f, 1.25f, 0.6f, 0.35f, 0.72f, 1.2f, 0.48f)
    val WIDE2MP = Preset("عدسة 2MP", 0.9f, 1.3f, 0.85f, 0.2f, 0.7f, 1.2f, 0.47f)
    val NIGHT = Preset("ليلي", 0.5f, 1.05f, 1.0f, 0.2f, 0.55f, 1.0f, 0.5f)

    fun byStrength(i: Int): Preset = when (i) {
        0 -> LIGHT
        2 -> STRONG
        else -> NATURAL
    }

    class Stats(val gainR: Float, val gainB: Float, val satBefore: Float, val satBoost: Float, val gamma: Float) {
        fun describe(): String = String.format(
            Locale.US, "توازن اللون R×%.2f B×%.2f · تشبع ×%.2f · سطوع γ%.2f",
            gainR, gainB, satBoost, gamma
        )
    }

    class Result(val bitmap: Bitmap, val stats: Stats)

    private fun cl(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()

    fun enhance(src: Bitmap, p: Preset, progress: (Int) -> Unit = {}): Result {
        val w = src.width
        val h = src.height
        progress(3)

        // 1) تحليل على نسخة مصغرة
        val sc = 320f / max(w, h).toFloat()
        val aw = max(8, (w * sc).toInt())
        val ah = max(8, (h * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, aw, ah, true)
        val sp = IntArray(aw * ah)
        small.getPixels(sp, 0, aw, 0, 0, aw, ah)
        if (small !== src) small.recycle()

        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        var cnt = 0
        val hist = IntArray(256)
        for (px in sp) {
            val r = (px shr 16) and 255
            val g = (px shr 8) and 255
            val b = px and 255
            val y = (r * 299 + g * 587 + b * 114) / 1000
            hist[y]++
            if (y in 20..235) { sr += r; sg += g; sb += b; cnt++ }
        }
        var gR = 1f
        var gB = 1f
        if (cnt > 50 && sr > 1.0 && sb > 1.0) {
            val mr = sr / cnt
            val mg = sg / cnt
            val mb = sb / cnt
            gR = (mg / mr).toFloat().coerceIn(0.8f, 1.25f)
            gB = (mg / mb).toFloat().coerceIn(0.8f, 1.25f)
        }
        gR = 1f + (gR - 1f) * p.wb
        gB = 1f + (gB - 1f) * p.wb
        progress(10)

        // 2) مستويات
        val total = aw * ah
        var acc = 0
        var black = 0
        var white = 255
        var gotBlack = false
        for (i in 0..255) {
            acc += hist[i]
            if (!gotBlack && acc >= total * 0.005) { black = i; gotBlack = true }
            if (acc >= total * 0.995) { white = i; break }
        }
        black = black.coerceIn(0, 40)
        white = white.coerceIn(200, 255)
        val lscale = 255f / max(1, white - black).toFloat()

        var meanL = 0.0
        for (i in 0..255) meanL += hist[i] * (((i - black) * lscale).coerceIn(0f, 255f) / 255.0)
        meanL /= max(1, total).toDouble()
        val m = meanL.coerceIn(0.04, 0.96)
        var gm = (ln(p.target.toDouble()) / ln(m)).toFloat().coerceIn(p.gammaMin, p.gammaMax)
        gm = 1f + (gm - 1f) * 0.9f

        val gains = floatArrayOf(gR, 1f, gB)
        val luts = Array(3) { IntArray(256) }
        for (c in 0..2) {
            for (v in 0..255) {
                val a = min(255f, v * gains[c])
                val l = ((a - black) * lscale).coerceIn(0f, 255f) / 255f
                luts[c][v] = cl(l.toDouble().pow(gm.toDouble()).toFloat() * 255f)
            }
        }
        progress(14)

        // 3) تشبع: قياس ثم عامل
        var satSum = 0.0
        var satN = 0
        for (px in sp) {
            val r = luts[0][(px shr 16) and 255]
            val g = luts[1][(px shr 8) and 255]
            val b = luts[2][px and 255]
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            if (mx > 25) { satSum += (mx - mn).toDouble() / mx; satN++ }
        }
        val s0 = if (satN > 0) (satSum / satN).toFloat() else 0.3f
        val target = 0.30f * p.sat
        val base = 1f + 0.08f * p.sat
        val sBoost = max(base, if (s0 > 0.01f) min(1.6f, target / s0) else 1.6f)
        progress(18)

        // 4) نسخة ضبابية لتقليل الضوضاء اللونية والوضوح
        val useBlur = p.nr > 0f || p.clarity > 0f
        var bp: IntArray? = null
        if (useBlur) {
            val b1 = Bitmap.createScaledBitmap(src, max(2, w / 3), max(2, h / 3), true)
            val b2 = Bitmap.createScaledBitmap(b1, w, h, true)
            if (b1 !== src && b1 !== b2) b1.recycle()
            val arr = IntArray(w * h)
            b2.getPixels(arr, 0, w, 0, 0, w, h)
            if (b2 !== src) b2.recycle()
            bp = arr
        }
        progress(30)

        // 5) المرور الرئيسي
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lutR = luts[0]
        val lutG = luts[1]
        val lutB = luts[2]
        val nr = p.nr
        val clar = p.clarity
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val i = row + x
                val c = px[i]
                val r = lutR[(c shr 16) and 255]
                val g = lutG[(c shr 8) and 255]
                val b = lutB[c and 255]
                val yl = (r * 299 + g * 587 + b * 114) / 1000
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                var f = 1f + (sBoost - 1f) * (1f - 0.6f * sat)
                if (r > 95 && g > 40 && b > 20 && r > g && r > b && (mx - mn) > 15 && (r - g) > 8) {
                    f = 1f + (f - 1f) * 0.5f
                }
                var cr = (r - yl) * f
                var cg = (g - yl) * f
                var cb = (b - yl) * f
                var lift = 0f
                if (bp != null) {
                    val q = bp[i]
                    val br = lutR[(q shr 16) and 255]
                    val bg = lutG[(q shr 8) and 255]
                    val bb = lutB[q and 255]
                    val byl = (br * 299 + bg * 587 + bb * 114) / 1000
                    cr = cr * (1f - nr) + (br - byl) * f * nr
                    cg = cg * (1f - nr) + (bg - byl) * f * nr
                    cb = cb * (1f - nr) + (bb - byl) * f * nr
                    lift = ((yl - byl) * clar).coerceIn(-24f, 24f)
                }
                val ny = yl + lift
                px[i] = (0xFF shl 24) or (cl(ny + cr) shl 16) or (cl(ny + cg) shl 8) or cl(ny + cb)
            }
            if (y % 128 == 0) progress(30 + 65 * y / h)
        }
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        progress(100)
        return Result(out, Stats(gR, gB, s0, sBoost, gm))
    }

    @Suppress("unused")
    private fun unusedExp(v: Double) = exp(v)
}
