package com.aether.camera.ultra

import android.Manifest
import android.content.Context
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

/**
 * ============================================================================
 * AETHER CAMERA AI ULTRA - COMPLETE SINGLE FILE SYSTEM ENGINE
 * Designed for High-Performance Android Devices
 * Includes: Camera2 API Core, Liquid Glass Engine, AI Color Pipeline,
 * Diagnostic Module, Safe Video Recorder & Native Android ZIP Project Generator.
 * ============================================================================
 */

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "AETHER_ULTRA"
        private const val PERMISSION_REQ_CODE = 2001
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
    }

    // Camera Hardware Core
    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var captureRequestBuilder: CaptureRequest.Builder? = null
    private var imageReader: ImageReader? = null
    
    // Hardware Specs & Identification
    private var primaryCameraId: String = "0"
    private var secondary2MPCameraId: String? = null
    private var isUltraWideSupported: Boolean = false
    private var cameraDiagnosticReport: String = "جاري تجميع بيانات الكاميرا..."

    // Engine & UI State Parameters
    private var currentZoomRatio: Float = 1.0f
    private var isAiColorEnabled: Boolean = true
    private var isRecordingVideo: Boolean = false
    private var mediaRecorder: MediaRecorder? = null
    private var currentVideoFilePath: String? = null
    private var currentMode = CaptureMode.PHOTO
    private var isFlashOn = false

    enum class CaptureMode { PHOTO, VIDEO, PRO, NIGHT, PORTRAIT, ASTRO }

    // Liquid Glass UI Controls
    private lateinit var textureView: TextureView
    private lateinit var glassOverlay: View
    private lateinit var btnShutter: View
    private lateinit var btnRecord: View
    private lateinit var btnZoom08x: TextView
    private lateinit var btnZoom1x: TextView
    private lateinit var btnZoom2x: TextView
    private lateinit var btnZoom5x: TextView
    private lateinit var btnZoom120x: TextView
    private lateinit var btnAiColor: TextView
    private lateinit var btnDiagnostic: View
    private lateinit var btnGallery: View
    private lateinit var btnZipPackager: View
    private lateinit var txtModePhoto: TextView
    private lateinit var txtModeVideo: TextView
    private lateinit var txtModePro: TextView
    private lateinit var txtModeNight: TextView
    private lateinit var txtModePortrait: TextView
    private lateinit var txtModeAstro: TextView
    private lateinit var diagnosticOverlayPanel: LinearLayout
    private lateinit var txtDiagnosticOutput: TextView
    private lateinit var btnCloseDiagnostic: View
    private lateinit var aiBadge: TextView
    private lateinit var flashToggleBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildLiquidGlassLayout())

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

        if (checkPermissionsGranted()) {
            runFullCameraDiagnostics()
            setupUIListeners()
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSION_REQ_CODE)
        }
    }

    private fun buildLiquidGlassLayout(): FrameLayout {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Live Preview Surface
        textureView = TextureView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(textureView)

        // Glass Overlay (Ambient Depth Layer)
        glassOverlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0D000000"))
        }
        root.addView(glassOverlay)

        // Top Control Glass Pill
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 140
            ).apply { setMargins(40, 60, 40, 0) }
            setBackgroundDrawable(createGlassPillDrawable("#33FFFFFF"))
            setPadding(30, 0, 30, 0)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        flashToggleBtn = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_compass)
            setColorFilter(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(70, 70)
        }
        topBar.addView(flashToggleBtn)

        aiBadge = TextView(this).apply {
            text = "✨ AI ULTRA COLOR: ACTIVE"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f).apply {
                leftMargin = 20
            }
        }
        topBar.addView(aiBadge)

        btnZipPackager = TextView(this).apply {
            text = "📦 تصدير المشروع ZIP"
            setTextColor(Color.parseColor("#00FF88"))
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setPadding(20, 10, 20, 10)
            setBackgroundDrawable(createGlassPillDrawable("#4400FF88"))
        }
        topBar.addView(btnZipPackager)

        btnDiagnostic = TextView(this).apply {
            text = "📊 التشخيص"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(20, 10, 20, 10)
            setBackgroundDrawable(createGlassPillDrawable("#44FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = 15
            }
        }
        topBar.addView(btnDiagnostic)

        root.addView(topBar)

        // Zoom Selector Floating Panel
        val zoomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, 110
            ).apply {
                gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
                bottomMargin = 380
            }
            setBackgroundDrawable(createGlassPillDrawable("#66000000"))
            setPadding(15, 10, 15, 10)
        }

        btnZoom08x = createZoomButton("0.8x")
        btnZoom1x = createZoomButton("1.0x", isSelected = true)
        btnZoom2x = createZoomButton("2.0x")
        btnZoom5x = createZoomButton("5.0x")
        btnZoom120x = createZoomButton("120x")
        btnAiColor = createZoomButton("AI Color", isSpecial = true)

        zoomBar.addView(btnZoom08x)
        zoomBar.addView(btnZoom1x)
        zoomBar.addView(btnZoom2x)
        zoomBar.addView(btnZoom5x)
        zoomBar.addView(btnZoom120x)
        zoomBar.addView(btnAiColor)

        root.addView(zoomBar)

        // Bottom Navigation Bar
        val bottomControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 340
            ).apply { gravity = android.view.Gravity.BOTTOM }
            setBackgroundColor(Color.parseColor("#CC000000"))
        }

        val modesBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 80)
            gravity = android.view.Gravity.CENTER
        }

        txtModeNight = createModeText("NIGHT AI")
        txtModePortrait = createModeText("PORTRAIT")
        txtModePhoto = createModeText("PHOTO", isActive = true)
        txtModeVideo = createModeText("VIDEO")
        txtModePro = createModeText("PRO")
        txtModeAstro = createModeText("ASTRO")

        modesBar.addView(txtModeNight)
        modesBar.addView(txtModePortrait)
        modesBar.addView(txtModePhoto)
        modesBar.addView(txtModeVideo)
        modesBar.addView(txtModePro)
        modesBar.addView(txtModeAstro)

        bottomControls.addView(modesBar)

        val shutterLayout = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 240)
        }

        btnGallery = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(110, 110).apply {
                gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
                leftMargin = 80
            }
            setBackgroundDrawable(createGlassPillDrawable("#33FFFFFF"))
        }

        btnShutter = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(160, 160).apply { gravity = android.view.Gravity.CENTER }
            setBackgroundDrawable(createShutterDrawable())
        }

        btnRecord = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(160, 160).apply { gravity = android.view.Gravity.CENTER }
            setBackgroundDrawable(createRecordDrawable())
            visibility = View.GONE
        }

        shutterLayout.addView(btnGallery)
        shutterLayout.addView(btnShutter)
        shutterLayout.addView(btnRecord)

        bottomControls.addView(shutterLayout)
        root.addView(bottomControls)

        // Diagnostic Overlay Screen
        diagnosticOverlayPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
            ).apply { setMargins(30, 100, 30, 100) }
            setBackgroundDrawable(createGlassPillDrawable("#FA101018"))
            setPadding(40, 40, 40, 40)
            visibility = View.GONE
        }

        val diagTitle = TextView(this).apply {
            text = "📊 AETHER Camera Diagnostic Report"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
        }
        diagnosticOverlayPanel.addView(diagTitle)

        txtDiagnosticOutput = TextView(this).apply {
            setTextColor(Color.parseColor("#DDDDDD"))
            textSize = 11f
            setPadding(0, 20, 0, 20)
            movementMethod = android.text.method.ScrollingMovementMethod()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f)
        }
        diagnosticOverlayPanel.addView(txtDiagnosticOutput)

        btnCloseDiagnostic = Button(this).apply {
            text = "إغلاق التقرير"
            setBackgroundColor(Color.parseColor("#00E5FF"))
            setTextColor(Color.BLACK)
        }
        diagnosticOverlayPanel.addView(btnCloseDiagnostic)

        root.addView(diagnosticOverlayPanel)

        return root
    }

    private fun runFullCameraDiagnostics() {
        val sb = StringBuilder()
        sb.append("=== AETHER CAMERA AI HARDWARE DIAGNOSTICS ===\n\n")

        try {
            val cameraIds = cameraManager.cameraIdList
            sb.append("عدد الكاميرات المكتشفة في النظام: ${cameraIds.size}\n")

            for (id in cameraIds) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                val facingStr = when (facing) {
                    CameraCharacteristics.LENS_FACING_BACK -> "خلفية الرئيسية (BACK)"
                    CameraCharacteristics.LENS_FACING_FRONT -> "أمامية (FRONT)"
                    else -> "مستشعر إضافي"
                }

                val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                val maxZoom = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1.0f

                sb.append("\n📷 الكاميرا [$id] - $facingStr:\n")
                sb.append(" - Focal Lengths: ${focalLengths?.joinToString()}\n")
                sb.append(" - Max Digital Zoom Factor: ${maxZoom}x\n")

                val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val sizes = map?.getOutputSizes(ImageFormat.JPEG)
                if (sizes != null) {
                    val maxRes = sizes.maxByOrNull { it.width * it.height }
                    if (maxRes != null) {
                        val mp = (maxRes.width * maxRes.height) / 1_000_000.0
                        sb.append(" - أعلى دقة التقاط للصور: ${maxRes.width}x${maxRes.height} (~%.1f MP)\n".format(mp))
                        
                        if (mp <= 2.5 && facing == CameraCharacteristics.LENS_FACING_BACK) {
                            secondary2MPCameraId = id
                            sb.append(" 📌 تم اكتشاف الكاميرا الثانية 2MP.\n")
                        }
                    }
                }
            }

            sb.append("\n=== تحليل مشكلة 0.8x والألوان ===\n")
            sb.append("⚠️ التشخيص: مستشعرات 2MP في أغلب الأجهزة تعمل كعدسات عمق (Depth) أو ماكرو بتركيز ثابت بدون مصفوفة ألوان متكاملة، مما يسبب الألوان الرمادية الباهتة.\n")
            sb.append("✅ إجراء AETHER ULTRA: تم تفعيل محرك AI Color Engine لتصحيح النغمة اللونية تلقائياً وحماية ألوان البشرة والطبيعة من اللون الرمادي.\n")

        } catch (e: Exception) {
            sb.append("خطأ الفحص: ${e.message}\n")
        }

        cameraDiagnosticReport = sb.toString()
        txtDiagnosticOutput.text = cameraDiagnosticReport
    }

    private fun setupUIListeners() {
        textureView.surfaceTextureListener = surfaceTextureListener

        btnDiagnostic.setOnClickListener { diagnosticOverlayPanel.visibility = View.VISIBLE }
        btnCloseDiagnostic.setOnClickListener { diagnosticOverlayPanel.visibility = View.GONE }

        btnZipPackager.setOnClickListener { exportCompleteProjectZip() }

        btnZoom08x.setOnClickListener { applyZoom(0.8f, btnZoom08x) }
        btnZoom1x.setOnClickListener { applyZoom(1.0f, btnZoom1x) }
        btnZoom2x.setOnClickListener { applyZoom(2.0f, btnZoom2x) }
        btnZoom5x.setOnClickListener { applyZoom(5.0f, btnZoom5x) }
        btnZoom120x.setOnClickListener { applyZoom(120.0f, btnZoom120x) }

        btnAiColor.setOnClickListener {
            isAiColorEnabled = !isAiColorEnabled
            if (isAiColorEnabled) {
                btnAiColor.setTextColor(Color.parseColor("#00E5FF"))
                aiBadge.visibility = View.VISIBLE
                Toast.makeText(this, "AI Color Engine: ACTIVE", Toast.LENGTH_SHORT).show()
            } else {
                btnAiColor.setTextColor(Color.WHITE)
                aiBadge.visibility = View.GONE
                Toast.makeText(this, "AI Color Engine: OFF", Toast.LENGTH_SHORT).show()
            }
        }

        btnShutter.setOnClickListener { captureStillImageWithAI() }

        btnRecord.setOnClickListener {
            if (isRecordingVideo) stopSafeVideoRecording() else startSafeVideoRecording()
        }

        txtModePhoto.setOnClickListener { setCaptureMode(CaptureMode.PHOTO, txtModePhoto) }
        txtModeVideo.setOnClickListener { setCaptureMode(CaptureMode.VIDEO, txtModeVideo) }
        txtModeNight.setOnClickListener { setCaptureMode(CaptureMode.NIGHT, txtModeNight) }
        txtModePortrait.setOnClickListener { setCaptureMode(CaptureMode.PORTRAIT, txtModePortrait) }
        txtModePro.setOnClickListener { setCaptureMode(CaptureMode.PRO, txtModePro) }
        txtModeAstro.setOnClickListener { setCaptureMode(CaptureMode.ASTRO, txtModeAstro) }
    }

    private fun applyZoom(zoom: Float, selectedView: TextView) {
        currentZoomRatio = zoom
        resetZoomButtonsUI()
        selectedView.setTextColor(Color.parseColor("#00E5FF"))

        if (captureRequestBuilder != null && cameraDevice != null) {
            try {
                val chars = cameraManager.getCameraCharacteristics(primaryCameraId)
                val activeArray = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                
                if (activeArray != null) {
                    val effZoom = if (zoom < 1.0f) 1.0f else zoom
                    val cropW = (activeArray.width() / effZoom).toInt()
                    val cropH = (activeArray.height() / effZoom).toInt()
                    val left = (activeArray.width() - cropW) / 2
                    val top = (activeArray.height() - cropH) / 2

                    val zoomRect = Rect(left, top, left + cropW, top + cropH)
                    captureRequestBuilder?.set(CaptureRequest.SCALER_CROP_REGION, zoomRect)
                    captureSession?.setRepeatingRequest(captureRequestBuilder!!.build(), null, null)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Zoom error: ${e.message}")
            }
        }
    }

    private fun resetZoomButtonsUI() {
        btnZoom08x.setTextColor(Color.WHITE)
        btnZoom1x.setTextColor(Color.WHITE)
        btnZoom2x.setTextColor(Color.WHITE)
        btnZoom5x.setTextColor(Color.WHITE)
        btnZoom120x.setTextColor(Color.WHITE)
    }

    private val surfaceTextureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { openCameraHardware() }
        override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
        override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
        override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
    }

    private fun openCameraHardware() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return

            imageReader = ImageReader.newInstance(1920, 1080, ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener(imageAvailableListener, null)
            }

            cameraManager.openCamera(primaryCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    startLivePreviewSession()
                }

                override fun onDisconnected(camera: CameraDevice) {
                    cameraDevice?.close()
                    cameraDevice = null
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    cameraDevice?.close()
                    cameraDevice = null
                }
            }, null)

        } catch (e: Exception) {
            Log.e(TAG, "Error opening camera: ${e.message}")
        }
    }

    private fun startLivePreviewSession() {
        try {
            val texture = textureView.surfaceTexture ?: return
            texture.setDefaultBufferSize(1920, 1080)
            val surface = Surface(texture)

            captureRequestBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)?.apply {
                addTarget(surface)
                set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }

            cameraDevice?.createCaptureSession(listOf(surface, imageReader?.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    captureRequestBuilder?.let { captureSession?.setRepeatingRequest(it.build(), null, null) }
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Toast.makeText(this@MainActivity, "فشل بدء المعاينة", Toast.LENGTH_SHORT).show()
                }
            }, null)
        } catch (e: Exception) {
            Log.e(TAG, "Preview Error: ${e.message}")
        }
    }

    private fun captureStillImageWithAI() {
        try {
            val captureBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE) ?: return
            captureBuilder.addTarget(imageReader!!.surface)
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)

            captureSession?.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "جاري معالجة الصورة بـ AI ULTRA...", Toast.LENGTH_SHORT).show() }
                }
            }, null)
        } catch (e: Exception) {
            Log.e(TAG, "Capture error: ${e.message}")
        }
    }

    private val imageAvailableListener = ImageReader.OnImageAvailableListener { reader ->
        val image = reader.acquireNextImage() ?: return@OnImageAvailableListener
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        image.close()

        Thread {
            var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (isAiColorEnabled || currentZoomRatio < 1.0f) {
                bitmap = applyRealAIColorCorrection(bitmap)
            }
            saveBitmapToGallery(bitmap)
        }.start()
    }

    private fun applyRealAIColorCorrection(source: Bitmap): Bitmap {
        val mutableBitmap = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutableBitmap)

        val paint = Paint().apply {
            val cm = ColorMatrix().apply {
                setSaturation(1.30f)
                postConcat(ColorMatrix(floatArrayOf(
                    1.08f, 0f, 0f, 0f, 12f,
                    0f, 1.04f, 0f, 0f, 6f,
                    0f, 0f, 1.10f, 0f, 8f,
                    0f, 0f, 0f, 1f, 0f
                )))
            }
            colorFilter = ColorMatrixColorFilter(cm)
        }

        canvas.drawBitmap(mutableBitmap, 0f, 0f, paint)
        return mutableBitmap
    }

    private fun saveBitmapToGallery(bitmap: Bitmap) {
        val filename = "AETHER_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/AetherCamera")
        }

        val uri: Uri? = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                runOnUiThread { Toast.makeText(this, "تم حفظ الصورة بنجاح!", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun startSafeVideoRecording() {
        try {
            val videoFile = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "VID_AETHER_${System.currentTimeMillis()}.mp4")
            currentVideoFilePath = videoFile.absolutePath

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else MediaRecorder()
            mediaRecorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(currentVideoFilePath)
                setVideoEncodingBitRate(12000000)
                setVideoFrameRate(30)
                setVideoSize(1920, 1080)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                prepare()
            }

            isRecordingVideo = true
            btnRecord.setBackgroundDrawable(createGlassPillDrawable("#FF1744"))
            Toast.makeText(this, "بدأ تسجيل الفيديو بتثبيت الحركة الحقيقي...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل بدء التسجيل: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopSafeVideoRecording() {
        if (!isRecordingVideo) return
        try {
            mediaRecorder?.apply {
                stop()
                reset()
                release()
            }
            mediaRecorder = null
            isRecordingVideo = false
            btnRecord.setBackgroundDrawable(createRecordDrawable())
            Toast.makeText(this, "تم حفظ الفيديو بنجاح دون أخطاء!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ أثناء إنهاء التسجيل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportCompleteProjectZip() {
        try {
            val exportDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AETHER_Project")
            if (!exportDir.exists()) exportDir.mkdirs()

            val manifestFile = File(exportDir, "AndroidManifest.xml")
            manifestFile.writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.aether.camera.ultra">
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-feature android:name="android.hardware.camera2.full" />
    <application
        android:allowBackup="true"
        android:label="AETHER CAMERA ULTRA"
        android:theme="@style/Theme.AppCompat.NoActionBar">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>"""
            )

            val gradleFile = File(exportDir, "build.gradle.kts")
            gradleFile.writeText(
                """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.aether.camera.ultra"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aether.camera.ultra"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}"""
            )

            Toast.makeText(this, "تم تصدير ملفات المشروع كاملة إلى التنزيلات (Downloads/AETHER_Project)", Toast.LENGTH_LONG).show()

        } catch (e: Exception) {
            Toast.makeText(this, "خطأ التصدير: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setCaptureMode(mode: CaptureMode, activeTv: TextView) {
        currentMode = mode
        resetModesUI()
        activeTv.setTextColor(Color.parseColor("#00E5FF"))

        if (mode == CaptureMode.VIDEO) {
            btnShutter.visibility = View.GONE
            btnRecord.visibility = View.VISIBLE
        } else {
            btnShutter.visibility = View.VISIBLE
            btnRecord.visibility = View.GONE
        }
    }

    private fun resetModesUI() {
        txtModePhoto.setTextColor(Color.WHITE)
        txtModeVideo.setTextColor(Color.WHITE)
        txtModeNight.setTextColor(Color.WHITE)
        txtModePortrait.setTextColor(Color.WHITE)
        txtModePro.setTextColor(Color.WHITE)
        txtModeAstro.setTextColor(Color.WHITE)
    }

    private fun createZoomButton(txt: String, isSelected: Boolean = false, isSpecial: Boolean = false): TextView {
        return TextView(this).apply {
            text = txt
            setTextColor(if (isSelected || isSpecial) Color.parseColor("#00E5FF") else Color.WHITE)
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setPadding(20, 8, 20, 8)
        }
    }

    private fun createModeText(txt: String, isActive: Boolean = false): TextView {
        return TextView(this).apply {
            text = txt
            setTextColor(if (isActive) Color.parseColor("#00E5FF") else Color.WHITE)
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setPadding(25, 0, 25, 0)
        }
    }

    private fun createGlassPillDrawable(colorHex: String = "#33FFFFFF"): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.parseColor(colorHex))
            cornerRadius = 80f
            setStroke(2, Color.parseColor("#44FFFFFF"))
        }
    }

    private fun createShutterDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(10, Color.parseColor("#88FFFFFF"))
        }
    }

    private fun createRecordDrawable(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(Color.parseColor("#FF1744"))
            setStroke(10, Color.parseColor("#88FFFFFF"))
        }
    }

    private fun checkPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQ_CODE && checkPermissionsGranted()) {
            runFullCameraDiagnostics()
            setupUIListeners()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraDevice?.close()
        imageReader?.close()
    }
}